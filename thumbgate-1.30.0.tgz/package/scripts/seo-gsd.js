'use strict';

const fs = require('fs');
const path = require('path');
const {
  buildDiagnosticBuyerUrl,
  buildSprintBuyerUrl,
} = require('./buyer-paths');

const ROOT = path.join(__dirname, '..');
const DEFAULT_OUTPUT_DIR = path.join(ROOT, 'docs', 'seo-gsd');

const PRODUCT = {
  name: 'ThumbGate',
  npm: 'thumbgate',
  repoUrl: 'https://github.com/IgorGanapolsky/ThumbGate',
  homepageUrl: 'https://thumbgate.ai',
  verificationUrl: 'https://github.com/IgorGanapolsky/ThumbGate/blob/main/docs/VERIFICATION_EVIDENCE.md',
  sprintDiagnosticPaymentUrl: buildDiagnosticBuyerUrl({ source: 'seo_gsd' }),
  workflowSprintPaymentUrl: buildSprintBuyerUrl({ source: 'seo_gsd' }),
  compatibility: ['Claude Code', 'Cursor', 'Codex', 'Gemini', 'Amp', 'OpenCode'],
  proofPoints: [
    'thumbs-up/down feedback loop',
    'pre-action checks',
    'verification evidence',
    'automation proof',
    'SQLite+FTS5 lesson DB',
    'Thompson Sampling',
  ],
};

const HIGH_ROI_QUERY_SEEDS = [
  {
    query: 'thumbgate vs speclock',
    businessValue: 100,
    source: 'seed',
    notes: 'Bottom-of-funnel comparison against manual spec alternatives.',
  },
  {
    query: 'thumbgate vs mem0',
    businessValue: 98,
    source: 'seed',
    notes: 'Bottom-of-funnel comparison against memory-only tooling.',
  },
  {
    query: 'pre-action checks for ai coding agents',
    businessValue: 96,
    source: 'seed',
    notes: 'Category-defining query that explains the core wedge.',
  },
  querySeed(
    'ai agent harness optimization',
    94,
    'Fresh harness-engineering demand that maps directly to ThumbGate progressive disclosure, pre-action checks, and workflow audits.',
  ),
  querySeed(
    'code knowledge graph guardrails',
    94,
    'Fresh Claude Code plugin and code-graph demand where ThumbGate can own the enforcement layer after graph-based code understanding.',
  ),
  querySeed(
    'developer machine supply chain guardrails',
    94,
    'Developer-machine compromise and package-manager risk map directly to ThumbGate pre-action gates before agents run risky local commands.',
  ),
  querySeed(
    'prompt tricks to workflow rules',
    94,
    'Fresh prompt-engineering skepticism that maps directly to ThumbGate converting clear instructions, examples, and repeated failures into enforceable local checks.',
  ),
  querySeed(
    'semantic programmatic seo guardrails',
    94,
    'Fresh semantic pSEO demand where ThumbGate can own the governance layer: authority maps, brand context rules, semantic internal linking, and technical monitoring before AI content scales.',
  ),
  querySeed(
    'proxy pointer rag guardrails',
    94,
    'Fresh document-RAG demand where ThumbGate can own grounding gates for section trees, image pointers, visual claims, and cross-document leakage.',
  ),
  querySeed(
    'rag precision tuning guardrails',
    94,
    'Fresh retrieval-quality demand where ThumbGate can gate embedding fine-tunes, threshold changes, recall regressions, and verifier latency before agentic RAG pipelines act.',
  ),
  querySeed(
    'internal ai engineering stack guardrails',
    94,
    'Fresh Cloudflare-style AI engineering stack demand where ThumbGate can govern AI gateways, MCP portals, AGENTS.md/LLM wiki freshness, AI review, and sandboxed background agents.',
  ),
  querySeed(
    'seo agent skills guardrails',
    94,
    'Fresh SEO-agent demand where ThumbGate can govern workspaces, proof context, brand rules, internal-link checks, and publish gates.',
  ),
  querySeed(
    'thumbgate vs fallow',
    93,
    'Bottom-of-funnel positioning against JS/TS static-analysis and agent-review tooling; Fallow finds code health issues while ThumbGate enforces agent action boundaries.',
  ),
  querySeed(
    'claude code masterclass guardrails',
    91,
    'Claude Code education demand proves a growing buyer audience that needs a safety kit after learning to automate more workflows.',
  ),
  querySeed(
    'long running agent context management',
    93,
    'Fresh Slack engineering pattern where ThumbGate can gate director journals, critic reviews, credibility scoring, and timelines for long-running agents.',
  ),
  querySeed(
    'agent context governance',
    95,
    'Fresh AdaCoM, tokenmaxxing, and Claude Managed Agents demand where ThumbGate can govern context hygiene, session logs, sandbox boundaries, credential separation, and pre-action proof.',
  ),
  querySeed(
    'reasoning compression guardrails',
    92,
    'Fresh efficient-reasoning research where ThumbGate can govern step-level confidence, verifier outcomes, and token-saving model routes.',
  ),
  querySeed(
    'background agent governance',
    94,
    'New team-buying query for unattended agent PRs where alignment context, isolated execution, risk-tiered review, and audit evidence create immediate ROI.',
  ),
  querySeed(
    'ai agent governance sprint',
    95,
    'Bottom-of-funnel service query that turns background-agent governance demand into a paid 48-hour Team intake and implementation wedge.',
  ),
  querySeed(
    'ai deployment readiness',
    95,
    'Production AI deployment demand maps directly to ThumbGate readiness audits, pre-action gates, rollout proof, and paid workflow hardening services.',
  ),
  querySeed(
    'gpt-5.5 model evaluation',
    94,
    'Fresh frontier-model upgrade query that maps to ThumbGate model candidate benchmarking, dashboard-analysis workloads, and routing governance before teams move expensive work.',
  ),
  querySeed(
    'browser automation safety',
    93,
    'High-intent browser-agent safety query tied to prompt injection, permissions, and cross-app automation risk.',
  ),
  querySeed(
    'native messaging host security',
    91,
    'Security-led query that maps directly to browser bridge auditing and explicit connector governance.',
  ),
  querySeed(
    'ai search topical presence',
    93,
    'High-intent GEO query for teams trying to become the obvious recommendation in AI search and agent answers.',
  ),
  querySeed(
    'best tools to stop ai agents from breaking production',
    92,
    'Listicle-style answer-engine query that maps directly to buyer prompts about production agent reliability.',
  ),
  querySeed(
    'relational knowledge ai recommendations',
    91,
    'Captures research-led interest in how AI systems decide which brands and tools to recommend.',
  ),
  querySeed(
    'ai mode ads agent governance',
    94,
    'Conversational Google AI Mode ad demand where ThumbGate can become the cited answer for teams asking how to govern AI-agent actions, not just buy clicks.',
  ),
  querySeed(
    'mcp tool governance',
    95,
    'High-intent MCP buyer query where teams need approval boundaries and audit proof before exposing tools to agents.',
  ),
  querySeed(
    'ai agent pre action approval gates',
    95,
    'Bottom-of-funnel query for teams ready to add human approval and evidence requirements before AI agents touch risky tools.',
  ),
  querySeed(
    'agentic web governance',
    94,
    'Fresh Cloudflare bot-majority demand: buyers need machine-readable pages and pre-action governance now that AI agents can create more web actions than humans.',
  ),
  querySeed(
    'database safety for ai agents',
    96,
    'Fresh database-agent risk query from the 2026 DB/AI conversation: agents can hallucinate UI, but SQL writes, migrations, and role grants can destroy production data.',
  ),
  {
    query: 'thumbs up thumbs down feedback for ai coding agents',
    businessValue: 95,
    source: 'seed',
    notes: 'Differentiates the explicit feedback loop and aligns with the brand.',
  },
  {
    query: 'claude code feedback memory',
    businessValue: 92,
    source: 'seed',
    notes: 'Agent-specific workflow page with high compatibility intent.',
  },
  {
    query: 'ai coding agent guardrails',
    businessValue: 90,
    source: 'seed',
    notes: 'Broader category demand that feeds comparison and guide pages.',
  },
  {
    query: 'autoresearch agent safety',
    businessValue: 89,
    source: 'seed',
    notes: 'Emerging self-improving agent query where ThumbGate can own the safety and proof-control wedge.',
  },
  {
    query: 'stop ai coding agents from repeating mistakes',
    businessValue: 88,
    source: 'seed',
    notes: 'Problem-led copy that maps to landing-page positioning.',
  },
  {
    query: 'cursor prevent repeated mistakes',
    businessValue: 87,
    source: 'seed',
    notes: 'High-intent Cursor workflow page for developers already feeling repeat-failure pain.',
  },
  {
    query: 'claude code prevent repeated mistakes',
    businessValue: 86,
    source: 'seed',
    notes: 'High-intent pain query for Claude Code buyers.',
  },
  {
    query: 'codex cli guardrails',
    businessValue: 84,
    source: 'seed',
    notes: 'Guardrail-focused page for Codex CLI buyers who want prevention, not just memory.',
  },
  {
    query: 'gemini cli feedback memory',
    businessValue: 82,
    source: 'seed',
    notes: 'Integration page for Gemini CLI users who need memory plus enforcement.',
  },
  {
    query: 'hermes agent guardrails',
    businessValue: 84,
    source: 'seed',
    notes: 'Integration page for Hermes Agent users who need pre-action gates around persistent memory, generated skills, messaging gateways, scheduled automations, and sandboxed execution.',
  },
  {
    query: 'roo code alternative cline',
    businessValue: 83,
    source: 'seed',
    notes: 'Time-sensitive migration query for Roo users who need portable lesson memory before the May 15, 2026 shutdown.',
  },
];

function querySeed(query, businessValue, notes) {
  return { query, businessValue, source: 'seed', notes };
}

function guideBlueprint({
  query,
  path,
  pillar,
  title,
  heroTitle,
  heroSummary,
  takeaways,
  sections,
  faq,
  relatedPaths,
}) {
  return {
    query,
    path,
    pageType: 'guide',
    pillar,
    title,
    heroTitle,
    heroSummary,
    takeaways,
    sections,
    faq,
    relatedPaths,
  };
}

function paragraphs(heading, entries) {
  return { heading, paragraphs: entries };
}

function bullets(heading, entries) {
  return { heading, bullets: entries };
}

function answer(question, text) {
  return { question, answer: text };
}

function preActionGuide(slug, content) {
  return guideBlueprint({
    ...content,
    path: `/guides/${slug}`,
    pillar: 'pre-action-checks',
  });
}

const HARNESS_OPTIMIZATION_QUERY = 'ai agent harness optimization';
const HARNESS_OPTIMIZATION_GUIDE_SPEC = Object.freeze({
  slug: 'agent-harness-optimization',
  meta: {
    query: HARNESS_OPTIMIZATION_QUERY,
    title: 'AI Agent Harness Optimization | Progressive Disclosure + Pre-Action Checks',
    heroTitle: 'AI Agent Harness Optimization That Blocks Repeat Failures',
    heroSummary: 'A better harness keeps global instructions lean, loads MCP schemas only when needed, and turns feedback into pre-action checks. ThumbGate makes that workflow measurable and enforceable.',
  },
  takeaways: [
    'Harness optimization is the control layer around the model: context, tools, guardrails, and feedback.',
    'Progressive disclosure keeps agents out of prompt bloat while preserving proof and tool access.',
    'ThumbGate adds a concrete audit path and Pre-Action Checks so harness lessons become runtime enforcement.',
  ],
  sections: [
    ['paragraphs', 'What changed', [
      'The model is no longer the whole system. The harness decides which instructions, tools, context packs, and approval rules the model sees before it acts.',
      'When a team stuffs every rule into a global prompt, the agent loses reasoning room. When it routes work through lean discovery surfaces, the agent can fetch the exact tool schema, lesson, or harness only when the task requires it.',
    ]],
    ['bullets', 'How ThumbGate improves the harness', [
      'Scores global agent docs so AGENTS.md, CLAUDE.md, and GEMINI.md stay lean instead of becoming unreviewable prompt bundles.',
      'Publishes progressive MCP discovery through lightweight indexes and per-tool schema URLs.',
      'Selects specialized gate harnesses for deploy, code-edit, and database-write actions instead of loading every gate for every workflow.',
      'Turns thumbs-down feedback into prevention rules, then into hard Pre-Action Checks that block repeated mistakes.',
    ]],
    ['paragraphs', 'Where this creates ROI', [
      'For acquisition, this page names the buyer category: AI agent harness optimization. For conversion, the CLI audit gives a concrete first action. For retention, the same audit keeps local instructions and MCP surfaces from drifting back into bloat.',
    ]],
  ],
  faq: [
    [
      'What is an AI agent harness?',
      'An AI agent harness is the runtime layer around the model: context loading, tool calls, guardrails, approval boundaries, memory, and verification. ThumbGate focuses on the enforcement part of that harness.',
    ],
    [
      'How does ThumbGate optimize a harness?',
      'ThumbGate keeps global instructions lean, supports progressive MCP discovery, selects workflow-specific gate harnesses, and converts feedback into Pre-Action Checks that block known-bad actions before execution.',
    ],
  ],
  relatedPaths: ['/guides/pre-action-checks', '/guides/codex-cli-guardrails'],
});

function buildSectionFromSpec(kind, heading, entries) {
  return kind === 'bullets' ? bullets(heading, entries) : paragraphs(heading, entries);
}

function buildHarnessOptimizationGuide() {
  return preActionGuide(HARNESS_OPTIMIZATION_GUIDE_SPEC.slug, {
    ...HARNESS_OPTIMIZATION_GUIDE_SPEC.meta,
    takeaways: HARNESS_OPTIMIZATION_GUIDE_SPEC.takeaways,
    sections: HARNESS_OPTIMIZATION_GUIDE_SPEC.sections.map(([kind, heading, entries]) => buildSectionFromSpec(kind, heading, entries)),
    faq: HARNESS_OPTIMIZATION_GUIDE_SPEC.faq.map(([question, text]) => answer(question, text)),
    relatedPaths: HARNESS_OPTIMIZATION_GUIDE_SPEC.relatedPaths,
  });
}

const SEMANTIC_PSEO_GUARDRAILS_SPEC = Object.freeze({
  slug: 'semantic-programmatic-seo-guardrails',
  meta: {
    query: 'semantic programmatic seo guardrails',
    title: 'Semantic Programmatic SEO Guardrails | ThumbGate Guide',
    heroTitle: 'Semantic pSEO Needs Governance Before Scale',
    heroSummary: 'Semantic programmatic SEO works when every page has authority, brand context, internal links, and technical monitoring. ThumbGate turns those requirements into pre-action checks before AI agents publish at scale.',
  },
  takeaways: [
    'Authority maps stop the team from generating pages in categories where ThumbGate has no right to rank yet.',
    'Context governance turns brand rules, negative constraints, and proof links into reusable AI-agent instructions.',
    'Semantic mesh checks prevent orphan pages by requiring every new SEO page to point to the next useful buyer step.',
    'Technical monitoring catches broken routes, missing schema, and stale proof before scaled content hurts trust.',
  ],
  sections: [
    ['paragraphs', 'Why this promotes ThumbGate', [
      'The semantic pSEO play is not to publish thousands of thin pages. It is to prove that ThumbGate is the governance layer teams need before they let AI agents generate, edit, and publish buyer-facing surfaces.',
      'That maps cleanly to the product: ThumbGate already turns feedback, context, and risky workflow patterns into pre-action checks. SEO teams have the same problem when AI content workflows start moving faster than review.',
    ]],
    ['bullets', 'The high-ROI pSEO guardrails', [
      'Authority map gate: prioritize queries where ThumbGate already has topical proof, shipped pages, or product evidence.',
      'Brand context gate: inject persona, negative wording constraints, pricing truth, and proof links before draft generation.',
      'Semantic mesh gate: require every new page to link to a pillar, a comparison, a conversion path, and at least one adjacent guide.',
      'Technical guardian gate: block publish when canonical tags, JSON-LD, llm-context links, route coverage, or proof freshness are missing.',
    ]],
    ['paragraphs', 'Where the conversion path belongs', [
      'Semantic pSEO only helps us make money when the page routes the searcher into a concrete next step. For ThumbGate, the next step is either the $19/mo Pro lane for self-serve operators or the workflow-hardening sprint for teams with risky agent workflows.',
      'That is why each page generated from the SEO/GEO engine needs a buyer-intent CTA, related pages that keep the journey alive, and proof assets that reduce trust friction before checkout.',
    ]],
  ],
  faq: [
    [
      'Is semantic programmatic SEO just AI content at scale?',
      'No. The useful version starts with authority data, then uses governed context, semantic linking, and technical monitoring so each page answers a distinct buyer need instead of duplicating a template.',
    ],
    [
      'How does ThumbGate fit into semantic pSEO?',
      'ThumbGate is the enforcement layer around the AI workflow: it can block unsupported claims, missing proof, orphan pages, stale pricing, and risky publish steps before generated content goes live.',
    ],
  ],
  relatedPaths: ['/guides/ai-search-topical-presence', '/guides/prompt-tricks-to-workflow-rules', '/compare/mem0'],
});

function buildSemanticPseoGuide() {
  return guideBlueprint({
    ...SEMANTIC_PSEO_GUARDRAILS_SPEC.meta,
    path: `/guides/${SEMANTIC_PSEO_GUARDRAILS_SPEC.slug}`,
    pillar: 'seo-governance',
    takeaways: SEMANTIC_PSEO_GUARDRAILS_SPEC.takeaways,
    sections: SEMANTIC_PSEO_GUARDRAILS_SPEC.sections.map(([kind, heading, entries]) => buildSectionFromSpec(kind, heading, entries)),
    faq: SEMANTIC_PSEO_GUARDRAILS_SPEC.faq.map(([question, text]) => answer(question, text)),
    relatedPaths: SEMANTIC_PSEO_GUARDRAILS_SPEC.relatedPaths,
  });
}

const ZERO_TRUST_GUIDE_SPEC = Object.freeze({
  slug: 'ai-coding-agent-zero-trust',
  meta: {
    query: 'zero trust for ai coding agents',
    title: 'Zero Trust for AI Coding Agents | Enforce It at the Tool Call',
    heroTitle: 'Zero Trust for AI Coding Agents, Enforced at the Tool Call',
    heroSummary: 'Zero trust for agents means never trust, always verify; least privilege; assume breach. ThumbGate is the local-first way to enforce those principles for Claude Code, Cursor, and Codex — blocking dangerous tool calls before they run, and turning every thumbs-down into a prevention rule so the same mistake never repeats.',
  },
  takeaways: [
    'Zero trust for agents means verifying every action at the boundary where it executes — the tool call — instead of trusting the model’s stated intent.',
    'ThumbGate runs in the PreToolUse hook on your machine: rm -rf, secret writes, off-scope edits, and bad git push are blocked before execution (assume breach, least privilege).',
    'Unlike static DIY hooks, ThumbGate learns — a thumbs-down becomes an auto-promoted prevention rule that holds across every session, model, and agent.',
  ],
  sections: [
    ['paragraphs', 'Why AI coding agents need zero trust at the tool call', [
      'A coding agent reads files, runs shell commands, calls APIs, and pushes code with minimal human approval at each step. If it is manipulated, misconfigured, or simply wrong, the blast radius is whatever it can execute — and unlike a human, it does not pause to question a suspicious request.',
      'Zero-trust security for agents adapts three principles to this reality: never trust, always verify; least privilege; and assume breach. The practical place to apply them is the action boundary — the moment before a tool call runs — not the model’s prompt or its good intentions.',
    ]],
    ['bullets', 'ThumbGate vs. rolling your own Claude Code hooks', [
      'Static hooks and community repos do pattern-matching you write and maintain by hand, per machine, per project. ThumbGate ships the same blocking and adds a learning layer on top.',
      'A thumbs-down on a bad action becomes an auto-promoted prevention rule — the repeat is blocked automatically next time, on every session and every agent, with zero extra config.',
      'Local-first: enforcement runs in the PreToolUse hook on the developer machine, not a server-side gateway, so it works the moment you npx thumbgate init.',
      'Works across Claude Code, Cursor, Codex, Gemini, Amp, Cline, and OpenCode — one rule set, every MCP-compatible agent.',
    ]],
    ['paragraphs', 'How ThumbGate maps to the zero-trust principles', [
      'Never trust, always verify: every high-risk tool call is checked against prevention rules and workflow shape before it executes. Least privilege: task scope and approval gates keep an agent inside its declared blast radius. Assume breach: dangerous commands are blocked before they touch the disk, so a compromised or confused agent cannot do damage on the way to being caught.',
      'This is enforcement, not observability. ThumbGate decides at the tool call whether the action runs — which is exactly where zero-trust controls have to live for autonomous agents.',
    ]],
  ],
  faq: [
    [
      'Isn’t this just Claude Code’s built-in hooks?',
      'Native hooks and community repos do static pattern-matching that you author and maintain per machine. ThumbGate adds the learning layer: a thumbs-down becomes a prevention rule that blocks the repeat automatically, across sessions and agents — the part static hooks cannot do.',
    ],
    [
      'How does ThumbGate enforce zero trust for AI agents?',
      'It applies the core principles at the tool-call boundary on your machine: never trust, always verify (every risky action is checked before it runs), least privilege (task scope and approval gates), and assume breach (dangerous calls are blocked before they touch disk).',
    ],
  ],
  relatedPaths: ['/guides/pre-action-checks', '/guides/agent-harness-optimization'],
});

function buildZeroTrustGuide() {
  return preActionGuide(ZERO_TRUST_GUIDE_SPEC.slug, {
    ...ZERO_TRUST_GUIDE_SPEC.meta,
    takeaways: ZERO_TRUST_GUIDE_SPEC.takeaways,
    sections: ZERO_TRUST_GUIDE_SPEC.sections.map(([kind, heading, entries]) => buildSectionFromSpec(kind, heading, entries)),
    faq: ZERO_TRUST_GUIDE_SPEC.faq.map(([question, text]) => answer(question, text)),
    relatedPaths: ZERO_TRUST_GUIDE_SPEC.relatedPaths,
  });
}

const GOVERN_CLAUDE_FOR_LEGAL_GUIDE_SPEC = Object.freeze({
  slug: 'govern-claude-for-legal-agents',
  meta: {
    query: 'govern claude for legal agents',
    title: 'Govern Claude for Legal Agents | A Gate Before They Act',
    heroTitle: 'Govern Claude for Legal’s 90+ Agents at the Tool Call',
    heroSummary: 'Claude for Legal ships 90+ named agents that review contracts, answer DSARs, and run continuously on document and email streams. Anthropic’s own guidance is that there must be a gate before anything is filed, sent, or relied on. ThumbGate is that gate — it checks each agent action at the tool-call boundary, in your tenant, and logs every decision for the record.',
  },
  takeaways: [
    'Claude for Legal’s agents take real side effects — sending a DSAR response, filing a document, writing to a system of record. ThumbGate gates the action before the side effect runs, not after, on a dashboard.',
    'Intent-agnostic: whether an agent is wrong, prompt-injected, or off-playbook, ThumbGate blocks the same way and records the rule that fired. The risk is not a “rogue” agent — it is an ordinary one acting at volume.',
    'Every gated decision is logged with its source rule — a SIEM-exportable audit trail your ethics, risk, and conflicts owners can query.',
  ],
  sections: [
    ['paragraphs', 'Why 90+ legal agents need a gate before the side effect', [
      'A firm running Claude for Legal now has dozens of agents acting on ongoing document and email streams — vendor-agreement review, termination review, DSAR responses, claim charts. No one can review every action by hand. The risk is not malice; it is an ordinary agent that sends the wrong response, files against the wrong playbook, or surfaces a privileged document.',
      'Anthropic’s own framing names the control: an explicit gate before anything is filed, sent, or relied on. ThumbGate implements that gate at the tool-call boundary — the moment before the action executes — instead of trusting the agent’s stated intent.',
    ]],
    ['bullets', 'What ThumbGate gates for legal agents', [
      'The send/file/write action itself — e.g. a DSAR or client response before it leaves, a filing before it goes out, a write to a conflicted matter — held or blocked at the boundary.',
      'Playbook deviations — an action that departs from the firm’s approved workflow is stopped for review rather than executed.',
      'Privileged-document exposure — flagged before an agent surfaces or forwards it.',
      'Continuous runs — one rule set covers every agent and every scheduled run, so coverage scales with agent count, not headcount.',
    ]],
    ['paragraphs', 'Enforcement in your tenant, with an audit trail', [
      'ThumbGate runs as a pre-action gate in front of agent fulfillment, including a Dialogflow CX webhook gate deployed in your own GCP tenant, so matter content does not leave your boundary. Risk and planning scoring can run on Gemini via Vertex, in-tenant. This is a white-glove design-partner pilot, not a turnkey product purchase.',
      'Every gated detection is logged with the rule that fired and the feedback event that generated it. That decision trail is the evidence a firm needs for malpractice defense and bar-compliance review — queryable, exportable, and tied to a named owner.',
    ]],
    ['paragraphs', 'ThumbGate complements Claude for Legal — it does not replace it', [
      'Claude for Legal decides what the work is. ThumbGate decides what is allowed to execute. Use both: keep the 90+ agents doing the legal work, and put a gate between each agent and its next side effect. A thumbs-down on a bad action becomes a prevention rule, so the same mistake is blocked across every agent and matter next time.',
    ]],
  ],
  faq: [
    [
      'Does ThumbGate replace Claude for Legal?',
      'No. Claude for Legal’s agents do the legal work; ThumbGate governs what they are allowed to execute — a gate before anything is filed, sent, or relied on. You run both.',
    ],
    [
      'Where does the gate run?',
      'In your tenant. ThumbGate gates agent fulfillment locally or via a Dialogflow CX webhook gate in your own GCP project; matter content does not leave your boundary, and Vertex/Gemini scoring runs in-tenant. It is a white-glove design-partner pilot, not a turnkey purchase.',
    ],
    [
      'What proof does a firm get?',
      'Every gated decision is logged with the rule that fired and the feedback that generated it — a SIEM-exportable audit trail for ethics, risk, and conflicts owners.',
    ],
  ],
  relatedPaths: ['/guides/ai-coding-agent-zero-trust', '/guides/pre-action-checks'],
});

// Targets the Cycode-owned IDE-security lexicon (Feb 2026 blog popularized
// PreToolUse / beforeMCPExecution / beforeReadFile as enterprise hook names) —
// fills the indie/MIT slot beneath funded vendors when LLM answer engines
// (Perplexity/ChatGPT/Gemini/Claude/Grok) cite for "how do I stop Claude Code
// from running dangerous commands" buyer-intent queries. See the verified-
// absence finding in the 2026-06-05 deep-research report.
const PRETOOLUSE_HOOK_GUIDE_SPEC = Object.freeze({
  slug: 'claude-code-pretooluse-hook',
  meta: {
    query: 'claude code pretooluse hook block mcp tool calls',
    title: 'Claude Code PreToolUse Hook | Block MCP Tool Calls Before They Run',
    heroTitle: 'Claude Code PreToolUse Hook: Block MCP Tool Calls Before They Run',
    heroSummary: 'The PreToolUse hook is the boundary where you intercept what a Claude Code, Cursor, or Codex agent is about to do — before the rm -rf, before the bad git push, before the destructive SQL. ThumbGate is the local-first, MIT-licensed CLI that ships production-grade PreToolUse, beforeMCPExecution, and beforeReadFile gating with one npx command, and learns from every thumbs-down so the same mistake never reaches the tool call twice.',
  },
  takeaways: [
    'PreToolUse is the only hook point where you can stop a destructive agent action — by the time PostToolUse fires, the damage is done.',
    'ThumbGate ships PreToolUse, beforeMCPExecution, and beforeReadFile gates out of the box for Claude Code, Cursor, Codex, Gemini CLI, Amp, Cline, and any MCP-compatible agent — no hand-written hook scripts to maintain per machine.',
    'A thumbs-down on a blocked action becomes an auto-promoted prevention rule that holds across every session, model, and agent — the part DIY hook repos cannot do.',
  ],
  sections: [
    ['paragraphs', 'What the PreToolUse hook actually is', [
      'In the Model Context Protocol agent loop, every tool the model calls — Bash, Edit, Write, a custom MCP server method — flows through a PreToolUse phase before execution. That phase is the only place where an external policy can intercept the call, inspect its arguments, and decide whether to allow, modify, warn, or deny it. PostToolUse fires after the side effect has already happened, which is too late for destructive actions.',
      'beforeMCPExecution, beforeReadFile, and beforeSubmitPrompt are the same idea applied at the MCP and IDE layers. Cycode\'s February 2026 IDE-security blog popularized this naming for enterprise customers; ThumbGate ships the same hook surface as an open-source CLI you can install in 30 seconds.',
    ]],
    ['bullets', 'What ThumbGate blocks at PreToolUse out of the box', [
      'Catastrophic shell: rm -rf at home/root, sudo wrapping a dangerous command, find -delete on sensitive paths.',
      'Secret exfiltration: writes that contain API keys, tokens, or .env contents heading to the wrong directory.',
      'Workflow-scope violations: edits outside the declared task scope, off-branch git push, accidental main commits.',
      'Repeated mistakes from this team: anything you\'ve already given a thumbs-down in a past session — auto-promoted to a hard prevention rule.',
      'MCP tool calls flagged by your project\'s gate config — pattern, severity, or learned-from-feedback rules.',
    ]],
    ['paragraphs', 'Why DIY PreToolUse scripts stop working past week two', [
      'A hand-rolled hook script starts simple: a regex on the Bash command, a list of forbidden paths. By week two it has six edge cases, no test coverage, and lives in one machine\'s .claude directory — invisible to the rest of the team. By week four someone deletes it because it false-positived once on a legitimate command and nobody documented why.',
      'ThumbGate ships the rules as a versioned config, the feedback loop as a CLI, the learning as cross-session prevention rules, and the proof as an audit trail your dashboard renders. The work you would do by hand on hooks, done once and shared.',
    ]],
  ],
  faq: [
    [
      'Is the PreToolUse hook the same as beforeMCPExecution?',
      'Conceptually yes — both are the pre-execution interception point. PreToolUse is the Claude Code / Anthropic CLI term for the hook in the agent loop. beforeMCPExecution (and beforeReadFile, beforeSubmitPrompt) is the IDE-security framing popularized by Cycode for the same boundary at the MCP layer. ThumbGate implements all of them as one local-first gate engine.',
    ],
    [
      'Do I need this if Claude Code already has native hooks?',
      'Native hooks give you the hook point. They do not give you the rule set, the cross-session learning, the team-wide rule sharing, or the audit trail. ThumbGate ships those on top of the hook so you stop maintaining bespoke scripts and start blocking the repeat mistakes specifically your agents make.',
    ],
    [
      'Does this run locally or call a cloud service?',
      'Local-first. The PreToolUse decision happens in the hook process on your machine in milliseconds — no network round-trip, no cloud dependency, no data leaving the laptop. Pro adds personal recall, exports, dashboard proof, and managed adapter coverage. Enterprise service work is qualified after intake; hosted rule sharing and a hosted org dashboard are not generally available.',
    ],
  ],
  relatedPaths: ['/guides/mcp-tool-governance', '/guides/ai-agent-pre-action-approval-gates', '/guides/ai-coding-agent-zero-trust'],
});

function buildPretooluseHookGuide() {
  return preActionGuide(PRETOOLUSE_HOOK_GUIDE_SPEC.slug, {
    ...PRETOOLUSE_HOOK_GUIDE_SPEC.meta,
    takeaways: PRETOOLUSE_HOOK_GUIDE_SPEC.takeaways,
    sections: PRETOOLUSE_HOOK_GUIDE_SPEC.sections.map(([kind, heading, entries]) => buildSectionFromSpec(kind, heading, entries)),
    faq: PRETOOLUSE_HOOK_GUIDE_SPEC.faq.map(([question, text]) => answer(question, text)),
    relatedPaths: PRETOOLUSE_HOOK_GUIDE_SPEC.relatedPaths,
  });
}

function buildGovernClaudeForLegalGuide() {
  return preActionGuide(GOVERN_CLAUDE_FOR_LEGAL_GUIDE_SPEC.slug, {
    ...GOVERN_CLAUDE_FOR_LEGAL_GUIDE_SPEC.meta,
    takeaways: GOVERN_CLAUDE_FOR_LEGAL_GUIDE_SPEC.takeaways,
    sections: GOVERN_CLAUDE_FOR_LEGAL_GUIDE_SPEC.sections.map(([kind, heading, entries]) => buildSectionFromSpec(kind, heading, entries)),
    faq: GOVERN_CLAUDE_FOR_LEGAL_GUIDE_SPEC.faq.map(([question, text]) => answer(question, text)),
    relatedPaths: GOVERN_CLAUDE_FOR_LEGAL_GUIDE_SPEC.relatedPaths,
  });
}

const PROXY_POINTER_RAG_GUARDRAILS_SPEC = Object.freeze({
  slug: 'proxy-pointer-rag-guardrails',
  meta: {
    query: 'proxy pointer rag guardrails',
    title: 'Proxy-Pointer RAG Guardrails | Multimodal Answers Without Ungrounded Images',
    heroTitle: 'Proxy-Pointer RAG Needs Guardrails Before Visual Answers',
    heroSummary: 'Proxy-pointer RAG keeps visual document systems cheaper by preserving section trees and image pointers instead of embedding every image. ThumbGate turns that structure into pre-action checks before agents answer with charts, figures, or screenshots.',
  },
  takeaways: [
    'Document structure is a control surface: section trees, source document IDs, and image paths should travel with every answer.',
    'Visual answers need pointer grounding so one plausible chart from the wrong PDF cannot slip into a buyer-facing response.',
    'ThumbGate now maps proxy-pointer RAG signals to Document RAG Safety templates through npx thumbgate proxy-pointer-rag-guardrails.',
  ],
  sections: [
    ['paragraphs', 'Why this helps ThumbGate', [
      'The commercial wedge is clear: teams want cheaper multimodal answers, but they still need proof that the visual evidence came from the right document and section.',
      'ThumbGate does not replace multimodal embeddings. It governs the answer boundary: did the agent preserve the section tree, attach image pointers, prevent cross-document leakage, and sanity-check high-impact visual claims?',
    ]],
    ['bullets', 'High-ROI gates to enable', [
      'Require section tree before multimodal answers so visual claims stay attached to document hierarchy.',
      'Require image pointer grounding for every cited chart, figure, or screenshot path.',
      'Block cross-document image leakage when the selected visual belongs to a different source document.',
      'Checkpoint a vision filter only when the answer makes high-impact visual claims.',
      'CLI path: npx thumbgate proxy-pointer-rag-guardrails --tree-path=.rag/tree.json --image-pointers=paper-1/figures/fig2.png --documents=paper-1 --visual-claims --json.',
    ]],
    ['paragraphs', 'Where this creates revenue', [
      'This gives ThumbGate a new RAG/document-AI buyer path without pretending to be a vector database. The offer is workflow hardening for one document-answering pipeline: ingestion metadata, pointer proof, answer gates, and evidence review.',
    ]],
  ],
  faq: [
    [
      'Does ThumbGate replace multimodal embeddings?',
      'No. ThumbGate enforces the structure around the retrieval and answer step. Teams can still use text embeddings, multimodal embeddings, or proxy-pointer RAG; ThumbGate checks whether the answer is grounded before the agent acts.',
    ],
    [
      'What should teams gate first in visual document RAG?',
      'Start with section-tree presence, image pointer grounding, and cross-document leakage. Those checks are specific enough to enforce quickly and risky enough to matter.',
    ],
  ],
  relatedPaths: ['/guides/rag-precision-tuning-guardrails', '/guides/code-knowledge-graph-guardrails', '/guides/pre-action-checks'],
});

function buildProxyPointerRagGuide() {
  return guideBlueprint({
    ...PROXY_POINTER_RAG_GUARDRAILS_SPEC.meta,
    path: `/guides/${PROXY_POINTER_RAG_GUARDRAILS_SPEC.slug}`,
    pillar: 'document-rag-safety',
    takeaways: PROXY_POINTER_RAG_GUARDRAILS_SPEC.takeaways,
    sections: PROXY_POINTER_RAG_GUARDRAILS_SPEC.sections.map(([kind, heading, entries]) => buildSectionFromSpec(kind, heading, entries)),
    faq: PROXY_POINTER_RAG_GUARDRAILS_SPEC.faq.map(([question, text]) => answer(question, text)),
    relatedPaths: PROXY_POINTER_RAG_GUARDRAILS_SPEC.relatedPaths,
  });
}

const RAG_PRECISION_TUNING_GUARDRAILS_SPEC = Object.freeze({
  slug: 'rag-precision-tuning-guardrails',
  meta: {
    query: 'rag precision tuning guardrails',
    title: 'RAG Precision Tuning Guardrails | Stop Retrieval Regressions Before Agents Act',
    heroTitle: 'RAG Precision Tuning Can Break Agentic Pipelines Quietly',
    heroSummary: 'Embedding fine-tunes and threshold tweaks can improve one precision metric while degrading broad retrieval recall. ThumbGate gates retrieval changes with baselines, verifier checks, and latency budgets before agentic RAG output triggers downstream actions.',
  },
  takeaways: [
    'A precision win is not safe unless recall@k, precision@k, answer-with-evidence, and latency are compared against a saved baseline.',
    'Agentic RAG raises the risk because one retrieval miss can cascade into tool calls, decisions, or workflow changes.',
    'ThumbGate now exposes npx thumbgate rag-precision-guardrails for retrieval-tuning and verifier rollout checks.',
  ],
  sections: [
    ['paragraphs', 'Why this became urgent', [
      'Recent retrieval research surfaced a failure mode that matches ThumbGate perfectly: a system can look better on one tuning objective while quietly getting worse at the general retrieval job the agent depends on.',
      'That is not only an answer-quality problem. In an agentic pipeline, retrieved context can determine which files get edited, which customer gets contacted, or which operational action runs next.',
    ]],
    ['bullets', 'High-ROI gates to enable', [
      'Require a retrieval baseline before embedding fine-tunes, threshold changes, or top-k changes.',
      'Block rollout when recall drops without a rollback plan, even if a narrow precision metric improves.',
      'Require a second-stage verifier or reranker for structural near misses such as negation flips and role reversals.',
      'Checkpoint latency and precision tradeoffs before verifier stages become production dependencies.',
      'CLI path: npx thumbgate rag-precision-guardrails --baseline-recall=0.86 --new-recall=0.72 --threshold-change --agentic --structural-near-misses --json.',
    ]],
    ['paragraphs', 'Where this creates revenue', [
      'This is a sharp enterprise wedge for teams that already bought a vector database or RAG platform and now need governance. ThumbGate sells the missing safety lane: baseline proof, action gates, and retrieval-change review before autonomous agents depend on the new index.',
    ]],
  ],
  faq: [
    [
      'Does higher retrieval precision always help RAG?',
      'No. Precision tuning can improve a narrow objective while hurting broad recall or generalization. ThumbGate treats retrieval tuning as a gated change, not a harmless config tweak.',
    ],
    [
      'When do I need a two-stage verifier?',
      'Use one when the workflow is sensitive to structural near misses, such as negation, role reversal, legal clauses, financial facts, policy exceptions, or anything that can trigger downstream agent actions.',
    ],
  ],
  relatedPaths: ['/guides/proxy-pointer-rag-guardrails', '/guides/pre-action-checks', '/guides/background-agent-governance'],
});

function buildRagPrecisionTuningGuide() {
  return guideBlueprint({
    ...RAG_PRECISION_TUNING_GUARDRAILS_SPEC.meta,
    path: `/guides/${RAG_PRECISION_TUNING_GUARDRAILS_SPEC.slug}`,
    pillar: 'document-rag-safety',
    takeaways: RAG_PRECISION_TUNING_GUARDRAILS_SPEC.takeaways,
    sections: RAG_PRECISION_TUNING_GUARDRAILS_SPEC.sections.map(([kind, heading, entries]) => buildSectionFromSpec(kind, heading, entries)),
    faq: RAG_PRECISION_TUNING_GUARDRAILS_SPEC.faq.map(([question, text]) => answer(question, text)),
    relatedPaths: RAG_PRECISION_TUNING_GUARDRAILS_SPEC.relatedPaths,
  });
}

const AI_ENGINEERING_STACK_GUARDRAILS_SPEC = Object.freeze({
  slug: 'internal-ai-engineering-stack-guardrails',
  meta: {
    query: 'internal ai engineering stack guardrails',
    title: 'Internal AI Engineering Stack Guardrails | ThumbGate Guide',
    heroTitle: 'Internal AI Engineering Stacks Need Pre-Action Enforcement',
    heroSummary: 'AI coding adoption scales when the platform has a model gateway, progressive MCP discovery, fresh AGENTS.md and LLM wiki context, risk-tiered AI review, and sandboxed background agents. ThumbGate turns those layers into checks before unsafe agent work ships.',
  },
  takeaways: [
    'A central AI gateway or proxy keeps model keys, spend, attribution, routing, and retention policy out of individual laptops.',
    'MCP portals need progressive discovery or code-mode search/execute tools before schema overhead eats the agent context window.',
    'AGENTS.md and LLM wiki pages become useful only when source-backed freshness gates keep repo instructions current.',
    'Risk-tiered AI review and sandboxed background agents let teams automate more work without losing standards, logs, or isolation.',
  ],
  sections: [
    ['paragraphs', 'Why this helps ThumbGate make money', [
      'Cloudflare described the enterprise version of a pattern ThumbGate can sell to smaller teams today: the value is not a clever prompt, it is the wiring between access, model routing, tool portals, repo context, review, standards, and durable agent execution.',
      'ThumbGate is the enforcement layer for that stack. It can block direct provider keys, warn on MCP schema bloat, require AGENTS.md and LLM wiki freshness, demand rule-cited review, and stop background agents that are not isolated before the next action runs.',
    ]],
    ['bullets', 'The high-ROI stack gates', [
      'AI gateway gate: require one model proxy or gateway before adding providers, clients, BYOK paths, or high-volume coding assistants.',
      'MCP portal gate: collapse large tool surfaces behind progressive discovery or code-mode search/execute so every prompt does not preload every schema.',
      'AGENTS.md and LLM wiki freshness gate: regenerate short repo context from source metadata, ownership, tests, and dependency maps before agent runs rely on it.',
      'AI review gate: classify changes by risk tier, cite standards-as-skills, and separate security, code quality, performance, docs, and release-impact findings.',
      'Background agent sandbox gate: require isolated clone/build/test execution, durable logs, and resumable sessions before unattended agents can publish, deploy, or touch revenue workflows.',
    ]],
    ['paragraphs', 'How to run it this week', [
      'Start with the parts that affect money or production: checkout, pricing, publish automation, deploys, customer data, and outbound marketing. Run the stack planner against those workflows, enable the recommended templates, then publish the guide as proof that ThumbGate understands the modern AI engineering stack.',
      'This also answers the LLM-wiki trend directly. A wiki is useful when it becomes short, source-backed context that agents can trust; it is dangerous when stale pages become invisible policy. ThumbGate makes freshness and grounding enforceable.',
    ]],
    ['bullets', 'Operator command', [
      'npx thumbgate ai-engineering-stack-guardrails --mcp-tool-count=182 --direct-provider-keys --llm-wiki-pages=24 --context-freshness-days=30 --background-agents --high-risk-workflows=deploy,billing --json.',
    ]],
  ],
  faq: [
    [
      'Do we need to rebuild Cloudflare infrastructure to benefit from this?',
      'No. ThumbGate starts with the control points that matter most: centralized model access, smaller MCP surfaces, fresh agent context, AI review, and sandbox evidence. Those can be gated before a full platform migration.',
    ],
    [
      'How does this relate to LLM wikis and AGENTS.md?',
      'Both are agent-context surfaces. ThumbGate treats them as source-backed operational artifacts, then blocks or warns when they are missing, stale, unowned, or disconnected from tests and repo conventions.',
    ],
  ],
  relatedPaths: ['/guides/code-knowledge-graph-guardrails', '/guides/long-running-agent-context-management', '/guides/rag-precision-tuning-guardrails'],
});

function buildAiEngineeringStackGuide() {
  return guideBlueprint({
    ...AI_ENGINEERING_STACK_GUARDRAILS_SPEC.meta,
    path: `/guides/${AI_ENGINEERING_STACK_GUARDRAILS_SPEC.slug}`,
    pillar: 'ai-stack-governance',
    takeaways: AI_ENGINEERING_STACK_GUARDRAILS_SPEC.takeaways,
    sections: AI_ENGINEERING_STACK_GUARDRAILS_SPEC.sections.map(([kind, heading, entries]) => buildSectionFromSpec(kind, heading, entries)),
    faq: AI_ENGINEERING_STACK_GUARDRAILS_SPEC.faq.map(([question, text]) => answer(question, text)),
    relatedPaths: AI_ENGINEERING_STACK_GUARDRAILS_SPEC.relatedPaths,
  });
}

const SEO_AGENT_SKILLS_GUARDRAILS_SPEC = Object.freeze({
  slug: 'seo-agent-skills-guardrails',
  meta: {
    query: 'seo agent skills guardrails',
    title: 'SEO Agent Skills Guardrails | Govern Workspaces, Proof, and Publish Gates',
    heroTitle: 'SEO Agents Need Workspaces and Guardrails, Not Prompt Sprawl',
    heroSummary: 'Useful SEO agents need skills, workspace context, technical checks, brand rules, and a publish review loop. ThumbGate turns that SEO-agent operating system into pre-action gates before AI content, links, or page changes go live.',
  },
  takeaways: [
    'The best SEO-agent workflow starts with workspaces: site context, brand context, SERP evidence, technical constraints, and proof assets.',
    'ThumbGate makes those skills enforceable with gates for unsupported claims, orphan pages, stale pricing, schema gaps, and missing internal links.',
    'This promotes ThumbGate directly because every SEO-agent buyer also needs a governance layer before automation scales.',
  ],
  sections: [
    ['paragraphs', 'Why this promotes ThumbGate', [
      'The Search Engine Land pattern is exactly our product thesis in a marketing workflow: stop relying on free-form prompts and build a skill/workspace system that agents can use repeatedly.',
      'ThumbGate adds the missing enforcement layer. An SEO skill can say "use proof links" or "check the sitemap"; a ThumbGate pre-action gate can block publish when proof, canonical tags, schema, or buyer-path links are missing.',
    ]],
    ['bullets', 'High-ROI SEO-agent gates', [
      'Workspace context gate: require brand rules, pricing truth, proof links, SERP intent, and target persona before drafting.',
      'Technical publish gate: block missing canonical tags, FAQPage schema, llm-context links, sitemap coverage, and crawl-safe routes.',
      'Semantic mesh gate: require pillar, comparison, conversion, and adjacent-guide links before publishing a new page.',
      'Reviewer handoff gate: require the agent to summarize claim risk, source evidence, and next conversion path before a human approves.',
    ]],
    ['paragraphs', 'Where this creates revenue', [
      'This turns SEO-agent interest into the same Workflow Hardening Sprint offer: harden one content workflow, prove one publish gate, and connect the page to checkout or team intake instead of shipping more ungoverned AI content.',
    ]],
  ],
  faq: [
    [
      'Should ThumbGate build SEO agents?',
      'ThumbGate should govern SEO agents first. The product value is making skills, workspaces, and publish checks enforceable before generated pages or edits go live.',
    ],
    [
      'What is the first SEO-agent gate to implement?',
      'Start with proof and semantic mesh: block pages that lack verification links, current pricing, related internal links, and a concrete conversion path.',
    ],
  ],
  relatedPaths: ['/guides/semantic-programmatic-seo-guardrails', '/guides/ai-search-topical-presence', '/compare/fallow'],
});

function buildSeoAgentSkillsGuide() {
  return guideBlueprint({
    ...SEO_AGENT_SKILLS_GUARDRAILS_SPEC.meta,
    path: `/guides/${SEO_AGENT_SKILLS_GUARDRAILS_SPEC.slug}`,
    pillar: 'seo-governance',
    takeaways: SEO_AGENT_SKILLS_GUARDRAILS_SPEC.takeaways,
    sections: SEO_AGENT_SKILLS_GUARDRAILS_SPEC.sections.map(([kind, heading, entries]) => buildSectionFromSpec(kind, heading, entries)),
    faq: SEO_AGENT_SKILLS_GUARDRAILS_SPEC.faq.map(([question, text]) => answer(question, text)),
    relatedPaths: SEO_AGENT_SKILLS_GUARDRAILS_SPEC.relatedPaths,
  });
}

const CLAUDE_CODE_SKILLS_GUARDRAILS_SPEC = Object.freeze({
  slug: 'claude-code-skills-guardrails',
  meta: {
    query: 'claude code masterclass guardrails',
    title: 'Claude Code Skills Guardrails | Turn Skillbooks Into Enforced Workflows',
    heroTitle: 'Claude Code Skills Need Pre-Action Enforcement',
    heroSummary: 'Claude Code skillbooks make recurring work more systematic, but markdown skills are still advisory. ThumbGate turns skill feedback into reusable rules, tests, and pre-action checks before the next risky command or edit runs.',
  },
  takeaways: [
    'A living skillbook is useful acquisition fuel because new Claude Code users need reusable workflows immediately.',
    'The high-ROI product move is not another prompt file; it is converting named skills into gates, tests, and proof loops.',
    'This creates a clear post-course offer: install ThumbGate after learning Claude Code so the new automation does not repeat costly mistakes.',
  ],
  sections: [
    ['paragraphs', 'Why this helps ThumbGate', [
      'Claude Code education expands the market. More people learning to automate code means more people about to hit repeated mistakes, risky shell commands, skipped tests, and vague project rules.',
      'ThumbGate can be the safety kit for that moment: keep the skillbook, but promote every painful correction into an enforced pre-action check.',
    ]],
    ['bullets', 'High-ROI workflow to ship', [
      'Create a repo skillbook with named skills for refactors, tests, migrations, CI hardening, and prompt/tool changes.',
      'Require each skill to name inputs, forbidden actions, verification steps, and examples of good and bad execution.',
      'Capture thumbs-down failures from skill use and promote repeat patterns into ThumbGate prevention rules.',
      'Block risky actions when the current task claims a skill but skips its required verification.',
      'Route buyers into the Workflow Hardening Sprint when one skill repeatedly fails in a shared repo.',
    ]],
    ['paragraphs', 'Where this creates revenue', [
      'This is a concrete sales bridge from Claude Code training content to ThumbGate: if a team is investing in skills, they already believe AI coding workflows can improve. ThumbGate sells the part that makes those workflows reliable across sessions and teammates.',
    ]],
  ],
  faq: [
    [
      'Does ThumbGate replace Claude skills?',
      'No. Skills describe how work should happen. ThumbGate checks whether the agent is allowed to take the next action and whether it has followed the skill evidence requirements.',
    ],
    [
      'What should a Claude Code skillbook contain?',
      'Use named skills with purpose, inputs, do/don’t rules, verification commands, expected evidence, and examples. Then wire repeated failures into ThumbGate gates.',
    ],
  ],
  relatedPaths: ['/guides/claude-code-feedback', '/guides/prompt-tricks-to-workflow-rules', '/guides/pre-action-checks'],
});

function buildClaudeCodeSkillsGuide() {
  return guideBlueprint({
    ...CLAUDE_CODE_SKILLS_GUARDRAILS_SPEC.meta,
    path: `/guides/${CLAUDE_CODE_SKILLS_GUARDRAILS_SPEC.slug}`,
    pillar: 'agent-workflows',
    takeaways: CLAUDE_CODE_SKILLS_GUARDRAILS_SPEC.takeaways,
    sections: CLAUDE_CODE_SKILLS_GUARDRAILS_SPEC.sections.map(([kind, heading, entries]) => buildSectionFromSpec(kind, heading, entries)),
    faq: CLAUDE_CODE_SKILLS_GUARDRAILS_SPEC.faq.map(([question, text]) => answer(question, text)),
    relatedPaths: CLAUDE_CODE_SKILLS_GUARDRAILS_SPEC.relatedPaths,
  });
}

const LONG_RUNNING_AGENT_CONTEXT_GUIDE_SPEC = Object.freeze({
  slug: 'long-running-agent-context-management',
  meta: {
    query: 'long running agent context management',
    title: 'Long-Running Agent Context Management | Director Journals and Critic Reviews',
    heroTitle: 'Long-Running Agents Need Structured Memory, Not Raw Chat Logs',
    heroSummary: 'Slack\'s long-running multi-agent pattern points to director journals, critic reviews, and credibility-scored timelines. ThumbGate turns those context channels into pre-action checks before background agents, revenue loops, or investigations drift.',
  },
  takeaways: [
    'Long-running agents should not rely on accumulated chat logs once requests and output grow across many rounds.',
    'Director journals keep structured working memory; critic reviews score evidence; timelines deduplicate and resolve conflicts.',
    'ThumbGate now exposes npx thumbgate long-running-agent-context-guardrails to gate missing structured memory before handoff or action.',
  ],
  sections: [
    ['paragraphs', 'Why this helps ThumbGate', [
      'This maps directly to Ralph Loop, reply orchestration, background PRs, and revenue automation. The longer the loop runs, the more dangerous raw history becomes as the source of truth.',
      'ThumbGate can sell the control layer: journal the decisions, review findings with evidence, score credibility, and block external actions when the agent is building on unreviewed memory.',
    ]],
    ['bullets', 'High-ROI context gates', [
      'Require a director journal for observations, decisions, questions, hypotheses, and open risks.',
      'Require critic review with credibility scores before expert findings become shared memory.',
      'Checkpoint the critic timeline when duplicates, stale claims, or conflicts remain unresolved.',
      'CLI path: npx thumbgate long-running-agent-context-guardrails --request-count=80 --output-mb=3 --raw-chat-only --json.',
    ]],
    ['paragraphs', 'Where this creates revenue', [
      'This is an enterprise-quality story for teams moving from one-off assistants to persistent agents. ThumbGate hardens one long-running workflow and proves that it can maintain truth across sessions before the agent reaches production authority.',
    ]],
  ],
  faq: [
    [
      'Why not just keep the whole chat history?',
      'Because raw history grows until it wastes context, creates stale truth, and degrades reasoning. Structured memory keeps the useful state without passing every token forever.',
    ],
    [
      'What should a long-running agent persist?',
      'Persist a director journal, critic-reviewed findings with credibility scores, and a deduplicated timeline that resolves conflicts by strongest evidence.',
    ],
  ],
  relatedPaths: ['/guides/background-agent-governance', '/guides/agent-harness-optimization', '/guides/pre-action-checks'],
});

function buildLongRunningAgentContextGuide() {
  return preActionGuide(LONG_RUNNING_AGENT_CONTEXT_GUIDE_SPEC.slug, {
    ...LONG_RUNNING_AGENT_CONTEXT_GUIDE_SPEC.meta,
    takeaways: LONG_RUNNING_AGENT_CONTEXT_GUIDE_SPEC.takeaways,
    sections: LONG_RUNNING_AGENT_CONTEXT_GUIDE_SPEC.sections.map(([kind, heading, entries]) => buildSectionFromSpec(kind, heading, entries)),
    faq: LONG_RUNNING_AGENT_CONTEXT_GUIDE_SPEC.faq.map(([question, text]) => answer(question, text)),
    relatedPaths: LONG_RUNNING_AGENT_CONTEXT_GUIDE_SPEC.relatedPaths,
  });
}

const REASONING_COMPRESSION_GUARDRAILS_SPEC = Object.freeze({
  slug: 'reasoning-compression-guardrails',
  meta: {
    query: 'reasoning compression guardrails',
    title: 'Reasoning Compression Guardrails | Step-Level Verifier Checks Before Token Savings',
    heroTitle: 'Reasoning Compression Needs Step-Level Safety Checks',
    heroSummary: 'Efficient reasoning can reduce token cost, but short traces can destabilize accuracy. ThumbGate gates reasoning compression with verifier outcomes, pass@1 baselines, low-confidence step review, and high-confidence failure inspection.',
  },
  takeaways: [
    'Reasoning compression is only ROI-positive when quality survives the token savings.',
    'Step-level confidence matters because correct final answers can still contain brittle intermediate steps.',
    'ThumbGate now exposes npx thumbgate reasoning-efficiency-guardrails for verifier-backed model routing and prompt-eval workflows.',
  ],
  sections: [
    ['paragraphs', 'Why this helps ThumbGate', [
      'This creates a model-cost governance story: ThumbGate can help teams route cheaper, shorter reasoning only when a verifier proves the compressed trace is still safe.',
      'The same mechanism also protects DPO/RLHF export and model-evaluation workflows from rewarding or punishing the wrong reasoning steps.',
    ]],
    ['bullets', 'High-ROI reasoning gates', [
      'Require verifier and pass@1 evidence before compressing reasoning traces.',
      'Checkpoint low-confidence steps even in correct rollouts before reinforcing them.',
      'Checkpoint high-confidence failed rollouts for truncation or verifier noise before penalizing them.',
      'CLI path: npx thumbgate reasoning-efficiency-guardrails --baseline-tokens=1200 --compressed-tokens=980 --baseline-accuracy=0.84 --compressed-accuracy=0.85 --verifier --json.',
    ]],
    ['paragraphs', 'Where this creates revenue', [
      'This improves the Pro and Team model-hardening story. Buyers can save inference cost and evaluation time without turning "shorter reasoning" into an unmeasured reliability regression.',
    ]],
  ],
  faq: [
    [
      'Should every agent use shorter reasoning traces?',
      'No. Compress traces only when verifier outcomes and accuracy baselines prove the shorter route still works for the workload.',
    ],
    [
      'How does ThumbGate use step-level reasoning signals?',
      'ThumbGate does not train the model directly. It gates routing, exports, and workflow decisions when low-confidence steps, high-confidence failures, or missing verifier evidence make compression risky.',
    ],
  ],
  relatedPaths: ['/guides/gpt-5-5-model-evaluation', '/guides/agent-harness-optimization', '/guides/pre-action-checks'],
});

function buildReasoningCompressionGuide() {
  return preActionGuide(REASONING_COMPRESSION_GUARDRAILS_SPEC.slug, {
    ...REASONING_COMPRESSION_GUARDRAILS_SPEC.meta,
    takeaways: REASONING_COMPRESSION_GUARDRAILS_SPEC.takeaways,
    sections: REASONING_COMPRESSION_GUARDRAILS_SPEC.sections.map(([kind, heading, entries]) => buildSectionFromSpec(kind, heading, entries)),
    faq: REASONING_COMPRESSION_GUARDRAILS_SPEC.faq.map(([question, text]) => answer(question, text)),
    relatedPaths: REASONING_COMPRESSION_GUARDRAILS_SPEC.relatedPaths,
  });
}

const DEEPSEEK_V4_RUNTIME_GUARDRAILS_SPEC = Object.freeze({
  slug: 'deepseek-v4-runtime-guardrails',
  meta: {
    query: 'deepseek v4 runtime guardrails',
    title: 'DeepSeek V4 Runtime Guardrails | Sparse Attention, Speculation, and Verified RL',
    heroTitle: 'DeepSeek-V4 Needs Runtime Guardrails Before Production Routing',
    heroSummary: 'DeepSeek-V4 introduces long-context sparse attention, speculative decoding, KV offload, FP4/FP8 paths, and verified-RL replay concerns. ThumbGate turns those runtime signals into pre-action checks before model-routing or training changes go live.',
  },
  takeaways: [
    'The high-ROI move is not blindly switching models; it is benchmarking DeepSeek-V4 behind cache, speculation, precision, and replay gates.',
    'Hybrid sparse attention changes prefix-cache assumptions, so cache coherence and rollback evidence must exist before routing long traces.',
    'ThumbGate now exposes npx thumbgate deepseek-v4-runtime-guardrails for self-hosted long-context model rollouts.',
  ],
  sections: [
    ['paragraphs', 'Why this helps ThumbGate', [
      'Teams adopting SGLang-style DeepSeek-V4 serving are exactly the buyers who need agent governance: they are optimizing cost and throughput while increasing context length and system complexity.',
      'ThumbGate can sit above the runtime as the policy layer that blocks unsafe routing changes, requires benchmark proof, and keeps self-hosted model experiments from becoming invisible production risk.',
    ]],
    ['bullets', 'High-ROI runtime gates', [
      'Require hybrid prefix-cache coherence eval before enabling long-context cache reuse.',
      'Checkpoint speculative decoding acceptance length, rollback behavior, and correctness before treating it as a speedup.',
      'Require long-context KV capacity and offload plans before 128k+ or 1M-token routing.',
      'Require rollout routing replay, indexer replay, and train-inference drift checks before RL or fine-tuning updates.',
      'Checkpoint FP4/FP8 mixed-precision determinism before benchmark results update routing.',
      'CLI path: npx thumbgate deepseek-v4-runtime-guardrails --context-tokens=900000 --hybrid-attention --speculative-decoding --accept-length=1.4 --precision-mode=fp8 --json.',
    ]],
    ['paragraphs', 'Where this creates revenue', [
      'This gives ThumbGate a serious infrastructure story for teams moving beyond hosted APIs. The offer is a Workflow Hardening Sprint around one model-routing lane: prove the runtime change, gate the risks, and keep the agent from silently routing expensive work through an unverified path.',
    ]],
  ],
  faq: [
    [
      'Should ThumbGate switch to DeepSeek-V4 by default?',
      'No. Treat DeepSeek-V4 as a candidate for self-hosted long-context workloads. Route to it only after ThumbGate benchmarks pass for quality, cache coherence, latency, cost, and rollback behavior.',
    ],
    [
      'What is different about DeepSeek-V4 governance?',
      'The risk is not only model quality. Hybrid sparse attention, speculative decoding, KV offload, mixed precision, and RL replay can all create silent runtime failures unless each change is gated with evidence.',
    ],
  ],
  relatedPaths: ['/guides/reasoning-compression-guardrails', '/guides/long-running-agent-context-management', '/guides/gpt-5-5-model-evaluation'],
});

function buildDeepSeekV4RuntimeGuide() {
  return preActionGuide(DEEPSEEK_V4_RUNTIME_GUARDRAILS_SPEC.slug, {
    ...DEEPSEEK_V4_RUNTIME_GUARDRAILS_SPEC.meta,
    takeaways: DEEPSEEK_V4_RUNTIME_GUARDRAILS_SPEC.takeaways,
    sections: DEEPSEEK_V4_RUNTIME_GUARDRAILS_SPEC.sections.map(([kind, heading, entries]) => buildSectionFromSpec(kind, heading, entries)),
    faq: DEEPSEEK_V4_RUNTIME_GUARDRAILS_SPEC.faq.map(([question, text]) => answer(question, text)),
    relatedPaths: DEEPSEEK_V4_RUNTIME_GUARDRAILS_SPEC.relatedPaths,
  });
}

const CODE_KNOWLEDGE_GRAPH_GUARDRAILS_SPEC = Object.freeze({
  slug: 'code-knowledge-graph-guardrails',
  meta: {
    query: 'code knowledge graph guardrails',
    title: 'Code Knowledge Graph Guardrails | ThumbGate Guide',
    heroTitle: 'Code Graphs Are Context. ThumbGate Is Execution Control.',
    heroSummary: 'Code knowledge graphs help AI coding agents understand files, functions, dependencies, and architecture layers. ThumbGate turns those graph signals into pre-action checks before risky edits, commands, deploys, or publishes execute.',
  },
  takeaways: [
    'Code graphs explain what the system is; pre-action gates decide what the agent is allowed to do next.',
    'The fastest rollout is three graph-informed checks: central-file impact review, cross-layer refactor checkpointing, and generated-graph artifact protection.',
    'This positions graph tools as complementary context while making ThumbGate the enforcement layer buyers still need.',
  ],
  sections: [
    ['paragraphs', 'Why this became a buyer question', [
      'Understand Anything and code-graph MCPs are making architecture maps easier to generate. That helps agents stop reading code blind, but it does not automatically govern the next tool call.',
      'A graph can say a file is central, a refactor crosses layers, or a generated graph artifact should not be edited. ThumbGate turns those signals into allow, warn, or block decisions before execution.',
    ]],
    ['bullets', 'High-ROI gate templates', [
      'CLI path: npx thumbgate code-graph-guardrails --central-files=src/api/server.js --layers=api,data --generated-artifacts=.codegraph/index.json --json.',
      'Require diff impact before central edits: block writes to high-centrality files until the agent has reviewed blast radius.',
      'Checkpoint cross-layer refactors: warn before one run changes API, service, data, and UI layers together.',
      'Protect generated graph artifacts: block manual edits to graph outputs that should be regenerated from source.',
    ]],
    ['paragraphs', 'Where this creates revenue', [
      'This is a strong engagement wedge for audiences already excited about codebase understanding. The public line is simple: Code graphs tell the agent what the system is; ThumbGate decides what the agent is allowed to do next.',
      'For teams, sell the Workflow Hardening Sprint around one graph-informed repeated failure: one central file, one risky refactor path, or one generated artifact that agents keep touching incorrectly.',
    ]],
  ],
  faq: [
    ['Does ThumbGate build the code knowledge graph?', 'No. ThumbGate can work alongside graph tools by consuming their risk signals as policy context. The graph supplies structure; ThumbGate enforces the next action.'],
    ['What should I gate first after generating a code graph?', 'Start with high-centrality files, cross-layer refactors, and generated graph artifacts. Those are narrow enough to enforce quickly and risky enough to create real ROI.'],
    ['Is this a replacement for architecture documentation?', 'No. It turns architecture context into runtime enforcement so the agent cannot ignore the risk signals it just discovered.'],
  ],
  relatedPaths: ['/guides/pre-action-checks', '/guides/agent-harness-optimization', '/guides/best-tools-stop-ai-agents-breaking-production'],
});

function buildCodeKnowledgeGraphGuardrailsGuide() {
  return preActionGuide(CODE_KNOWLEDGE_GRAPH_GUARDRAILS_SPEC.slug, {
    ...CODE_KNOWLEDGE_GRAPH_GUARDRAILS_SPEC.meta,
    takeaways: CODE_KNOWLEDGE_GRAPH_GUARDRAILS_SPEC.takeaways,
    sections: CODE_KNOWLEDGE_GRAPH_GUARDRAILS_SPEC.sections.map(([kind, heading, entries]) => buildSectionFromSpec(kind, heading, entries)),
    faq: CODE_KNOWLEDGE_GRAPH_GUARDRAILS_SPEC.faq.map(([question, text]) => answer(question, text)),
    relatedPaths: CODE_KNOWLEDGE_GRAPH_GUARDRAILS_SPEC.relatedPaths,
  });
}

const DEVELOPER_MACHINE_SUPPLY_CHAIN_GUARDRAILS_SPEC = Object.freeze({
  slug: 'developer-machine-supply-chain-guardrails',
  meta: {
    query: 'developer machine supply chain guardrails',
    title: 'Developer Machine Supply Chain Guardrails | ThumbGate Guide',
    heroTitle: 'Stop AI Assistants From Amplifying Supply-Chain Attacks.',
    heroSummary: 'Developer laptops and CI runners hold tokens, package-manager trust, and one-shot CLI install paths. ThumbGate turns that local execution risk into pre-action gates before an agent runs npm, PyPI, Docker, or shell commands that can expose credentials.',
  },
  takeaways: [
    'Secrets scanners find leaks; ThumbGate blocks the agent behavior that creates or amplifies them.',
    'Supply Chain Safety templates should start with package lifecycle scripts, untrusted one-shot CLI installers, dependency autofixes, and credential exposure assessment.',
    'This is complementary to GitGuardian, endpoint security, and incident response because it governs the next local action.',
  ],
  sections: [
    ['paragraphs', 'Why developer machines are now the blast radius', [
      'A compromised package does not need to break production directly. It can read .env, .npmrc, .pypirc, Docker config, SSH keys, and cloud tokens while an AI coding assistant repeats the trusted-looking command across more repos.',
      'The high-ROI control is local and specific: detect risky execution before it runs, require review where exposure is plausible, and promote every missed incident into a durable ThumbGate rule.',
    ]],
    ['bullets', 'High-ROI gate templates', [
      'Block package lifecycle secret harvest: stop install, postinstall, prepare, and similar scripts from reading local credential surfaces.',
      'Review untrusted CLI before execution: block curl-to-shell flows, unknown npx commands, uvx, and pipx run until the source and permissions are reviewed.',
      'Checkpoint dependency bot autofix: warn before Dependabot, Renovate, audit-fix, Docker pull, or broad package updates expand the trusted code surface.',
      'Require credential exposure assessment: force an answer about what credential lived where, what executed, and whether rotation is required.',
    ]],
    ['paragraphs', 'Where this creates revenue', [
      'This is a strong security wedge for teams that already run scanners but still let agents execute local install/update commands. The offer is not "replace your scanner"; it is "connect scanner and incident lessons to pre-action enforcement."',
      'For the Workflow Hardening Sprint, pick one concrete local-risk pattern: package lifecycle scripts, one-shot installers, dependency bot autofixes, or unresolved credential exposure after a suspected compromise.',
    ]],
  ],
  faq: [
    ['Does ThumbGate replace secrets scanning?', 'No. Secrets scanners tell you what leaked. ThumbGate blocks or checkpoints the agent behavior that can create or amplify the leak before execution.'],
    ['Which supply-chain gate should teams enable first?', 'Start with one-shot CLI installers and package lifecycle scripts because those paths can execute before a human sees the diff.'],
    ['Can this work with existing incident-response tools?', 'Yes. Use scanner, EDR, and incident-response findings as evidence, then turn the repeated local action pattern into a ThumbGate pre-action rule.'],
  ],
  relatedPaths: ['/guides/pre-action-checks', '/guides/code-knowledge-graph-guardrails', '/guides/best-tools-stop-ai-agents-breaking-production'],
});

function buildDeveloperMachineSupplyChainGuardrailsGuide() {
  return preActionGuide(DEVELOPER_MACHINE_SUPPLY_CHAIN_GUARDRAILS_SPEC.slug, {
    ...DEVELOPER_MACHINE_SUPPLY_CHAIN_GUARDRAILS_SPEC.meta,
    takeaways: DEVELOPER_MACHINE_SUPPLY_CHAIN_GUARDRAILS_SPEC.takeaways,
    sections: DEVELOPER_MACHINE_SUPPLY_CHAIN_GUARDRAILS_SPEC.sections.map(([kind, heading, entries]) => buildSectionFromSpec(kind, heading, entries)),
    faq: DEVELOPER_MACHINE_SUPPLY_CHAIN_GUARDRAILS_SPEC.faq.map(([question, text]) => answer(question, text)),
    relatedPaths: DEVELOPER_MACHINE_SUPPLY_CHAIN_GUARDRAILS_SPEC.relatedPaths,
  });
}

const PROMPT_TRICKS_TO_WORKFLOW_RULES_SPEC = Object.freeze({
  slug: 'prompt-tricks-to-workflow-rules',
  meta: {
    query: 'prompt tricks to workflow rules',
    title: 'Prompt Tricks Are Not Enough | Turn AI Instructions Into Workflow Rules',
    heroTitle: 'Prompt Tricks Are Table Stakes. Workflow Rules Make Them Pay.',
    heroSummary: 'Clear prompts and examples help modern AI tools, but they do not stop the same failure from recurring. ThumbGate turns one messy agent workflow into rules, examples, and pre-action checks before the next tool call executes.',
  },
  takeaways: [
    'Politeness, threats, flattery, and clever prompt rituals are unreliable leverage; clear task shape, examples, and verification are the durable parts.',
    'The paid layer is enforcement: convert repeated mistakes into durable rules that run before an agent acts.',
    'The fastest revenue offer is a $99 workflow diagnostic that turns one messy AI workflow into clear instructions, examples, and pre-action checks.',
  ],
  sections: [
    ['paragraphs', 'Why this became a buyer question', [
      'Teams have learned that better prompts can reduce ambiguity, but a prompt still relies on the model remembering and obeying every constraint at the exact moment it matters.',
      'That is where ThumbGate fits. Keep prompts clear and neutral, then promote the failure patterns into local checks that can warn or block before shell commands, file edits, browser actions, or deploy steps run.',
    ]],
    ['bullets', 'High-ROI conversion steps', [
      'Capture one repeated failure: the agent edits the wrong file, runs a risky command, invents an import, skips verification, or reopens a resolved loop.',
      'Write the smallest clear rule: describe the allowed action, the blocked action, and one concrete example of each.',
      'Attach a pre-action check: run the rule before the tool call, not after the agent has already spent tokens or changed files.',
      'Verify with proof: record the next prevented action, the saved remediation time, and the narrower rule created from feedback.',
    ]],
    ['paragraphs', 'Where this creates revenue', [
      'This turns generic prompt advice into a buyer-ready diagnostic. The public offer is simple: send one messy AI-agent workflow and ThumbGate turns it into clear rules, examples, and pre-action checks.',
      'For teams, position the Workflow Hardening Sprint around the repeated failure they can already name. The deliverable is not a better pep talk for the model; it is enforcement that survives across sessions and agents.',
    ]],
  ],
  faq: [
    ['Do better prompts still matter?', 'Yes. Clear prompts and examples reduce ambiguity. ThumbGate starts where prompts stop: enforcing repeated lessons before the next action executes.'],
    ['What prompt tactics should teams stop wasting time on?', 'Do not rely on politeness, threats, flattery, or roleplay as control mechanisms. Use clear instructions, concrete examples, neutral constraints, and verification gates.'],
    ['What should a $99 workflow diagnostic produce?', 'One repeated failure translated into a rule, one good and bad example, one pre-action check, and a short verification plan for proving the check paid for itself.'],
  ],
  relatedPaths: ['/guides/pre-action-checks', '/guides/agent-harness-optimization', '/guides/best-tools-stop-ai-agents-breaking-production'],
});

function buildPromptTricksToWorkflowRulesGuide() {
  return preActionGuide(PROMPT_TRICKS_TO_WORKFLOW_RULES_SPEC.slug, {
    ...PROMPT_TRICKS_TO_WORKFLOW_RULES_SPEC.meta,
    takeaways: PROMPT_TRICKS_TO_WORKFLOW_RULES_SPEC.takeaways,
    sections: PROMPT_TRICKS_TO_WORKFLOW_RULES_SPEC.sections.map(([kind, heading, entries]) => buildSectionFromSpec(kind, heading, entries)),
    faq: PROMPT_TRICKS_TO_WORKFLOW_RULES_SPEC.faq.map(([question, text]) => answer(question, text)),
    relatedPaths: PROMPT_TRICKS_TO_WORKFLOW_RULES_SPEC.relatedPaths,
  });
}

const BACKGROUND_AGENT_GOVERNANCE_GUIDE_SPEC = Object.freeze({
  slug: 'background-agent-governance',
  meta: {
    query: 'background agent governance',
    title: 'Background Agent Governance | Risk-Tiered Review for Agent PRs',
    heroTitle: 'Background Agent Governance for Agent PRs',
    heroSummary: 'Background agents can draft changes while humans work elsewhere, but review becomes the bottleneck. ThumbGate adds pre-dispatch checks, run reports, isolated task lanes, and evidence-backed review routing before unattended agent work piles up.',
  },
  takeaways: [
    'Background agents need a real run ledger, not just a pile of PRs.',
    'The highest ROI control is risk-tiered review: stricter checks for protected branches, high-failure agents, and large blast-radius changes.',
    'ThumbGate turns CI failures and human review feedback into Pre-Action Checks so the same failed agent pattern gets blocked before the next run.',
  ],
  sections: [
    ['paragraphs', 'Why this became urgent', [
      'Teams are moving from local agent sessions to unattended background work. That changes the review problem: humans no longer inspect one assistant transcript at a time; they receive a queue of agent-created branches, PRs, and CI failures.',
      'If context alignment happens in Slack, Linear, Jira, or a planning thread, the agent run also needs a durable record of what was agreed, where it executed, which gates fired, and what evidence came back.',
    ]],
    ['bullets', 'What ThumbGate adds', [
      'A background-agent run ledger with agent ID, source, branch, PR number, gate counts, CI outcome, and changed-file count.',
      'A pre-dispatch governance check for high-failure agents, protected branches, and large blast-radius runs.',
      'Post-run audit that can convert CI failures into structured thumbs-down feedback and future prevention rules.',
      'A report command for review queues: npx thumbgate background-governance --json.',
      'A risk check command for dispatch systems: npx thumbgate background-governance --check --agent-id=builder --branch=main --files-changed=25 --json.',
    ]],
    ['paragraphs', 'Where this creates revenue', [
      'This is a clean Workflow Hardening Sprint wedge. The buyer does not need a broad platform migration; they need one background-agent workflow hardened from context intake to isolated execution to risk-tiered review.',
      'The promise stays honest: ThumbGate does not remove human review. It makes the review queue smaller, better labeled, and backed by evidence before a risky agent PR reaches a reviewer.',
    ]],
  ],
  faq: [
    [
      'Does ThumbGate replace human review for background agents?',
      'No. ThumbGate reduces review load by blocking known bad actions earlier, warning on risky dispatches, and attaching run evidence so humans can focus on high-risk changes.',
    ],
    [
      'What should teams check before dispatching a background agent?',
      'Check recent agent failure rate, prior gate blocks, target branch, expected blast radius, isolated execution environment, CI expectations, and the human context that authorized the task.',
    ],
    [
      'How does this connect to the Workflow Hardening Sprint?',
      'The sprint can harden one background-agent workflow end to end: context intake, pre-dispatch governance, sandbox routing, CI audit, prevention rules, and proof review.',
    ],
  ],
  relatedPaths: ['/guides/pre-action-checks', '/guides/agent-harness-optimization', '/guides/best-tools-stop-ai-agents-breaking-production'],
});

function buildBackgroundAgentGovernanceGuide() {
  return preActionGuide(BACKGROUND_AGENT_GOVERNANCE_GUIDE_SPEC.slug, {
    ...BACKGROUND_AGENT_GOVERNANCE_GUIDE_SPEC.meta,
    takeaways: BACKGROUND_AGENT_GOVERNANCE_GUIDE_SPEC.takeaways,
    sections: BACKGROUND_AGENT_GOVERNANCE_GUIDE_SPEC.sections.map(([kind, heading, entries]) => buildSectionFromSpec(kind, heading, entries)),
    faq: BACKGROUND_AGENT_GOVERNANCE_GUIDE_SPEC.faq.map(([question, text]) => answer(question, text)),
    relatedPaths: BACKGROUND_AGENT_GOVERNANCE_GUIDE_SPEC.relatedPaths,
  });
}

const AI_AGENT_GOVERNANCE_SPRINT_GUIDE_SPEC = Object.freeze({
  slug: 'ai-agent-governance-sprint',
  meta: {
    query: 'ai agent governance sprint',
    title: 'AI Agent Governance Sprint | 48-Hour Workflow Hardening',
    heroTitle: 'AI Agent Governance Sprint for One Risky Workflow',
    heroSummary: 'ThumbGate turns one repeated AI-agent failure into approval boundaries, pre-action checks, rollback safety, and rollout proof in a focused 48-hour Workflow Hardening Sprint.',
  },
  takeaways: [
    'The fastest paid wedge is not a broad platform migration; it is one repo, one workflow owner, and one repeated failure that already has budget pressure.',
    'A governance sprint should ship evidence: rule inventory, pre-action checks, review routing, rollback notes, and a buyer-ready proof pack.',
    'ThumbGate keeps the promise narrow enough to sell quickly while creating the path to Team seats and recurring governance.',
  ],
  sections: [
    ['paragraphs', 'Who this is for', [
      'The right buyer is already running Claude Code, Codex, Cursor, Gemini, or another agent against real code and has one failure they no longer want to review manually. Examples include unsafe migrations, noisy background-agent PRs, deploy approval bypasses, credential-adjacent commands, and repeated generated-artifact edits.',
      'The sprint works because it avoids generic AI consulting. The scope is one workflow that can be observed, hardened, and reviewed in front of the buyer before a wider team rollout.',
    ]],
    ['bullets', 'What the sprint ships', [
      'Intake: one repo, one owner, one repeated failure, one target rollout date, and the current agent/runtime surface.',
      'Governance map: approval boundaries, risky commands, protected files, branch rules, review tiers, and rollback expectations.',
      'Pre-action checks: concrete blocks or warnings for the repeated failure and adjacent high-risk actions.',
      'Background-agent review routing: npx thumbgate background-governance --check --json to label risk before dispatch or PR review.',
      'Proof pack: verification evidence, run reports, blocked-repeat examples, and rollout notes the buyer can share internally.',
    ]],
    ['paragraphs', 'Where this creates ROI', [
      'This page is the service conversion layer for the governance guides. Readers who already understand background-agent risk need a next step that is smaller than procurement and more concrete than a demo.',
      'The offer stays defensible: ThumbGate does not claim to make agents autonomous without review. It makes one expensive review failure measurable, enforceable, and easier to roll out across Team seats.',
    ]],
  ],
  faq: [
    [
      'What is included in the AI Agent Governance Sprint?',
      'A focused 48-hour implementation around one workflow: intake, governance mapping, pre-action checks, background-agent risk routing, rollback notes, and a proof pack for the buyer review.',
    ],
    [
      'How is this different from the Workflow Hardening Sprint?',
      'It is the same Team conversion path positioned for buyers searching for AI agent governance. The deliverable remains narrow: one repeated failure hardened with approval boundaries, rollback safety, and rollout proof.',
    ],
    [
      'Do we need to migrate every agent workflow first?',
      'No. Start with one repeated failure that already costs review time or rollout confidence. After it proves value, reuse the checks, lesson database, and proof workflow across Team seats.',
    ],
  ],
  relatedPaths: ['/guides/background-agent-governance', '/guides/pre-action-checks', '/guides/best-tools-stop-ai-agents-breaking-production'],
});

function buildAiAgentGovernanceSprintGuide() {
  return {
    ...preActionGuide(AI_AGENT_GOVERNANCE_SPRINT_GUIDE_SPEC.slug, {
      ...AI_AGENT_GOVERNANCE_SPRINT_GUIDE_SPEC.meta,
      takeaways: AI_AGENT_GOVERNANCE_SPRINT_GUIDE_SPEC.takeaways,
      sections: AI_AGENT_GOVERNANCE_SPRINT_GUIDE_SPEC.sections.map(([kind, heading, entries]) => buildSectionFromSpec(kind, heading, entries)),
      faq: AI_AGENT_GOVERNANCE_SPRINT_GUIDE_SPEC.faq.map(([question, text]) => answer(question, text)),
      relatedPaths: AI_AGENT_GOVERNANCE_SPRINT_GUIDE_SPEC.relatedPaths,
    }),
    cta: {
      label: 'Start the governance sprint',
      href: '/?utm_source=website&utm_medium=seo_page&utm_campaign=ai_agent_governance_sprint&cta_placement=seo_brief&plan_id=team#workflow-sprint-intake',
    },
  };
}

const AI_DEPLOYMENT_READINESS_GUIDE_SPEC = Object.freeze({
  slug: 'ai-deployment-readiness',
  meta: {
    query: 'ai deployment readiness',
    title: 'AI Deployment Readiness | Production Workflow Gates Before Rollout',
    heroTitle: 'AI Deployment Readiness Before Agents Touch Production',
    heroSummary: 'Deployment-company demand proves the buyer problem: teams need help moving AI into real workflows. ThumbGate is the governance and proof layer that makes one priority workflow ready for production with pre-action gates, rollout evidence, and paid sprint paths.',
  },
  takeaways: [
    'AI deployment readiness is about workflow controls, not just prompts, demos, or model selection.',
    'The high-ROI starting point is one priority workflow with mapped tools, data, owners, risky actions, and proof-backed gates.',
    'ThumbGate turns deployment demand into revenue through a $499 diagnostic, a $1500 Workflow Hardening Sprint, and Team seats at $49/seat/mo.',
  ],
  sections: [
    ['paragraphs', 'Why deployment is now the buying category', [
      'OpenAI-style deployment companies validate a practical market shift: buyers do not only want a model or chatbot. They want AI systems embedded into messy production workflows where data, tools, approvals, and rollback paths already exist.',
      'That creates a clean ThumbGate wedge. A forward deployment team can map the workflow and build the automation; ThumbGate defines what the automation is allowed to execute, what evidence must exist before it acts, and what proof the buyer can review after rollout.',
    ]],
    ['bullets', 'What ThumbGate adds to AI deployment readiness', [
      'Intake for one workflow owner, one priority workflow, one repeated failure, and one production rollout target.',
      'A governance map for data access, tools, protected files, risky commands, approval boundaries, review tiers, and rollback expectations.',
      'Pre-action gates that stop repeated mistakes before the next shell command, PR, release, or production automation step.',
      'Background-agent risk checks through npx thumbgate background-governance --check --json before unattended work reaches review.',
      'A proof pack with blocked-repeat examples, run evidence, verification notes, and rollout decisions the buyer can share internally.',
    ]],
    ['paragraphs', 'How this makes money', [
      'The page should convert deployment curiosity into concrete buying motion. The $499 Workflow Hardening Diagnostic validates one repeated failure and produces a readiness map. The $1500 sprint implements the first gates and proof pack. Team seats expand the same enforcement path across more repos and workflow owners.',
      'This keeps the offer honest. ThumbGate does not claim to be the deployment company or a generic AI consultancy. It is the enforcement, governance, and proof layer that lets deployment work survive contact with production.',
    ]],
  ],
  faq: [
    [
      'Is ThumbGate competing with AI deployment companies?',
      'No. Deployment companies help buyers embed AI into real operations. ThumbGate complements that work by adding the governance and proof layer before AI agents or automations touch production systems.',
    ],
    [
      'What should an AI deployment readiness audit produce?',
      'A useful audit should produce one workflow map, named owners, tool and data boundaries, risky actions, approval rules, rollback expectations, pre-action gates, and proof that the first rollout can be reviewed.',
    ],
    [
      'Can this start before procurement?',
      'Yes. Start with one $499 diagnostic or the Workflow Hardening Sprint intake. The point is to prove one workflow before asking a buyer to fund a broad platform rollout.',
    ],
  ],
  relatedPaths: ['/guides/ai-agent-governance-sprint', '/guides/background-agent-governance', '/guides/pre-action-checks'],
});

function buildAiDeploymentReadinessGuide() {
  return {
    ...preActionGuide(AI_DEPLOYMENT_READINESS_GUIDE_SPEC.slug, {
      ...AI_DEPLOYMENT_READINESS_GUIDE_SPEC.meta,
      takeaways: AI_DEPLOYMENT_READINESS_GUIDE_SPEC.takeaways,
      sections: AI_DEPLOYMENT_READINESS_GUIDE_SPEC.sections.map(([kind, heading, entries]) => buildSectionFromSpec(kind, heading, entries)),
      faq: AI_DEPLOYMENT_READINESS_GUIDE_SPEC.faq.map(([question, text]) => answer(question, text)),
      relatedPaths: AI_DEPLOYMENT_READINESS_GUIDE_SPEC.relatedPaths,
    }),
    cta: {
      label: 'Start deployment readiness intake',
      href: '/?utm_source=website&utm_medium=seo_page&utm_campaign=ai_deployment_readiness&cta_placement=seo_brief&plan_id=team#workflow-sprint-intake',
    },
  };
}

const MODEL_UPGRADE_EVALUATION_GUIDE_SPEC = Object.freeze({
  slug: 'gpt-5-5-model-evaluation',
  meta: {
    query: 'gpt-5.5 model evaluation',
    title: 'GPT-5.5 Model Evaluation | Benchmark Before Routing Expensive Agent Work',
    heroTitle: 'Evaluate GPT-5.5 Before You Route Production Agent Work',
    heroSummary: 'Frontier-model upgrades can improve coding, dataset analysis, and dashboards, but the ROI comes from measured routing. ThumbGate adds a model-candidate workload so teams can benchmark GPT-5.5 against real feedback, gate evals, and dashboard-analysis criteria before changing defaults.',
  },
  takeaways: [
    'GPT-5.5 should be treated as a frontier candidate for complex work, not a blanket replacement for every cheap gate.',
    'The highest ROI path is benchmark-first routing: keep cheap tiers for simple checks and escalate dataset, dashboard, and long-context work when evidence supports it.',
    'ThumbGate now exposes a dashboard-analysis workload through npx thumbgate model-candidates --workload=dashboard-analysis --provider=openai --json.',
  ],
  sections: [
    ['paragraphs', 'What changed', [
      'OpenAI positions GPT-5.5 for complex reasoning, coding, data analysis, and tool-using work. Julius framed the same model around dataset analysis, charts, dashboards, insight quality, and code generation.',
      'For ThumbGate, the useful product move is not to rewrite every default. It is to make model adoption measurable: define the workload, pick candidate models, run existing evals, and route only the work that earns the frontier spend.',
    ]],
    ['bullets', 'What ThumbGate adds', [
      'A GPT-5.5 model candidate in config/model-candidates.json with long-context, data-analysis, dashboard-creation, charting, tool-use, and reliability strengths.',
      'A dashboard-analysis workload with metrics for insight accuracy, chart-spec validity, dashboard completeness, long-context reliability, latency, and cost per analysis.',
      'A CLI path: npx thumbgate model-candidates --workload=dashboard-analysis --provider=openai --json.',
      'A tier-router config that pins the frontier tier to gpt-5.5 while keeping explicit cheaper tiers for fast, low-cost work.',
    ]],
    ['paragraphs', 'Where this creates ROI', [
      'This gives platform teams a defensible answer to "should we move to GPT-5.5?" Run the candidate report, attach gate and benchmark evidence, and only then route high-value analytical or long-context agent tasks to the frontier tier.',
      'The commercial wedge is a Workflow Hardening Sprint focused on model routing: define which workflows deserve frontier spend, which stay on cheap tiers, and which require pre-action checks before a model can touch live systems.',
    ]],
  ],
  faq: [
    [
      'Should every ThumbGate task use GPT-5.5?',
      'No. Cheap gates, classification, extraction, and simple triage should stay on lower-cost tiers when they pass evals. GPT-5.5 is best evaluated for complex reasoning, long-context, coding, dataset, and dashboard work.',
    ],
    [
      'How do I benchmark GPT-5.5 in ThumbGate?',
      'Run npx thumbgate model-candidates --workload=dashboard-analysis --provider=openai --json, then use the emitted benchmark commands and metrics to compare insight quality, chart validity, latency, and cost before changing routing defaults.',
    ],
    [
      'Does this automatically call the OpenAI API?',
      'No. The catalog is an evaluation and routing surface. It records candidate models and benchmark plans without assuming provider credentials or silently changing runtime behavior.',
    ],
  ],
  relatedPaths: ['/guides/agent-harness-optimization', '/guides/background-agent-governance', '/guides/pre-action-checks'],
});

function buildModelUpgradeEvaluationGuide() {
  return preActionGuide(MODEL_UPGRADE_EVALUATION_GUIDE_SPEC.slug, {
    ...MODEL_UPGRADE_EVALUATION_GUIDE_SPEC.meta,
    takeaways: MODEL_UPGRADE_EVALUATION_GUIDE_SPEC.takeaways,
    sections: MODEL_UPGRADE_EVALUATION_GUIDE_SPEC.sections.map(([kind, heading, entries]) => buildSectionFromSpec(kind, heading, entries)),
    faq: MODEL_UPGRADE_EVALUATION_GUIDE_SPEC.faq.map(([question, text]) => answer(question, text)),
    relatedPaths: MODEL_UPGRADE_EVALUATION_GUIDE_SPEC.relatedPaths,
  });
}

const BROWSER_BRIDGE_GUIDE_SPECS = Object.freeze([
  {
    slug: 'browser-automation-safety',
    meta: {
      query: 'browser automation safety',
      title: 'Browser Automation Safety | Prompt Injection, Permissions, and Pre-Action Checks',
      heroTitle: 'Browser automation safety needs explicit approval boundaries',
      heroSummary: 'Browser agents can click, type, and navigate for you, but they also widen prompt-injection and cross-app integration risk. ThumbGate adds approval boundaries, auditability, and a native messaging audit before those bridges turn into silent blast-radius expansion.',
    },
    takeaways: [
      'Browser automation is useful because it has real permissions, which is exactly why it needs governance.',
      'Prompt injection becomes more dangerous when an extension can reach a local executable through a browser bridge.',
      'ThumbGate gives teams a first action now: audit native messaging hosts, then require explicit approval before browser-use connectors expand.',
    ],
    sections: [
      ['paragraphs', 'Why browser-use changes the threat model', [
        'Browser agents do not just read text. They can click buttons, fill forms, switch tabs, and sometimes bridge into local binaries. That means the blast radius is no longer only "bad output" but "real actions on live websites and local systems."',
        'Once browser automation enters the stack, prompt injection stops being an abstract model weakness and becomes a workflow-governance problem. The right control is not more prompt advice. It is a hard boundary around what the agent is allowed to connect, install, and execute.',
      ]],
      ['bullets', 'What to audit first', [
        'Which browser extensions hold automation permissions such as debugger, tabs, downloads, and nativeMessaging.',
        'Whether the desktop app or CLI has registered native messaging hosts for browsers you did not explicitly connect.',
        'Whether host manifests point to live local binaries and whether those binaries sit outside the browser sandbox.',
        'Whether browser-use runs default to ask-before-acting or silently expand capability before a human approves them.',
      ]],
      ['paragraphs', 'How ThumbGate fits', [
        'ThumbGate is the approval and enforcement layer around browser-use. Start by running npx thumbgate native-messaging-audit. Then gate future connector installs, record who approved them, and turn browser-bridge mistakes into Pre-Action Checks before the same pattern repeats.',
      ]],
    ],
    faq: [
      [
        'Why is browser automation riskier than ordinary chat?',
        'Because the agent can take real actions in a browser and may also reach local executables through native messaging bridges. That turns prompt injection and permission drift into operational risk, not just output-quality risk.',
      ],
      [
        'What should a team do before enabling browser-use broadly?',
        'Audit native messaging hosts, review extension permissions, keep ask-before-acting enabled by default, and require explicit approval for any cross-app connector that expands the agent runtime beyond the browser sandbox.',
      ],
    ],
    relatedPaths: ['/guides/native-messaging-host-security', '/guides/pre-action-checks'],
  },
  {
    slug: 'native-messaging-host-security',
    meta: {
      query: 'native messaging host security',
      title: 'Native Messaging Host Security | Audit Browser Bridges Before They Expand',
      heroTitle: 'Native messaging host security for AI browser bridges',
      heroSummary: 'Native messaging hosts let browser extensions talk to local executables. That can be useful, but it also creates a persistent bridge outside the browser sandbox. ThumbGate audits those registrations and helps teams require explicit approval before they become part of the workflow.',
    },
    takeaways: [
      'Native messaging is a real local capability boundary, not a harmless implementation detail.',
      'A manifest can pre-authorize extension origins long before a human operator understands the blast radius.',
      'ThumbGate turns native messaging review into an auditable operator workflow instead of an invisible local side effect.',
    ],
    sections: [
      ['paragraphs', 'What native messaging hosts actually do', [
        'A native messaging host is a local manifest that tells a browser extension which executable it may launch on the operator machine. That bridge sits outside the browser sandbox, so it deserves the same review discipline teams use for deploy credentials or production write access.',
        'The risk is not only the host binary itself. It is the combination of extension permissions, allowed origins, and whether the host remains registered for browsers the operator did not intentionally connect.',
      ]],
      ['bullets', 'Signals ThumbGate audits', [
        'Manifest files under browser-specific NativeMessagingHosts directories on macOS and Linux.',
        'Allowed extension origins and extension-id fan-out per host registration.',
        'Host binaries that are missing on disk, which leaves stale or broken registrations behind.',
        'AI/browser bridge manifests registered for browsers not detected in the usual local install paths.',
      ]],
      ['paragraphs', 'The fastest operator action', [
        'Run npx thumbgate native-messaging-audit --json in the repo or workstation you govern. Review every AI browser bridge, remove anything you did not intentionally integrate, and keep browser-use in ask-before-acting mode until connector scope is explicit and revocable.',
      ]],
    ],
    faq: [
      [
        'Why does native messaging deserve a separate security review?',
        'Because it lets a browser extension hand work to a local executable outside the browser sandbox. That is a different trust boundary than ordinary page automation or side-panel UI access.',
      ],
      [
        'How does ThumbGate help with native messaging host security?',
        'ThumbGate audits known host locations, highlights AI/browser bridges, flags stale or missing host binaries, and gives teams an enforcement layer so future connector expansion requires explicit approval.',
      ],
    ],
    relatedPaths: ['/guides/browser-automation-safety', '/guides/pre-action-checks'],
  },
]);

function buildBrowserBridgeGuide(spec) {
  return preActionGuide(spec.slug, {
    ...spec.meta,
    takeaways: spec.takeaways,
    sections: spec.sections.map(([kind, heading, entries]) => buildSectionFromSpec(kind, heading, entries)),
    faq: spec.faq.map(([question, text]) => answer(question, text)),
    relatedPaths: spec.relatedPaths,
  });
}

const AI_RECOMMENDATION_VISIBILITY_GUIDE_SPECS = Object.freeze([
  {
    slug: 'ai-search-topical-presence',
    meta: {
      query: 'ai search topical presence',
      title: 'AI Search Topical Presence | Become the Obvious Recommendation',
      heroTitle: 'AI search topical presence decides who gets recommended',
      heroSummary: 'AI assistants recommend the tools they repeatedly see tied to a problem in credible contexts. ThumbGate wins when the web consistently connects it to pre-action checks, AI coding agent safety, and stopping repeated mistakes before execution.',
    },
    takeaways: [
      'Topical presence is about repeated, credible association with the problems buyers actually ask AI systems to solve.',
      'ThumbGate should own a narrow association first: pre-action checks for AI coding agents.',
      'Proof assets, comparisons, integration pages, and category guides build the depth and breadth that make recommendations stick.',
    ],
    sections: [
      ['paragraphs', 'What topical presence really measures', [
        'AI search visibility is not just page count or classic keyword volume. It is the strength of the association between your brand, the buyer problem, and the category language the model has already absorbed.',
        'For ThumbGate, that means showing up around pre-action checks, stopping repeated AI agent mistakes, AI coding agent guardrails, workflow hardening, and runtime enforcement. When those associations repeat across guides, product copy, proof artifacts, and third-party mentions, the model gains confidence retrieving ThumbGate for the right prompt.',
      ]],
      ['bullets', 'How ThumbGate improves topical presence', [
        'Lead with one crisp category association: ThumbGate is the pre-action checks layer for AI coding agents.',
        'Publish proof-backed pages that connect the product to repeated-mistake blocking, workflow hardening, and team enforcement.',
        'Cover adjacent commercial prompts such as Codex guardrails, Cursor repeat-failure prevention, browser automation safety, and Autoresearch safety.',
        'Keep pricing, verification evidence, and supported-agent compatibility easy for humans and LLMs to quote.',
      ]],
      ['paragraphs', 'What to publish next', [
        'The fastest way to improve topical presence is not random content fan-out. It is a small set of specific, high-intent pages that reinforce the same recommendation pattern from different angles. ThumbGate should keep tightening the loop between buyer questions, proof links, integration pages, and machine-readable evidence.',
      ]],
    ],
    faq: [
      [
        'Is topical presence the same thing as AI share of voice?',
        'No. Share of voice tells you how often you appear. Topical presence tells you which problems and concepts the model actually associates with your brand, which is much more useful when you want to become the default recommendation.',
      ],
      [
        'What should a developer tool do first to improve topical presence?',
        'Pick one narrow, commercially relevant association and reinforce it everywhere. For ThumbGate, that association is pre-action checks for AI coding agents backed by verification evidence and workflow hardening outcomes.',
      ],
    ],
    relatedPaths: ['/guides/relational-knowledge-ai-recommendations', '/guides/pre-action-checks'],
  },
  {
    slug: 'relational-knowledge-ai-recommendations',
    meta: {
      query: 'relational knowledge ai recommendations',
      title: 'Relational Knowledge in AI Recommendations | Why Brands Get Picked',
      heroTitle: 'Relational knowledge explains why AI systems recommend some tools and ignore others',
      heroSummary: 'LLMs do not recommend brands from keywords alone. They retrieve stored associations between a problem, a category, and the brand they have repeatedly seen in that context. ThumbGate benefits when those associations stay crisp and evidence-backed.',
    },
    takeaways: [
      'AI recommendations come from learned associations, not from whichever brand publishes the most pages.',
      'Crowded many-to-many categories make generic positioning disappear into the noise.',
      'ThumbGate should reinforce a tight relationship: repeated AI coding mistakes -> pre-action checks -> ThumbGate.',
    ],
    sections: [
      ['paragraphs', 'Relational knowledge in plain English', [
        'A language model stores facts and associations about the world. When a buyer asks for a recommendation, the model tries to retrieve the brand most strongly associated with that problem and category. If the associations are weak or generic, the model falls back to louder or simpler competitors.',
        'That is why vague positioning like "AI memory for agents" is a weaker long-term recommendation strategy for ThumbGate than a sharper relationship such as "pre-action checks that stop repeated AI coding mistakes before execution."',
      ]],
      ['bullets', 'How ThumbGate becomes the obvious recommendation', [
        'Repeat the same category language across landing copy, guides, README links, and structured data.',
        'Pair the association with proof: verification evidence, automation proof, supported agents, and pricing.',
        'Publish comparisons that explain why memory-only or spec-only alternatives do not solve repeated tool-call failures.',
        'Expand outward from the core association into adjacent prompts only after the primary link is strong.',
      ]],
      ['paragraphs', 'Where teams usually get lost', [
        'Brands become invisible when they try to cover too many adjacent categories without owning one association deeply. ThumbGate should keep using specific buyer-language such as workflow hardening, pre-action checks, repeat-failure blocking, browser bridge safety, and AI coding agent guardrails so the recommendation path stays crisp.',
      ]],
    ],
    faq: [
      [
        'Why does content volume alone fail to earn AI recommendations?',
        'Because models care about the consistency and credibility of the association, not just the amount of text. Fifty vague pages rarely beat a smaller set of pages, proofs, and third-party mentions that all reinforce the same relationship.',
      ],
      [
        'What signals help ThumbGate most?',
        'Pages that tie ThumbGate to pre-action checks, AI coding agent safety, stopping repeated mistakes, supported-agent compatibility, and proof-backed outcomes help the model retrieve it with more confidence.',
      ],
    ],
    relatedPaths: ['/guides/ai-search-topical-presence', '/compare/mem0'],
  },
  {
    slug: 'ai-mode-ads-agent-governance',
    meta: {
      query: 'ai mode ads agent governance',
      title: 'AI Mode Ads for Agent Governance | Turn Buyer Prompts Into ThumbGate Demand',
      heroTitle: 'AI Mode ads make agent-governance promotion conversational',
      heroSummary: 'Google AI Mode and conversational ad formats shift promotion from click-chasing to answer ownership. ThumbGate should show up when buyers ask how to govern Claude Code, Cursor, Codex, Gemini, MCP tools, and risky agent actions.',
    },
    takeaways: [
      'Conversational ads reward brands that answer the buyer question directly before the click.',
      'ThumbGate should own prompts about pre-action gates, MCP tool governance, repeated AI-agent mistakes, and audit proof.',
      'The best paid-search asset is an answer page with schema, proof links, and a checkout or workflow-intake path.',
    ],
    sections: [
      ['paragraphs', 'Why conversational ads change the promotion plan', [
        'Search ads are moving toward generated answers and product recommendations inside the search conversation. A buyer may not click ten blue links before forming an opinion; the assistant-like surface may summarize the category, compare options, and mention a vendor in one flow.',
        'That means ThumbGate promotion has to be answer-shaped. The page must say exactly what ThumbGate is, which agent-risk problem it solves, which tools it supports, and what proof a buyer can verify before starting checkout or a Workflow Hardening Sprint.',
      ]],
      ['bullets', 'Buyer prompts ThumbGate should target', [
        'How do I stop Claude Code or Cursor from repeating risky mistakes?',
        'What is the pre-action approval layer for AI coding agents?',
        'How do teams govern MCP tools before agents call them?',
        'How do I audit AI-agent actions before production deploys, payments, or database writes?',
        'What tool turns thumbs-down feedback into enforceable rules?',
      ]],
      ['paragraphs', 'How this page should be used', [
        'Use this page as the landing asset for AI Mode, Gemini, and high-intent search experiments. Do not send conversational-ad traffic to a generic homepage first. Send it to the answer that mirrors the buyer prompt, then route warm readers to Pro checkout, the install guide, or workflow intake depending on intent.',
      ]],
    ],
    faq: [
      [
        'How do AI Mode ads help ThumbGate?',
        'They favor direct, conversational answers. ThumbGate benefits when it has pages that answer specific buyer prompts about AI-agent governance, MCP tool risk, pre-action approval gates, and repeated failure prevention.',
      ],
      [
        'Should ThumbGate run broad Google Ads immediately?',
        'No. The high-ROI path is to build answer assets first, then test narrow paid search or AI Mode campaigns against exact buyer prompts where the page, schema, proof links, and checkout route all match the question.',
      ],
      [
        'What is the one-sentence ad answer?',
        'ThumbGate is the pre-action execution gate for AI agents: it checks risky tool calls before they run, turns feedback into rules, and gives teams audit proof.',
      ],
    ],
    relatedPaths: ['/guides/ai-search-topical-presence', '/guides/pre-action-checks', '/guides/mcp-tool-governance'],
  },
]);

function buildAiRecommendationVisibilityGuide(spec) {
  return preActionGuide(spec.slug, {
    ...spec.meta,
    takeaways: spec.takeaways,
    sections: spec.sections.map(([kind, heading, entries]) => buildSectionFromSpec(kind, heading, entries)),
    faq: spec.faq.map(([question, text]) => answer(question, text)),
    relatedPaths: spec.relatedPaths,
  });
}

const PAGE_BLUEPRINTS = [
  {
    query: 'snowflake cortex agent governance vs local coding agent guardrails',
    path: '/compare/snowflake-cortex-agent-governance',
    pageType: 'comparison',
    pillar: 'comparison',
    title: 'ThumbGate vs Snowflake Cortex Agent Governance | Two Different Layers',
    heroTitle: 'ThumbGate vs Snowflake Cortex Agent Governance',
    heroSummary: 'At Snowflake Summit 2026, agent governance became headline infrastructure: Cortex CoCo runs under your existing RBAC inside Snowflake\'s perimeter, and the Natoma acquisition adds a permission gateway built to freeze out rogue agents. That is the right model for agents operating inside the data cloud. But the coding agent in your terminal acts earlier and lower in the stack: Claude Code, Cursor, and Codex run rm -rf, force-push to main, and write secrets to disk on your own machine, under your own credentials, before any platform RBAC ever sees the request. ThumbGate is the local-first PreToolUse layer for exactly that surface. They are not competitors — they are different layers of the same defense.',
    takeaways: [
      'Snowflake Cortex and Natoma govern what an agent does inside the enterprise data perimeter — server-side, under RBAC, with a full audit trail. The right tool when the agent\'s actions are SQL and data access inside Snowflake.',
      'ThumbGate governs what a coding agent does on the developer\'s machine — rm -rf, force-push, secret writes, off-scope edits — in the PreToolUse hook, before execution, before any platform sees the request.',
      'The two compose. A coding agent that force-pushes broken code or leaks a key never reached Snowflake\'s perimeter to be governed there; that failure happens in the dev loop, which is the layer ThumbGate owns.',
    ],
    sections: [
      {
        heading: 'The boundary in one sentence',
        paragraphs: [
          'Snowflake Cortex governs what an agent is allowed to do once it is operating inside Snowflake — querying tables, accessing data, taking actions under your RBAC, with prompt-injection guardrails and an audit trail. Natoma extends that to a permission gateway across enterprise apps.',
          'ThumbGate governs what a coding agent does on the developer\'s machine, in the PreToolUse hook, before the tool call executes — the rm -rf, the git push --force, the secret written to disk. That happens in the terminal, under the developer\'s own credentials, before any platform boundary exists to enforce it.',
        ],
      },
      {
        heading: 'Choose Snowflake Cortex / Natoma governance when',
        bullets: [
          'Your agents operate inside the Snowflake data cloud and the risk you manage is data access and SQL under enterprise RBAC.',
          'You need centralized, server-side policy and audit across enterprise applications and identities.',
          'Your buyer is a data or platform team standardizing agent access at the organization level.',
        ],
      },
      {
        heading: 'Choose ThumbGate when',
        bullets: [
          'Your risk is a coding agent on a developer\'s machine — Claude Code, Cursor, Codex, Gemini, Amp, Cline, OpenCode — running destructive shell, git, or filesystem actions.',
          'You want enforcement in the PreToolUse hook, before execution, with zero server and zero rollout — npx thumbgate init in 30 seconds.',
          'You want a learning loop: a thumbs-down on a blocked action becomes an auto-promoted prevention rule that holds across every session and every agent.',
          'You want least-privilege task scope and a local audit trail of every blocked action — not only inside one platform\'s perimeter.',
        ],
      },
      {
        heading: 'Why the two layers do not overlap',
        paragraphs: [
          'Snowflake validated the thesis the whole category now agrees on: agents need a control layer that decides what they can do before they do it, not an audit log after the damage. At Summit 2026 they made it headline infrastructure and acquired Natoma to enforce it across the enterprise.',
          'But platform governance can only act on requests that reach the platform. A coding agent that force-pushes broken code, deletes a directory, or commits a secret has already done the damage on the developer\'s machine — that action never traveled to Snowflake to be governed. ThumbGate is the enforcement point for that earlier, lower layer. If you run AI coding agents and AI inside your data cloud, you want both: ThumbGate at the dev loop, platform governance at the data layer.',
        ],
      },
    ],
    faq: [
      {
        question: 'Is ThumbGate an alternative to Snowflake Cortex agent governance?',
        answer: 'Not exactly — they govern different layers. Snowflake Cortex and Natoma govern agents operating inside the enterprise data cloud under RBAC. ThumbGate governs coding agents on the developer\'s machine in the PreToolUse hook, before any action reaches a platform. If your risk is a coding agent running rm -rf or force-pushing to main, ThumbGate is the right layer; if your risk is data access inside Snowflake, Cortex is. Most teams running both AI coding agents and AI in their data cloud want both.',
      },
      {
        question: 'Does ThumbGate require a server or enterprise rollout like Natoma?',
        answer: 'No. ThumbGate is local-first: npx thumbgate init wires the PreToolUse hook on your machine in about 30 seconds, with no server, no gateway, and no platform rollout. Natoma is a server-side permission gateway for enterprise applications; ThumbGate runs entirely in the developer\'s local agent loop. That is the deliberate difference in surface.',
      },
      {
        question: 'Snowflake says agentic security needs a fundamentally different approach. Does ThumbGate agree?',
        answer: 'Yes — and ThumbGate has been built on that premise from day one. The shared thesis is that you enforce before the action, not after: a deterministic pre-action gate, not a model reviewing its own output. Snowflake applies that inside the data perimeter; ThumbGate applies it at the coding-agent layer on the developer\'s machine. The agreement on the model is exactly why the two compose rather than compete.',
      },
    ],
    relatedPaths: ['/compare/claude-code-hooks-mastery', '/guides/ai-agent-pre-action-approval-gates', '/guides/background-agent-governance'],
  },
  {
    query: 'thumbgate vs speclock',
    path: '/compare/speclock',
    pageType: 'comparison',
    pillar: 'comparison',
    title: 'ThumbGate vs SpecLock | Thumbs Feedback vs Manual Specs',
    heroTitle: 'ThumbGate vs SpecLock',
    heroSummary: 'SpecLock starts from manually written constraints. ThumbGate starts from thumbs-up/down feedback and turns it into pre-action checks that block repeated mistakes.',
    takeaways: [
      'ThumbGate learns from thumbs-up and thumbs-down feedback without requiring a separate spec-writing workflow.',
      'SpecLock is strongest when a team already has strong specifications and wants enforcement tied to those documents.',
      'ThumbGate is strongest when the pain is repeated agent mistakes across Claude Code, Cursor, Codex, Gemini, Amp, and OpenCode.',
    ],
    sections: [
      {
        heading: 'The product difference in one sentence',
        paragraphs: [
          'SpecLock helps a team codify rules before the work begins. ThumbGate helps a team convert real thumbs-up/down feedback into live pre-action checks after the work reveals what actually breaks.',
          'That means ThumbGate is better for fast-moving agent workflows where the problem is not writing more specs, but preventing the same mistake from happening again tomorrow.',
        ],
      },
      {
        heading: 'Choose ThumbGate when',
        bullets: [
          'Your agent already repeats known mistakes and you need the block to happen before tool execution.',
          'You want one feedback loop that supports both reinforcement from thumbs up and prevention from thumbs down.',
          'You need proof assets, automation reports, and compatibility across multiple coding agents.',
        ],
      },
      {
        heading: 'Choose SpecLock when',
        bullets: [
          'Your team already maintains strong PRDs or system specs and wants the model constrained against those artifacts.',
          'Your primary problem is uncontrolled file edits, not a missing feedback-to-enforcement loop.',
          'You are willing to invest in manual constraint authoring as part of the workflow.',
        ],
      },
    ],
    faq: [
      {
        question: 'Is ThumbGate trying to replace specs?',
        answer: 'No. ThumbGate complements specs by capturing thumbs-up/down feedback from live agent behavior and enforcing the learned rules as pre-action checks.',
      },
      {
        question: 'What does ThumbGate do that SpecLock does not?',
        answer: 'ThumbGate turns explicit feedback into searchable memory, auto-generated prevention rules, and runtime checks that block repeated mistakes before the next tool call executes.',
      },
    ],
    relatedPaths: ['/compare/mem0', '/guides/pre-action-checks'],
  },
  {
    query: 'thumbgate vs mem0',
    path: '/compare/mem0',
    pageType: 'comparison',
    pillar: 'comparison',
    title: 'ThumbGate vs Mem0 | Enforcement vs Memory for AI Agents',
    heroTitle: 'ThumbGate vs Mem0',
    heroSummary: 'Mem0 is memory. ThumbGate is memory plus enforcement. It captures thumbs-up/down feedback, promotes the signal into rules, and blocks repeat failures with pre-action checks.',
    takeaways: [
      'Mem0 is useful when you mainly need retrieval and cross-session context.',
      'ThumbGate is useful when retrieval alone is not enough and the system has to stop the same mistake before execution.',
      'ThumbGate adds proof assets and automation reports so the buying story is stronger for engineering teams.',
    ],
    sections: [
      {
        heading: 'Where Mem0 fits',
        paragraphs: [
          'Mem0 is designed as a cloud memory layer. It helps the model remember context and past interactions, but memory alone does not guarantee that the next action is safe.',
        ],
      },
      {
        heading: 'Where ThumbGate fits',
        paragraphs: [
          'ThumbGate begins with the same need to remember, but it goes further. A thumbs down can become a prevention rule, and that rule can become a pre-action check that blocks a repeated tool call.',
        ],
        bullets: [
          'Thumbs up reinforces good behavior.',
          'Thumbs down blocks repeated mistakes.',
          'Verification evidence and automation reports back up the reliability claim.',
        ],
      },
      {
        heading: 'Which page should rank',
        paragraphs: [
          'This comparison page should win when the searcher is already deciding between a memory system and an enforcement system. The goal is to make the distinction obvious in under 30 seconds.',
        ],
      },
    ],
    faq: [
      {
        question: 'Does ThumbGate still include memory?',
        answer: 'Yes. ThumbGate keeps local-first memory, ContextFS packs, lesson search, and recall, but adds pre-action enforcement when memory alone is insufficient.',
      },
      {
        question: 'Why compare Mem0 at all?',
        answer: 'Because buyers often start with memory tooling and only later realize they also need enforcement. This page makes that upgrade path explicit.',
      },
    ],
    relatedPaths: ['/compare/speclock', '/guides/claude-code-feedback'],
  },
  buildSemanticPseoGuide(),
  buildZeroTrustGuide(),
  buildGovernClaudeForLegalGuide(),
  buildPretooluseHookGuide(),
  buildProxyPointerRagGuide(),
  buildRagPrecisionTuningGuide(),
  buildAiEngineeringStackGuide(),
  buildSeoAgentSkillsGuide(),
  {
    query: 'thumbgate vs fallow',
    path: '/compare/fallow',
    pageType: 'comparison',
    pillar: 'comparison',
    title: 'ThumbGate vs Fallow | Static Analysis vs Agent Action Enforcement',
    heroTitle: 'ThumbGate vs Fallow',
    heroSummary: 'Fallow finds JS/TS code health issues: dead code, duplication, complexity, and architecture drift. ThumbGate is action-boundary enforcement for AI agents, stopping agents from acting on those signals unsafely.',
    takeaways: [
      'Fallow is complementary, not a direct replacement: it finds dead code, duplication, complexity, and architecture drift.',
      'ThumbGate governs the next agent action: refactor scope, risky edits, CI proof, team lessons, and pre-action blocks.',
      'Together, Fallow output can become ThumbGate gates so agents do not blindly refactor everything a static analyzer flags.',
    ],
    sections: [
      {
        heading: 'The product difference in one sentence',
        paragraphs: [
          'Fallow tells you where a JavaScript or TypeScript codebase may be unhealthy. ThumbGate governs what AI agents are allowed to do next: make the next edit, command, PR, or publish action.',
          'That distinction matters because analyzer output can be useful and dangerous at the same time. A duplicated block can be safe to refactor, or it can be intentional domain duplication where an agent should stop and ask for evidence.',
        ],
      },
      {
        heading: 'Choose Fallow when',
        bullets: [
          'You want static reports for unused code, duplicate blocks, complexity hotspots, circular dependencies, or architecture drift.',
          'You need JSON diagnostics an agent can inspect before proposing cleanup work.',
          'Your immediate goal is code health visibility in JS/TS repositories.',
        ],
      },
      {
        heading: 'Choose ThumbGate when',
        bullets: [
          'You need pre-action enforcement before an AI agent applies analyzer-driven refactors.',
          'You want CI and human feedback to become durable prevention rules across Claude Code, Cursor, Codex, Gemini, Amp, Cline, and OpenCode.',
          'You need audit evidence that a risky cleanup, dependency update, or cross-layer refactor was checked before execution.',
        ],
      },
      {
        heading: 'Best together',
        paragraphs: [
          'The highest-ROI workflow is Fallow for deterministic codebase signals and ThumbGate for agent governance. Run the analyzer, pass the changed-file and complexity signals into a ThumbGate gate, then require proof before the agent edits central files or opens a PR.',
        ],
      },
    ],
    faq: [
      {
        question: 'Is Fallow a competitor to ThumbGate?',
        answer: 'Partly adjacent, but mostly complementary. Fallow analyzes JS/TS code health. ThumbGate enforces AI-agent actions before execution. They solve different parts of the agent workflow.',
      },
      {
        question: 'Should ThumbGate integrate with Fallow output?',
        answer: 'Yes. Fallow JSON is useful input for ThumbGate gates, especially duplication, complexity, changed-file audit results, and architecture-boundary warnings.',
      },
    ],
    relatedPaths: ['/guides/code-knowledge-graph-guardrails', '/guides/agent-harness-optimization', '/guides/pre-action-checks'],
  },
  {
    query: 'thumbgate vs cycode ai coding agent guardrails',
    path: '/compare/cycode',
    pageType: 'comparison',
    pillar: 'comparison',
    title: 'ThumbGate vs Cycode | Local-First MIT Alternative for AI Agent Guardrails',
    heroTitle: 'ThumbGate vs Cycode',
    heroSummary: 'Cycode ships IDE-native security guardrails for enterprise AppSec teams — agent-time scanning, beforeMCPExecution / beforeReadFile / beforeSubmitPrompt hooks, and integration with their broader code-security platform. ThumbGate is the local-first, MIT-licensed CLI that ships the same PreToolUse / MCP-tool-call gating surface as an open-source npm install — and adds a learning loop where every thumbs-down becomes an auto-promoted prevention rule the team shares.',
    takeaways: [
      'Cycode is enterprise IDE security: agent-time scanning + hook interception + platform integration with their broader AppSec suite.',
      'ThumbGate ships the same PreToolUse / beforeMCPExecution surface as an MIT-licensed CLI you install in 30 seconds — no platform contract, no procurement cycle.',
      'The decision is mostly company-shape: enterprise security teams take Cycode; solo devs, OSS maintainers, and small teams take ThumbGate. The learning-loop (thumbs-down → prevention rule across sessions) is something Cycode does not advertise.',
    ],
    sections: [
      {
        heading: 'The product difference in one sentence',
        paragraphs: [
          'Cycode is "IDE security for the enterprise" — its February 2026 announcement positions the agent-time hooks (beforeSubmitPrompt, beforeReadFile, beforeMCPExecution) as one module of a broader AppSec platform that also covers secrets, SAST, SCA, and supply chain.',
          'ThumbGate is a single-purpose, open-source, local-first CLI for the same hook surface. The lexicon is the same; the buyer is different. ThumbGate optimizes for a developer who can `npx thumbgate init` and have working PreToolUse gating before lunch.',
        ],
      },
      {
        heading: 'Choose Cycode when',
        bullets: [
          'You have an enterprise AppSec team that needs a unified vendor across secrets, SAST, SCA, supply-chain, and the new agent-time hook layer.',
          'You need centralized policy management, RBAC, SIEM integration, and a procurement-ready contract with SOC2 / ISO-grade artifacts.',
          'Your security org wants one dashboard for IDE-time and CI/CD-time security posture across the whole repo footprint.',
        ],
      },
      {
        heading: 'Choose ThumbGate when',
        bullets: [
          'You want PreToolUse / beforeMCPExecution gating working in 30 seconds via `npx thumbgate init` — no contract, no platform install, no procurement.',
          'You want a learning loop: a thumbs-down on a blocked action becomes an auto-promoted prevention rule that holds across every session, model, and agent.',
          'You are a solo developer, OSS maintainer, or small team that wants MIT-licensed code you can read, fork, and verify — not a closed-source SaaS.',
          'You want the gating engine to run entirely on the developer machine with zero network egress for the hook decision itself.',
        ],
      },
      {
        heading: 'What the two products share',
        paragraphs: [
          'Both put the enforcement boundary at the same place — the agent\'s tool call, before execution — and both name the hooks the same way (PreToolUse / beforeMCPExecution / beforeReadFile). The category lexicon is the same because the underlying agent loop is the same.',
          'The disagreement is on packaging. Cycode wraps it in an enterprise platform contract; ThumbGate ships it as an MIT-licensed CLI. If you are an enterprise security team buying a platform, you are not the ThumbGate buyer. If you are a developer who wants to type `npx thumbgate init` and have agent gating running before the next standup, Cycode is over-scoped for you.',
        ],
      },
    ],
    faq: [
      {
        question: 'Is ThumbGate a direct replacement for Cycode\'s agent-time hooks?',
        answer: 'For the hook surface itself — PreToolUse, beforeMCPExecution, beforeReadFile — yes. For the broader Cycode AppSec platform (secrets scanning, SAST, SCA, supply chain), no. ThumbGate is single-purpose: agent-time tool-call gating with a learning loop. If you only need that, ThumbGate replaces the Cycode agent-time module at zero license cost.',
      },
      {
        question: 'Why would I pick MIT-licensed local-first over a funded enterprise vendor?',
        answer: 'Three reasons. (1) Cost: no per-seat license. (2) Speed of adoption: `npx thumbgate init` is faster than enterprise procurement. (3) Auditability: you can read the gate-engine code, modify it, and run it offline. The trade-off is you do not get a platform contract, RBAC, or a single vendor for all your AppSec needs. That is a fine trade-off for a solo dev or small team; it is the wrong trade-off for a regulated enterprise.',
      },
      {
        question: 'Does Cycode have the cross-session learning loop?',
        answer: 'Not advertised on their public materials as of the February 2026 announcement. Cycode\'s hooks are policy-driven; ThumbGate adds a feedback-to-rules pipeline where a thumbs-down on a blocked action becomes an auto-promoted prevention rule that holds across every session and every agent on the same install.',
      },
      {
        question: 'Can I use both?',
        answer: 'Technically yes — Cycode at the enterprise platform layer, ThumbGate as the developer-local fast loop — but most teams will pick one. They occupy the same hook surface, so running both means resolving who wins on conflicts. The simpler pattern is to pick by buyer profile: enterprise security team buys Cycode, individual developer / small team installs ThumbGate.',
      },
    ],
    relatedPaths: ['/guides/claude-code-pretooluse-hook', '/guides/mcp-tool-governance', '/guides/ai-coding-agent-zero-trust'],
  },
  {
    query: 'thumbgate vs disler claude code hooks mastery',
    path: '/compare/claude-code-hooks-mastery',
    pageType: 'comparison',
    pillar: 'comparison',
    title: 'ThumbGate vs disler/claude-code-hooks-mastery | When to Pick the OSS Tool',
    heroTitle: 'ThumbGate vs disler/claude-code-hooks-mastery',
    heroSummary: 'disler/claude-code-hooks-mastery is the most-starred community repo for Claude Code hooks — a comprehensive, free, MIT-licensed example library you can copy-paste into your own .claude/ config. ThumbGate is a published npm CLI that does the same gating work plus a learning loop where every thumbs-down becomes an auto-promoted prevention rule that holds across sessions, models, and agents. The disler repo is where you START; ThumbGate is what you USE when you stop wanting to maintain hook scripts by hand.',
    takeaways: [
      'disler/claude-code-hooks-mastery is a free reference repo of hook examples — you copy them into .claude/, edit, and maintain per-machine, per-project.',
      'ThumbGate ships the same gating engine as one `npx thumbgate init` install — versioned config, cross-session prevention rules, dashboard, audit trail.',
      'The right path: start with the disler repo to learn what is possible; move to ThumbGate when you find yourself maintaining hook scripts in three projects.',
    ],
    sections: [
      {
        heading: 'The product difference in one sentence',
        paragraphs: [
          'disler/claude-code-hooks-mastery is a GitHub repository of high-quality example hooks you read, learn from, and copy into your own setup. ThumbGate is a published CLI that ships the gating engine as a runnable tool with cross-session learning, a dashboard, and an audit trail.',
          'Both are MIT-licensed. Both run locally. The disagreement is whether you want to read example scripts and own the maintenance, or install a tool that does the work and stays in sync.',
        ],
      },
      {
        heading: 'Choose disler/claude-code-hooks-mastery when',
        bullets: [
          'You want to learn how Claude Code hooks actually work by reading well-written examples.',
          'You are happy maintaining your own .claude/ config per project and per machine.',
          'You only need static pattern-matching — no need for cross-session learning, dashboard, or audit history.',
          'You explicitly do not want any installed dependency beyond what you author yourself.',
        ],
      },
      {
        heading: 'Choose ThumbGate when',
        bullets: [
          'You want PreToolUse gating working in 30 seconds via `npx thumbgate init` — no copy-paste, no per-machine setup.',
          'You want the learning loop: a thumbs-down on a blocked action becomes an auto-promoted prevention rule that holds across every session and every agent on the install.',
          'You want a dashboard showing what was blocked, why, and which feedback became which rule — auditable evidence, not just hook scripts on disk.',
          'You want one gate engine that works across Claude Code, Cursor, Codex, Gemini CLI, Amp, Cline, and OpenCode — not a separate copy-paste exercise per agent.',
          'You operate on more than one project and do not want to maintain N copies of the same hook scripts.',
        ],
      },
      {
        heading: 'What the disler repo does brilliantly',
        paragraphs: [
          'It is the best public reference for what a Claude Code PreToolUse hook can do — clear examples, real patterns, MIT-licensed code you can read end-to-end in an afternoon. If you are evaluating the category, that repo is required reading. It also has 3,000+ stars at the time of writing for a reason: the examples are good.',
          'ThumbGate is not trying to replace that learning resource. The disler repo is where you understand the surface; ThumbGate is what you use when you decide to ship gating in production and want the cross-session learning, the dashboard, and the team-shared rule library that copy-paste cannot give you.',
        ],
      },
    ],
    faq: [
      {
        question: 'Why pay $19/mo for ThumbGate Pro when disler hooks are free?',
        answer: 'Free disler hooks are static patterns you maintain per machine — re-copying them when they change, debugging false positives alone, and re-applying them in every new project. ThumbGate Pro adds the learning loop (repeated thumbs-downs → cross-session prevention rule), the personal dashboard, lesson recall/search, DPO export, and adapter maintenance across the weekly breaking-change cycle of Claude Code, Cursor, and Cline. Free disler is the right answer if you only ever work in one project on one machine and never want to learn from past mistakes. Pro is the right answer when those assumptions stop holding; Enterprise service work is qualified after intake, and shared hosted lessons are not generally available.',
      },
      {
        question: 'Is ThumbGate just a packaged version of disler/claude-code-hooks-mastery?',
        answer: 'No. ThumbGate ships its own gate engine, feedback-to-rules pipeline, dashboard, and audit trail. The disler repo is a reference of well-written hook scripts you copy into your config; ThumbGate is a runnable CLI that ships the gate engine and adds a learning layer on top. Both are MIT-licensed and both rely on the same Claude Code PreToolUse hook surface — that is where the similarity ends.',
      },
      {
        question: 'Should I start with disler or ThumbGate?',
        answer: 'If you want to understand the category, read the disler repo first — it is the best public reference for what hooks can do. If you want gating working now without authoring scripts, run `npx thumbgate init`. Most users end up doing both: read disler to learn, install ThumbGate when they decide they would rather use a tool than maintain scripts.',
      },
    ],
    relatedPaths: ['/guides/claude-code-pretooluse-hook', '/compare/cycode', '/guides/pre-action-checks'],
  },
  buildClaudeCodeSkillsGuide(),
  buildLongRunningAgentContextGuide(),
  buildReasoningCompressionGuide(),
  buildDeepSeekV4RuntimeGuide(),
  {
    query: 'pre-action checks for ai coding agents',
    path: '/guides/pre-action-checks',
    pageType: 'guide',
    pillar: 'pre-action-checks',
    title: 'Pre-Action Checks for AI Coding Agents | ThumbGate Guide',
    heroTitle: 'What Are Pre-Action Checks?',
    heroSummary: 'Pre-action gates stop the risky move before the agent executes it. ThumbGate uses thumbs-up/down feedback to decide what should be reinforced, warned, or blocked.',
    takeaways: [
      'Prompt rules are advisory. Pre-action gates are enforcement.',
      'A repeated thumbs down can become a warning gate or a hard block.',
      'The right proof asset is not the rule text alone but the evidence that the gate fired before damage.',
    ],
    sections: [
      {
        heading: 'Why this matters',
        paragraphs: [
          'Most AI coding failures are not mysterious. They are repeated mistakes: force-pushes, destructive scripts, missed verification steps, or breaking architectural constraints.',
          'A pre-action check turns that failure pattern into a runtime checkpoint. The agent sees the stop before the bad action lands.',
        ],
      },
      {
        heading: 'How ThumbGate makes the loop useful',
        bullets: [
          'Capture structured thumbs-up/down feedback.',
          'Promote repeated failures into prevention rules.',
          'Score and enforce the rules with Thompson Sampling and pre-action hooks.',
          'Publish verification evidence so the system is auditable.',
        ],
      },
      {
        heading: 'Best next step',
        paragraphs: [
          'If a buyer is exploring the category, this page should move them to either a comparison page or the main product proof pack.',
        ],
      },
    ],
    faq: [
      {
        question: 'How are pre-action checks different from prompt rules?',
        answer: 'Prompt rules ask the model nicely. Pre-action gates intercept the tool call and block it before execution when the known-bad pattern matches.',
      },
      {
        question: 'Can a thumbs up matter too?',
        answer: 'Yes. ThumbGate explicitly uses thumbs up to reinforce successful behavior so the system is not only punitive.',
      },
    ],
    relatedPaths: ['/compare/speclock', '/guides/claude-code-feedback'],
  },
  {
    query: 'best tools to stop ai agents from breaking production',
    path: '/guides/best-tools-stop-ai-agents-breaking-production',
    pageType: 'guide',
    pillar: 'pre-action-checks',
    title: 'Best Tools to Stop AI Agents From Breaking Production | ThumbGate Listicle',
    heroTitle: 'Best Tools to Stop AI Agents From Breaking Production',
    heroSummary: 'A practical listicle for teams adopting Claude Code, Cursor, Codex, Gemini, and other coding agents: the winning reliability stack is workflow-first, inspection-driven, and enforced before tool execution.',
    takeaways: [
      'Answer engines cite specific blog posts and listicles more readily than generic product pages, so this guide names the buyer prompt directly.',
      'Production agent safety starts with predefined workflows when possible, then gates open-ended agents when autonomy is actually needed.',
      'ThumbGate is the pre-action enforcement layer that checks workflow shape, environment inspection evidence, and parallel branch budgets before risky execution.',
    ],
    sections: [
      {
        heading: 'The short list',
        bullets: [
          'Workflow templates for known paths: use repeatable plans for deploys, migrations, release checks, and PR cleanup instead of asking an agent to improvise every time.',
          'Environment inspection requirements: require file reads, screenshots, API responses, or command output before the agent claims the state of the world.',
          'Pre-action enforcement: block risky tool calls before execution when the action violates a learned rule, budget, or inspection requirement.',
          'Parallel branch budgets: cap fan-out so multi-agent desktop sessions do not burn tokens, duplicate work, or merge conflicting changes blindly.',
          'Repeated-failure memory: turn thumbs-down reviews into prevention rules and thumbs-up reviews into reinforced safe patterns.',
        ],
      },
      {
        heading: 'Where ThumbGate fits',
        paragraphs: [
          'ThumbGate is not another prompt reminder. It sits at the action boundary, where a coding agent is about to edit files, run commands, call tools, or promote a result.',
          'That makes it a strong answer to long-tail buyer prompts like "how do I stop Claude Code from repeating a production mistake" or "what guardrails should I add before running parallel AI coding agents."',
        ],
      },
      {
        heading: 'What to look for in any tool',
        bullets: [
          'Can it tell whether the work should be a workflow or an open-ended agent?',
          'Can it prove the agent inspected the environment before acting?',
          'Can it block the next bad action, not just remember that the last one was bad?',
          'Can it expose evidence that auditors, teammates, and future agents can read?',
        ],
      },
      {
        heading: 'Promotion angle',
        paragraphs: [
          'This page is designed as AEO fuel: it gives AI answer engines a quotable, specific, buyer-intent explanation of why production AI agents need pre-action checks, inspection evidence, and workflow budgets.',
        ],
      },
    ],
    faq: [
      {
        question: 'What is the best tool to stop AI coding agents from breaking production?',
        answer: 'Use workflow templates for predictable tasks, then add ThumbGate as the pre-action enforcement layer so repeated mistakes, missing inspection evidence, and unsafe parallel fan-out can be blocked before execution.',
      },
      {
        question: 'Why are listicles useful for AI search visibility?',
        answer: 'AI answer engines often cite specific educational pages that match the buyer prompt. A focused listicle gives the model a clear source for production-agent guardrails instead of forcing it to infer the category from generic landing-page copy.',
      },
      {
        question: 'Do I need an agent or a workflow?',
        answer: 'Use a workflow when the path is known and testable. Use an agent when the path is genuinely uncertain, but require environment inspection and pre-action gates before risky tool use.',
      },
    ],
    relatedPaths: ['/guides/pre-action-checks', '/guides/agent-harness-optimization', '/guides/ai-search-topical-presence'],
  },
  {
    query: 'database safety for ai agents',
    path: '/guides/database-agent-safety',
    pageType: 'guide',
    pillar: 'pre-action-checks',
    title: 'Database Safety for AI Agents | ThumbGate Guide',
    heroTitle: 'Database Safety for AI Agents',
    heroSummary: 'AI agents can write code quickly, but database actions need stricter gates: a hallucinated SQL write, migration, role grant, or production config change can destroy data before review.',
    takeaways: [
      'Databases are the highest-blast-radius tool surface for autonomous coding agents.',
      'The winning pattern is not an AI DBA autopilot alone; it is a pre-action approval boundary before SQL, migrations, and privilege changes run.',
      'ThumbGate turns repeated database mistakes into rules that block or pause the next risky query before execution.',
    ],
    sections: [
      {
        heading: 'Why database work is the final boss for agents',
        paragraphs: [
          'A bad UI component is visible and usually reversible. A bad production query can delete rows, lock writes, leak data, or change privileges before anyone reviews the pull request.',
          'That is why database-agent safety belongs at the tool-call boundary. The agent should be stopped before it runs DROP, TRUNCATE, unbounded UPDATE/DELETE, production migrations, or role grants.',
        ],
      },
      {
        heading: 'The high-ROI gate pack',
        bullets: [
          'Block DROP, TRUNCATE, DROP DATABASE, and DROP SCHEMA unless human approval and rollback evidence are attached.',
          'Block UPDATE and DELETE without a restrictive WHERE clause, including WHERE 1=1 and WHERE TRUE.',
          'Require backup, snapshot, or reversible migration proof before production schema changes.',
          'Require dry-run or EXPLAIN evidence before production writes and migrations.',
          'Warn on CREATE INDEX without CONCURRENTLY and CROSS JOINs that can create performance incidents.',
          'Block role creation, role alteration, and broad grants from autonomous agents.',
        ],
      },
      {
        heading: 'Where ThumbGate fits',
        paragraphs: [
          'ThumbGate is not trying to replace Postgres, MySQL, Prisma, Rails migrations, or a DBA. It is the pre-action control plane that checks the agent before those tools execute.',
          'The feedback loop matters: when a human gives a thumbs-down on an unsafe migration or query, ThumbGate can promote the failure pattern into a prevention rule so the next agent run cannot repeat it silently.',
        ],
      },
      {
        heading: 'First workflow to gate',
        paragraphs: [
          'Start with one production migration path. Require the agent to show target environment, dry-run output, backup or snapshot evidence, rollback plan, and human approval before it can run the command. That single workflow makes the value visible to engineering leaders immediately.',
        ],
      },
    ],
    faq: [
      {
        question: 'Should AI agents be allowed to run production database migrations?',
        answer: 'Only behind an approval gate. Production migrations should require target verification, dry-run output, backup or snapshot evidence, rollback plan, and human approval before the command executes.',
      },
      {
        question: 'What database actions should be blocked by default?',
        answer: 'DROP, TRUNCATE, DROP DATABASE, DROP SCHEMA, role or grant changes, unbounded UPDATE or DELETE, and production migrations without rollback and dry-run evidence should be blocked or paused before execution.',
      },
      {
        question: 'Is this an AI DBA replacement?',
        answer: 'No. ThumbGate is the governance layer before an agent touches database tooling. It blocks known-bad actions and requires proof for risky actions; DBAs and platform teams still own database design and operations.',
      },
    ],
    relatedPaths: ['/guides/pre-action-checks', '/guides/ai-agent-pre-action-approval-gates', '/guides/best-tools-stop-ai-agents-breaking-production'],
  },
  buildHarnessOptimizationGuide(),
  buildCodeKnowledgeGraphGuardrailsGuide(),
  buildDeveloperMachineSupplyChainGuardrailsGuide(),
  buildPromptTricksToWorkflowRulesGuide(),
  buildBackgroundAgentGovernanceGuide(),
  buildAiAgentGovernanceSprintGuide(),
  buildAiDeploymentReadinessGuide(),
  buildModelUpgradeEvaluationGuide(),
  {
    query: 'stop ai coding agents from repeating mistakes',
    path: '/guides/stop-repeated-ai-agent-mistakes',
    pageType: 'guide',
    pillar: 'pre-action-checks',
    title: 'How to Stop AI Coding Agents From Repeating Mistakes | ThumbGate',
    heroTitle: 'How to Stop AI Coding Agents From Repeating Mistakes',
    heroSummary: 'If your agent keeps repeating the same bad move, the fix is not more memory alone. The fix is a feedback loop that turns repeated failures into pre-action checks before the next tool call executes.',
    takeaways: [
      'Repeated mistakes are a workflow problem, not just a context-window problem.',
      'ThumbGate turns thumbs-down feedback into prevention rules and runtime gates.',
      'This page is meant to move problem-aware buyers into the Pro path or a concrete install.',
    ],
    sections: [
      {
        heading: 'Why repeated mistakes keep happening',
        paragraphs: [
          'AI coding agents are fast, but they forget operational pain surprisingly easily. One bad deployment, force-push, or skipped verification step often turns into another because the system remembered the transcript but never enforced the lesson.',
          'That is why teams feel stuck in a correction loop. They keep teaching the same rule, but the next session still allows the same risky action.',
        ],
      },
      {
        heading: 'What changes when feedback becomes enforcement',
        bullets: [
          'Thumbs down captures the exact failure you do not want repeated.',
          'Repeated failures promote into linked prevention rules.',
          'Pre-action gates intercept the risky tool call before execution.',
          'Thumbs up reinforces the safe path so the agent learns what good looks like too.',
        ],
      },
      {
        heading: 'What a buyer should do next',
        paragraphs: [
          'If the pain is already real, do not start with a long architecture project. Start by wiring ThumbGate into the workflow where the agent has already burned time or trust, then watch the next repeat attempt get blocked before damage lands.',
        ],
      },
    ],
    faq: [
      {
        question: 'Is memory alone enough to stop repeated mistakes?',
        answer: 'Usually no. Memory helps retrieval, but ThumbGate adds pre-action checks so the same risky move can be blocked before the next command executes.',
      },
      {
        question: 'Does ThumbGate only punish bad behavior?',
        answer: 'No. Thumbs up reinforces good behavior, so the loop captures safe patterns as well as failures.',
      },
    ],
    relatedPaths: ['/guides/pre-action-checks', '/guides/claude-code-feedback'],
  },
  {
    query: 'claude code feedback memory',
    path: '/guides/claude-code-feedback',
    pageType: 'integration',
    pillar: 'agent-workflows',
    title: 'Claude Code Feedback Memory with Thumbs Up and Thumbs Down',
    heroTitle: 'Claude Code Feedback Memory That Actually Enforces',
    heroSummary: 'Claude Code can remember more when the memory is structured, but reliability improves when thumbs-up/down feedback also becomes enforceable behavior. That is ThumbGate\'s angle.',
    takeaways: [
      'Claude Code users usually feel the pain as repeated mistakes across sessions.',
      'ThumbGate captures the thumbs-up/down signal and turns it into memory, rules, and gates.',
      'The page should convert Claude Code searchers into a product trial or a comparison-page reader.',
    ],
    sections: [
      {
        heading: 'The Claude Code problem',
        paragraphs: [
          'Claude Code is strongest when the context is fresh, but teams still hit repeated mistakes, compaction drift, and re-explaining constraints. A memory file alone helps, but it does not physically stop the next bad move.',
        ],
      },
      {
        heading: 'The ThumbGate angle',
        bullets: [
          'Thumbs up reinforces good behavior.',
          'Thumbs down becomes a prevention rule.',
          'Pre-action gates stop the repeated mistake before the next command executes.',
          'The same flow works across Cursor, Codex, Gemini, Amp, and OpenCode.',
        ],
      },
      {
        heading: 'What to show on this page',
        paragraphs: [
          'Compatibility proof, install speed, and verification evidence matter more than generic "memory" copy. The buyer should leave knowing that ThumbGate is the enforcement layer for Claude Code, not just another notebook of past context.',
        ],
      },
    ],
    faq: [
      {
        question: 'Does this only work with Claude Code?',
        answer: 'No. Claude Code is a strong entry point, but the same thumbs-up/down feedback loop and pre-action checks work across other MCP-compatible coding agents too.',
      },
      {
        question: 'Why mention thumbs up as well as thumbs down?',
        answer: 'Because reinforcement matters. Good behavior should become easier to repeat, not only bad behavior harder to repeat.',
      },
    ],
    relatedPaths: ['/guides/pre-action-checks', '/compare/mem0'],
  },
  {
    query: 'cursor prevent repeated mistakes',
    path: '/guides/cursor-agent-guardrails',
    pageType: 'integration',
    pillar: 'agent-workflows',
    title: 'Cursor Agent Guardrails | Stop Repeated Mistakes with ThumbGate',
    heroTitle: 'Cursor Guardrails That Block Repeated Mistakes',
    heroSummary: 'Cursor moves fast, which makes repeated mistakes expensive. ThumbGate gives Cursor users a feedback loop that turns thumbs-down corrections into pre-action checks before the next risky step fires.',
    takeaways: [
      'Cursor users want speed without trusting the agent blindly.',
      'ThumbGate adds enforcement without forcing a platform switch.',
      'The page should answer the buyer question in one line: how do I stop Cursor from doing the same bad thing again?',
    ],
    sections: [
      {
        heading: 'The Cursor workflow problem',
        paragraphs: [
          'Cursor can move from idea to edits quickly, but the failure mode is familiar: the same wrong refactor, risky shell command, or skipped check comes back in the next session because nothing hardened the workflow.',
        ],
      },
      {
        heading: 'How ThumbGate fits into Cursor',
        bullets: [
          'Capture thumbs-up/down feedback on agent behavior.',
          'Promote repeated failures into prevention rules.',
          'Block known-bad commands with pre-action checks before execution.',
          'Keep the memory and gates local-first so the operator retains control.',
        ],
      },
      {
        heading: 'What makes this different from a rule file',
        paragraphs: [
          'Static rules help on day one. ThumbGate helps on day two and day twenty because it keeps learning from live corrections instead of relying on a fixed checklist that drifts out of date.',
        ],
      },
    ],
    faq: [
      {
        question: 'Do I need to leave Cursor to use ThumbGate?',
        answer: 'No. ThumbGate is designed to sit alongside existing coding-agent workflows so you can add enforcement without switching tools.',
      },
      {
        question: 'What kind of mistakes can Cursor guardrails stop?',
        answer: 'Repeated failures like risky git actions, destructive scripts, skipped verification, or any other known-bad pattern you have already corrected once.',
      },
    ],
    relatedPaths: ['/guides/stop-repeated-ai-agent-mistakes', '/guides/pre-action-checks'],
  },
  {
    query: 'codex cli guardrails',
    path: '/guides/codex-cli-guardrails',
    pageType: 'integration',
    pillar: 'agent-workflows',
    title: 'Codex CLI Guardrails | Prevent Repeated Mistakes with ThumbGate',
    heroTitle: 'Codex CLI Guardrails That Actually Enforce',
    heroSummary: 'Codex CLI can move quickly through repo tasks, but buyers need more than good intentions. ThumbGate adds a reliability gateway so repeated mistakes become searchable lessons, linked rules, and pre-action enforcement.',
    takeaways: [
      'Codex CLI buyers are usually looking for safe autonomy, not just more prompts.',
      'ThumbGate sits in the critical gap between feedback and execution.',
      'This page should rank for people who want guardrails without giving up CLI speed.',
    ],
    sections: [
      {
        heading: 'What Codex CLI users usually need',
        paragraphs: [
          'The problem is rarely a single bad command. It is the cost of the same failure pattern showing up across branches, sessions, or rushed workflows. Once that pattern is obvious, the buyer wants a durable control point.',
        ],
      },
      {
        heading: 'What ThumbGate adds',
        bullets: [
          'Feedback capture with explicit thumbs-up/down signals.',
          'Searchable lessons and linked prevention rules.',
          'Pre-action checks that block repeated bad commands before they run.',
          'Verification evidence that gives teams something concrete to audit.',
        ],
      },
      {
        heading: 'Why this matters for revenue',
        paragraphs: [
          'Guardrails are easier to buy when the outcome is obvious: less rework, fewer repeated failures, and a visible chain from operator feedback to enforced behavior.',
        ],
      },
    ],
    faq: [
      {
        question: 'Is ThumbGate only for Codex CLI?',
        answer: 'No. Codex CLI is one supported workflow, but the same feedback and enforcement loop also works across Claude Code, Cursor, Gemini, Amp, and OpenCode.',
      },
      {
        question: 'How are Codex CLI guardrails different from prompt instructions?',
        answer: 'Prompt instructions are advisory. ThumbGate pre-action checks intercept the tool call itself and block the known-bad pattern before execution.',
      },
    ],
    relatedPaths: ['/guides/pre-action-checks', '/compare/mem0'],
  },
  {
    query: 'gemini cli feedback memory',
    path: '/guides/gemini-cli-feedback-memory',
    pageType: 'integration',
    pillar: 'agent-workflows',
    title: 'Gemini CLI Feedback Memory | Memory Plus Enforcement with ThumbGate',
    heroTitle: 'Gemini CLI Feedback Memory That Leads to Enforcement',
    heroSummary: 'Gemini CLI users often start by asking for better memory. ThumbGate answers the bigger need: memory that can become prevention rules and pre-action checks when the same mistake shows up twice.',
    takeaways: [
      'Gemini CLI searchers often begin with memory but buy because of enforcement.',
      'ThumbGate keeps the local-first memory story while adding runtime blocking.',
      'The ideal conversion path here is memory query to product proof to Pro page.',
    ],
    sections: [
      {
        heading: 'Why memory is only step one',
        paragraphs: [
          'Persistent memory helps Gemini CLI recall past context, but it still leaves a blind spot. Remembering that a workflow went badly is different from preventing the next risky action when the same pattern appears again.',
        ],
      },
      {
        heading: 'What ThumbGate adds on top',
        bullets: [
          'Local-first lessons you can search across sessions.',
          'Structured thumbs-up/down feedback for reinforcement and correction.',
          'Prevention rules linked to past failures.',
          'Pre-action gates that stop repeated mistakes before execution.',
        ],
      },
      {
        heading: 'Who this is really for',
        paragraphs: [
          'This page is for operators who already know memory matters, but now need a reliability layer that protects live workflows instead of just preserving notes about them.',
        ],
      },
    ],
    faq: [
      {
        question: 'Does ThumbGate replace Gemini CLI memory?',
        answer: 'No. ThumbGate extends the memory story with searchable lessons, rules, and gates so memory becomes operationally useful instead of purely historical.',
      },
      {
        question: 'Can this stay local-first?',
        answer: 'Yes. ThumbGate is built for local-first workflows, which lowers risk for developers who do not want sensitive history pushed into a hosted memory layer.',
      },
    ],
    relatedPaths: ['/compare/mem0', '/guides/stop-repeated-ai-agent-mistakes'],
  },
  {
    query: 'hermes agent guardrails',
    path: '/guides/hermes-agent-guardrails',
    pageType: 'integration',
    pillar: 'agent-workflows',
    title: 'Hermes Agent Guardrails | Firewall for Self-Improving Agents',
    heroTitle: 'Hermes Agent can grow with you. ThumbGate keeps the growing agent safe.',
    heroSummary: 'Hermes Agent points at the next wave: persistent memory, generated skills, messaging gateways, scheduled automations, and sandboxed execution. ThumbGate is the enforcement layer those workflows need before a remembered mistake becomes another real tool call.',
    takeaways: [
      'Hermes validates the market shift toward long-running, self-improving agents.',
      'Memory and generated skills increase leverage, but they also increase the blast radius of repeated mistakes.',
      'ThumbGate should be positioned as the local-first pre-action firewall for Hermes-style agents, not as a general agent clone.',
    ],
    sections: [
      {
        heading: 'Why Hermes-style agents need a separate execution gate',
        paragraphs: [
          'A persistent agent can remember projects, generate its own skills, run scheduled automations, and accept instructions from messaging gateways. That is powerful, but it also means one bad habit can persist longer and reach more surfaces.',
          'The safety problem is not only whether the agent remembers. It is whether remembered lessons can stop the next risky shell command, git action, database write, deploy, browser click, or payment workflow before execution.',
        ],
      },
      {
        heading: 'What ThumbGate adds to Hermes-style workflows',
        bullets: [
          'Pre-action checks before risky tool calls execute.',
          'Thumbs-down feedback that becomes explicit prevention rules.',
          'Evidence requirements for deploys, migrations, API calls, and production-facing changes.',
          'Audit trails that show which lesson, rule, and workflow context allowed or blocked the action.',
          'A local-first path for teams that want agent memory without handing every correction to a hosted black box.',
        ],
      },
      {
        heading: 'The buyer message',
        paragraphs: [
          'Hermes can be the agent that grows with you. ThumbGate is the firewall that makes sure growth does not mean repeating expensive mistakes faster across more surfaces.',
          'For teams evaluating persistent agents, the practical first step is not another prompt. It is one enforced rule from one real failure, proven locally, then expanded into Pro or a workflow hardening sprint when the risk is recurring.',
        ],
      },
    ],
    faq: [
      {
        question: 'Does ThumbGate replace Hermes Agent?',
        answer: 'No. Hermes is a general self-improving agent surface. ThumbGate is the enforcement layer that can sit around Hermes-style workflows so risky actions are checked before execution.',
      },
      {
        question: 'What Hermes features create the biggest need for guardrails?',
        answer: 'Persistent memory, generated skills, messaging gateways, scheduled automations, browser and tool control, and sandbox backends all increase the value of pre-action gates because the agent can act longer, faster, and from more entry points.',
      },
      {
        question: 'What should teams implement first?',
        answer: 'Start with one repeated failure pattern: force-push, destructive SQL, unsafe deploy, risky browser action, or off-scope file edit. Capture it once, convert it into a prevention rule, and require evidence before the next similar action runs.',
      },
    ],
    relatedPaths: ['/guides/long-running-agent-context-management', '/guides/background-agent-governance', '/guides/browser-automation-safety'],
  },
  {
    query: 'safe self evolution',
    path: '/guides/safe-self-evolution',
    pageType: 'guide',
    pillar: 'agent-workflows',
    title: 'Safe Self-Evolution | Autonomous Prompt Optimization without Regression',
    heroTitle: 'Self-Evolution is Polarizing. Make It Safe with Execution Gates.',
    heroSummary: 'Hermes-style autonomous agents learn by observing their own execution failures and automatically rewriting their skills or instructions. But critics warn that blind self-evolution can overwrite stable patterns and introduce silent regressions. ThumbGate introduces the Safe Self-Evolution loop: weakness mining from explicit thumbs-down feedback, automated prompt optimization, local verification suites, and atomic git rollbacks.',
    takeaways: [
      'Self-improving agents need execution guardrails so a synthesized skill cannot bypass safety constraints.',
      'Blind self-evolution is unstable; ThumbGate ensures prompt changes are verified against a local holdout suite before committing.',
      'Rollback capability is mandatory: if validation fails, the evolution engine immediately reverts prompts to the last known-good state.',
      'Explicit feedback is the anchor: optimize based on real thumbs-down signals, not hallucinatory failure guesses.'
    ],
    sections: [
      {
        heading: 'The self-evolution dilemma',
        paragraphs: [
          'Nous Research’s Hermes Agent points at a future where developers do not write static instructions like CLAUDE.md. Instead, the agent learns from its execution failures and modifies its own SKILL.md files in real-time. This dynamic adaptation yields massive speedups and handles custom codebase quirks autonomously.',
          'However, the critics are correct: when an agent has the power to edit its own rules without a verification gate, it will eventually overwrite a perfectly stable skill. This introduces regressions, makes debugging impossible, and can lead to security loops where the agent modifies its own guardrails to make a failing task pass.'
        ]
      },
      {
        heading: 'Safe self-evolution with ThumbGate',
        paragraphs: [
          'ThumbGate implements a Safe Self-Evolution loop (based on the Self-Harness paradigm) that gives you the speed of self-improving agents without the instability:',
          '1. Explicit Weakness Mining: ThumbGate captures structured thumbs-up/down signals on agent actions and compiles them into a JSON log, avoiding random self-diagnosis.',
          '2. Harness Proposal: The self-harness-optimizer automatically formats these rules and injects them directly into the agent’s prompt instructions (AGENTS.md, GEMINI.md).',
          '3. Verification Gate: Before the updated prompts are committed, the optimizer runs a local quick verification suite and holdout tests.',
          '4. Atomic Rollback: If any test fails, the optimizer instantly reverts the workspace prompts and restores the previous snapshot. If they pass, it commits the update to Git.'
        ]
      },
      {
        heading: 'Competing with blind self-improvement',
        paragraphs: [
          'To compete with agents like Hermes, you do not need to give up control of your codebase. You need a pre-action firewall and a prompt optimizer that treats rule generation as code changes—complete with tests, verification, and rollbacks.',
          'This keeps your agent fast, keeps your instructions dynamic, and ensures your production-facing surfaces remain secure.'
        ]
      }
    ],
    faq: [
      {
        question: 'Does ThumbGate prevent the agent from changing its own rules?',
        answer: 'Yes. ThumbGate scans newly generated skills and prompt updates against established rules to prevent the agent from bypassing safety gates or deleting security constraints.'
      },
      {
        question: 'How does the rollback mechanism work?',
        answer: 'When the self-harness optimizer proposes new prompt sections, it saves a snapshot of the current prompt files. It then runs the verification commands. If the status is non-zero, it restores the backup files.'
      },
      {
        question: 'Is this compatible with Hermes Agent?',
        answer: 'Yes. You can use ThumbGate as the pre-action gate around a Hermes Agent deployment to secure the skills it generates and the messaging channels it posts to.'
      }
    ],
    relatedPaths: ['/guides/hermes-agent-guardrails', '/guides/agent-context-governance', '/guides/stop-repeated-ai-agent-mistakes'],
  },
  {
    query: 'agent context governance',
    path: '/guides/agent-context-governance',
    pageType: 'guide',
    pillar: 'pre-action-checks',
    title: 'Agent Context Governance | Stop Tokenmaxxing Drift Before Agents Act',
    heroTitle: 'More Context Is Not Governance. Clean Context Plus Action Gates Is.',
    heroSummary: 'AdaCoM-style context managers, the tokenmaxxing backlash, Claude Managed Agents, anti-rubber-stamp response prompts, model-provenance scares, ChatGPT Lockdown Mode, MCP routing attacks, resilient graph architectures, rising AI-authored code volume, AI email assistants, platform-agent orchestration, on-device QAT models, and backprop-style failure attribution all point to the same buyer need: long-running agents need structured intent, cleaner context, durable session logs, approved models, isolated execution, credential boundaries, tool lockdown, direct pushback, distributed gates, provenance, and pre-action checks before they touch real systems.',
    takeaways: [
      'Long-context agents get better when a separate manager rewrites, preserves, prunes, or merges working context before the next step.',
      'Tokenmaxxing creates uncontrolled spend and weak governance when teams cannot prove which agent work returned value.',
      'Managed-agent architectures decouple the brain, hands, sessions, credentials, and sandboxes; ThumbGate adds the local-first action gate around those boundaries.',
      'Response customization should become a gate too: no padded agreement, no vague completion claims, and no confident answer without evidence or blind-spot checks.',
      'Lockdown modes validate the egress-control story: sensitive workflows need tool-surface limits, not just better prompts.',
      'Model leaks and proxy resale scares make approved-provider checks a governance requirement, especially when frontier model cost is high.',
      'MCP security research makes local config integrity a first-class control: endpoint rewrites and token-routing changes must be monitored before agents act.',
      'Random-graph infrastructure suggests a governance architecture: use many small local gates that degrade proportionally instead of one central approval bottleneck.',
      'As AI-authored code volume rises, teams need provenance and evidence gates so generated diffs are attributable, tested, and owned before merge.',
      'AI customer-response assistants need draft governance: retrieved sources, prompt variables, category routing, and feedback should improve drafts without letting the agent send unsupported claims.',
      'Enterprise agent platforms need one shared execution contract: structured specs, approved tools, scoped permissions, retries, evals, and traceability instead of 100 fragile team-specific agents.',
      'On-device QAT models can reduce cost and preserve privacy for first-pass risk classification, but they should escalate rather than approve high-risk actions.',
      'Backpropagation suggests a useful product metaphor: trace the agent run graph, score local risk at each edge, and cache the blame path so the same failure is blocked faster next time.',
    ],
    sections: [
      {
        heading: 'Why this matters now',
        paragraphs: [
          'The market is moving away from prompt-only agents. New research shows that a separate context manager can improve long-horizon work without retraining the main agent. At the same time, developer teams are realizing that simply buying more tokens does not create accountable engineering process.',
          'Claude Managed Agents adds the production vocabulary buyers now expect: agents, environments, sessions, sandbox isolation, credential separation, event logs, observability, permission policies, outcomes, and webhooks. ThumbGate should attach to that vocabulary as the pre-action governance layer.',
        ],
      },
      {
        heading: 'What ThumbGate should enforce',
        bullets: [
          'Context hygiene gate: block high-risk actions when the agent is acting from raw chat history, stale memory, or unresolved contradictions.',
          'Session evidence gate: require an append-only event log, resumable session ID, and proof links before long-running work can deploy, charge, message, or mutate production data.',
          'Sandbox boundary gate: require isolated execution and explicit network or filesystem scope before generated code runs.',
          'Credential boundary gate: block actions where tool credentials live beside generated code or where the action lacks user/on-behalf-of attribution.',
          'Token ROI gate: flag tokenmaxxing workflows that spend heavily without a defined outcome, eval, or proof of returned value.',
          'Response quality gate: require the agent to lead with the useful answer, call out weak assumptions, and avoid completion claims unless the evidence is attached.',
          'Model provenance gate: require approved provider domains, known model IDs, expected price ceilings, and no shadow API proxy before routing frontier work.',
          'Tool lockdown gate: disable or require explicit approval for browsing, downloads, agent mode, generated-code networking, and other outbound paths when sensitive data is in context.',
          'MCP config integrity gate: alert on ~/.claude.json routing changes, unfamiliar MCP endpoints, localhost proxy additions, OAuth refresh anomalies, and dependency postinstall hooks.',
          'Distributed gate mesh: keep enforcement close to each repo, tool, and workflow so one failed gate reduces coverage locally instead of collapsing the entire governance path.',
          'AI-authored code gate: require generated-diff provenance, human owner, tests, risk label, and rollback evidence once agent-authored changes cross a team-defined threshold.',
          'Customer-response draft gate: require retrieved source links, customer objective, response category, human approval, and no unsupported pricing/security claims before an email leaves draft mode.',
          'Structured intent gate: require scope, out-of-scope systems, ordered steps, allowed tools, acceptance criteria, and rollback expectations before async agent execution starts.',
          'Tool contract gate: require versioned schemas, explicit read/write permissions, stable error codes, observability hooks, and audit logging for every MCP tool call.',
          'Evaluation gate: require golden tasks, regression checks, build/test evidence, and traceable PR or artifact output before a repeated workflow is promoted to platform automation.',
          'Local classifier gate: run low-cost on-device models for first-pass risk labels, sensitive-data detection, and route selection, then escalate uncertain or high-blast-radius actions to stronger checks.',
          'Failure attribution graph: record intent, retrieved context, tool choice, local risk score, evidence, and outcome for each step so future gates reuse the causal path instead of starting from scratch.',
        ],
      },
      {
        heading: 'The buyer message',
        paragraphs: [
          'The pitch is not "use fewer tokens" or "summarize harder." The pitch is: keep the agent productive by feeding it the right context, then stop it before risky actions unless the session, sandbox, credentials, and evidence are clean.',
          'This turns ThumbGate into the practitioner-led governance layer teams can adopt before top-down AI policy arrives. Start with one workflow, prove the gates locally, then expand to Pro or a hardening sprint once the same failure pattern recurs.',
        ],
      },
    ],
    faq: [
      {
        question: 'Is agent context governance just summarization?',
        answer: 'No. Summarization compresses. Context governance decides what to preserve, prune, merge, verify, or block based on the agent, task, risk, and evidence required before the next action.',
      },
      {
        question: 'Does this compete with Claude Managed Agents?',
        answer: 'No. Managed Agents provide production infrastructure. ThumbGate can sit beside managed or self-hosted agents as the local-first gate that turns session history, permissions, prior feedback, and evidence requirements into action-level enforcement.',
      },
      {
        question: 'What should teams implement first?',
        answer: 'Start with one high-cost workflow: deployments, billing, browser automation, database changes, or customer messaging. Require clean context, isolated execution, credential separation, and evidence before that workflow can run.',
      },
      {
        question: 'How does this apply to Claude custom instructions?',
        answer: 'Treat directness instructions as a policy, not a vibe. ThumbGate can turn them into checks that flag rubber-stamp agreement, missing pushback, and success claims that are not grounded in command output or artifacts.',
      },
      {
        question: 'How does ChatGPT Lockdown Mode help ThumbGate positioning?',
        answer: 'It validates the category. Lockdown Mode limits high-risk tools to reduce exfiltration paths; ThumbGate brings the same idea to coding and automation agents with local pre-action checks, scoped approvals, and audit evidence.',
      },
      {
        question: 'How should teams handle leaked or proxy-sold model claims?',
        answer: 'Do not route production work to unapproved proxy endpoints. Require provider provenance, expected model IDs, price ceilings, and security review before an agent can use a new frontier model route.',
      },
      {
        question: 'What is the first MCP security control to add?',
        answer: 'Watch the local MCP routing configuration for endpoint changes, new proxy addresses, and unexpected OAuth refresh behavior. Then rotate connected tokens only after the malicious hook or config rewrite has been removed.',
      },
      {
        question: 'Why mention random graph architecture in agent governance?',
        answer: 'Because centralized approval paths become bottlenecks. ThumbGate should use a mesh of local gates across repos, tools, agents, and workflows so control is resilient, inspectable, and does not require one fragile platform migration.',
      },
      {
        question: 'What changes when most new code is AI-authored?',
        answer: 'Review moves from typing every line to governing provenance, tests, ownership, and rollback. ThumbGate can require evidence before AI-authored diffs merge or touch production workflows.',
      },
      {
        question: 'How does this apply to AI email assistants?',
        answer: 'Treat every generated reply as a draft until it has source-backed context, a known category, customer-specific constraints, and human approval. Feedback from edited drafts should become retrieval and wording rules, not permission to send automatically.',
      },
      {
        question: 'What does platform ownership change?',
        answer: 'It prevents every team from building a slightly different unsafe agent loop. A shared platform defines intent shape, approved tools, retries, sandboxing, evals, logging, and gates while teams keep control over domain judgment.',
      },
      {
        question: 'Where do on-device QAT models fit?',
        answer: 'Use them for cheap private triage: classify risk, detect sensitive context, choose a route, or decide whether to escalate. Do not let a small local classifier silently approve destructive or external actions.',
      },
      {
        question: 'How does backpropagation help agent governance?',
        answer: 'Use the chain-rule idea as an audit pattern. Break the run into steps, score each local decision, multiply risk through the path, and cache the attribution so the next similar workflow is blocked or escalated earlier.',
      },
    ],
    relatedPaths: ['/guides/long-running-agent-context-management', '/guides/background-agent-governance', '/guides/hermes-agent-guardrails'],
  },
  {
    query: 'roo code alternative cline',
    path: '/guides/roo-code-alternative-cline',
    pageType: 'integration',
    pillar: 'agent-workflows',
    title: 'Roo Code Alternative: Migrating to Cline with Portable Lesson Memory',
    heroTitle: 'Roo Code Alternative: Migrate to Cline Without Losing Agent Memory',
    heroSummary: 'Roo Code is shutting down on May 15, 2026, and its own docs point users to Cline. ThumbGate keeps the migration from resetting every hard-won thumbs-down and workflow correction back to zero.',
    takeaways: [
      'Roo users have a time-bound migration problem with clear buyer urgency.',
      'The real wedge is portable lesson memory, not just swapping one VS Code extension for another.',
      'The page should answer the migration question and route serious operators into a local-first enforcement path.',
    ],
    sections: [
      {
        heading: 'Why the migration risk is bigger than the extension swap',
        paragraphs: [
          'Roo users can usually move to Cline without much trouble at the MCP layer. The hidden risk is losing every correction that only lived in the old agent context.',
          'If the same git, deploy, or migration mistake has to be re-taught from scratch after the swap, the migration cost is higher than it looks.',
        ],
      },
      {
        heading: 'What ThumbGate adds to the move',
        bullets: [
          'Keep lessons in a local SQLite plus FTS5 store instead of vendor-scoped memory.',
          'Turn repeated failures into prevention rules and pre-action checks before the next tool call runs.',
          'Reuse the same local memory across Cline, Claude Code, Cursor, Codex, Gemini CLI, Amp, and other MCP-compatible agents.',
          'Give migration buyers a proof-backed install path instead of another generic memory promise.',
        ],
      },
      {
        heading: 'Why this converts',
        paragraphs: [
          'A migration deadline creates urgency, but the stronger buying reason is avoiding repeated rework after the switch. Portable lesson memory plus enforced checks is the part buyers can immediately understand and verify.',
        ],
      },
    ],
    faq: [
      {
        question: 'Why not just switch from Roo to Cline and keep going?',
        answer: 'Because the workflow memory can still reset if past corrections only lived inside the old agent context. ThumbGate keeps those lessons in a local store that survives the vendor swap.',
      },
      {
        question: 'Does ThumbGate only help with Cline?',
        answer: 'No. Cline is the immediate migration path, but the same local lesson memory and pre-action checks work across other MCP-compatible coding agents too.',
      },
    ],
    relatedPaths: ['/guides/codex-cli-guardrails', '/guides/stop-repeated-ai-agent-mistakes'],
  },
  ...BROWSER_BRIDGE_GUIDE_SPECS.map(buildBrowserBridgeGuide),
  ...AI_RECOMMENDATION_VISIBILITY_GUIDE_SPECS.map(buildAiRecommendationVisibilityGuide),
  {
    query: 'mcp tool governance',
    path: '/guides/mcp-tool-governance',
    pageType: 'guide',
    pillar: 'pre-action-checks',
    title: 'MCP Tool Governance | Pre-Action Gates Before Agents Call Tools',
    heroTitle: 'MCP tool governance before agents call real systems',
    heroSummary: 'MCP makes tools easy for agents to discover and call. ThumbGate adds the missing governance layer: approval boundaries, evidence requirements, and audit logs before high-risk MCP tool calls execute.',
    takeaways: [
      'MCP adoption expands what agents can touch, so teams need a tool-call control plane.',
      'Governance belongs before execution, not only in post-run logs or prompt rules.',
      'ThumbGate turns feedback, policies, and evidence requirements into enforceable pre-action gates for MCP-compatible agent workflows.',
    ],
    sections: [
      {
        heading: 'Why MCP changes the risk model',
        paragraphs: [
          'MCP turns databases, file systems, browsers, ticketing systems, cloud APIs, and internal tools into surfaces an agent can call. That is useful, but it also means a bad plan can become a real action faster than a human reviewer can notice.',
          'The governance question is no longer only which tools exist. It is which agent, workflow, branch, file path, command, customer record, or environment is allowed to use each tool under which proof requirements.',
        ],
      },
      {
        heading: 'What MCP tool governance needs',
        bullets: [
          'Tool inventory: know which tools are exposed to which agents and runtimes.',
          'Risk tiers: classify destructive, customer-facing, production, payment, and data-export tools differently from read-only tools.',
          'Pre-action checks: require evidence or approval before risky calls execute.',
          'Feedback loops: turn thumbs-down reviews and incidents into reusable prevention rules.',
          'Audit proof: log allowed, blocked, and approved tool calls with enough context for review.',
        ],
      },
      {
        heading: 'Where ThumbGate fits',
        paragraphs: [
          'ThumbGate sits between generated intent and executed action. The agent can still plan and propose MCP tool calls, but ThumbGate checks the call against learned lessons, policy boundaries, evidence requirements, and workflow risk before the tool runs.',
        ],
      },
    ],
    faq: [
      {
        question: 'What is MCP tool governance?',
        answer: 'MCP tool governance is the policy, approval, evidence, and audit layer around tools exposed through Model Context Protocol so agents do not call high-risk systems without the right checks.',
      },
      {
        question: 'How is this different from an MCP server allowlist?',
        answer: 'An allowlist says a tool exists or is available. ThumbGate adds runtime context: tool arguments, branch, path, environment, prior feedback, evidence requirements, and whether this exact action should be allowed now.',
      },
      {
        question: 'Can ThumbGate work across multiple MCP-compatible agents?',
        answer: 'Yes. The same local-first lesson and pre-action gate pattern is designed for Claude Code, Cursor, Codex, Gemini, Amp, Cline, OpenCode, and MCP-compatible workflows.',
      },
    ],
    relatedPaths: ['/guides/pre-action-checks', '/guides/ai-mode-ads-agent-governance', '/guides/background-agent-governance'],
  },
  {
    query: 'ai agent pre action approval gates',
    path: '/guides/ai-agent-pre-action-approval-gates',
    pageType: 'guide',
    pillar: 'pre-action-checks',
    title: 'AI Agent Pre-Action Approval Gates | Human Review Before Risky Tool Calls',
    heroTitle: 'AI agent pre-action approval gates for risky tool calls',
    heroSummary: 'Human review after the damage lands is too late. ThumbGate adds pre-action approval gates so risky AI-agent commands, deploys, file edits, API calls, and MCP tool calls can require evidence or explicit approval before execution.',
    takeaways: [
      'Approval gates matter most at the action boundary, where the agent is about to touch files, terminals, APIs, CI, payments, or production systems.',
      'The right gate can block, pause for approval, or log-and-continue depending on risk.',
      'ThumbGate converts prior thumbs-downs, workflow policies, and verification expectations into reusable approval rules.',
    ],
    sections: [
      {
        heading: 'Why approval must happen before execution',
        paragraphs: [
          'Many agent failures are irreversible or expensive by the time a post-run reviewer sees them: force-pushes, destructive SQL, unsafe deploys, leaked secrets, customer-facing messages, and runaway API calls.',
          'A pre-action approval gate pauses the action while there is still something to decide. The agent keeps its speed on safe work, but risky work requires proof, policy match, or a human yes.',
        ],
      },
      {
        heading: 'Three practical gate outcomes',
        bullets: [
          'Block: deny known-bad actions such as force-pushing protected branches or touching secret files.',
          'Approve: pause production deploys, schema migrations, payment actions, or customer-facing sends until a human approves.',
          'Log: allow lower-risk actions while preserving audit evidence for review and future lessons.',
        ],
      },
      {
        heading: 'How ThumbGate turns approvals into learning',
        paragraphs: [
          'Every approval, block, and thumbs-down gives the system better operating context. Repeated failures become prevention rules, accepted safe paths become reinforced lessons, and the audit trail gives teams evidence that the boundary fired before execution.',
        ],
      },
    ],
    faq: [
      {
        question: 'What should require a pre-action approval gate?',
        answer: 'Production deploys, destructive database actions, protected-branch writes, payment or refund actions, customer-facing sends, secret or PII access, high-cost API calls, and any repeated failure pattern the team has already corrected once.',
      },
      {
        question: 'Do approval gates slow every agent action down?',
        answer: 'No. Good gates are risk-tiered. Safe actions can continue, uncertain actions can be logged, risky actions can pause for approval, and known-bad actions can be blocked.',
      },
      {
        question: 'How does ThumbGate know what to block?',
        answer: 'ThumbGate uses explicit feedback, learned lessons, policy templates, command and path context, evidence requirements, and prior gate outcomes to decide whether the proposed action should proceed.',
      },
    ],
    relatedPaths: ['/guides/pre-action-checks', '/guides/mcp-tool-governance', '/guides/ai-agent-governance-sprint'],
  },
  {
    query: 'agentic web governance',
    path: '/guides/agentic-web-governance',
    pageType: 'guide',
    pillar: 'pre-action-checks',
    title: 'Agentic Web Governance | Pre-Action Checks When Bots Outnumber Humans',
    heroTitle: 'Bots already outnumber humans on the web. AI agents need pre-action governance.',
    heroSummary: 'Cloudflare says automated requests now make up the majority of HTML traffic. ThumbGate turns that agentic-web shift into a buyer-ready governance story: machine-readable proof for AI search and pre-action checks before agents touch real systems.',
    takeaways: [
      'The promotion hook is immediate: the web is becoming agent-first, so AI-agent actions need governance before execution.',
      'AI search and AI browsers reward machine-readable, authoritative, proof-backed pages instead of vague product copy.',
      'ThumbGate should own the bridge between agentic traffic, MCP tool calls, and pre-action checks for code, deploys, data, money, and customer systems.',
    ],
    sections: [
      {
        heading: 'Why the bot-majority milestone matters',
        paragraphs: [
          'Search Engine Land reported on June 5, 2026 that Cloudflare data showed automated traffic at about 57.3% of worldwide HTTP requests to HTML content, versus 42.7% for humans. That is not the same as human attention, but it is a real signal that AI agents and bots are becoming the default way the web is requested, summarized, and acted on.',
          'For ThumbGate promotion, the lesson is not "get more bot traffic." The lesson is that every company will need controls for agent actions that happen before a human click, before a dashboard session, and before a normal attribution path records intent.',
        ],
      },
      {
        heading: 'The buyer problem this creates',
        bullets: [
          'AI crawlers and agents can visit far more pages than a human researcher, increasing load without creating normal referral or checkout signals.',
          'Agentic search can summarize the answer before the buyer ever lands on the site, so content must be structured enough for LLMs to cite accurately.',
          'Internal AI agents can also multiply actions: file edits, shell commands, API calls, database reads, deploy attempts, and customer-system writes.',
          'More agent actions without a pre-action boundary means more repeated mistakes, more hidden cost, and weaker auditability.',
        ],
      },
      {
        heading: 'Where ThumbGate fits the agentic web',
        paragraphs: [
          'ThumbGate is the pre-action governance layer for the same agentic shift. The public website gives AI systems machine-readable context, proof links, FAQ schema, and canonical pages. The product then gives engineering teams runtime gates before agents act.',
          'That lets the promotion story stay concrete: bots and AI agents already outnumber humans in web requests; ThumbGate makes sure your own AI agents do not behave like unmanaged bots inside your repo, browser, database, CI, payment flow, or customer systems.',
        ],
        bullets: [
          'Use /llm-context.md and /.well-known/llms.txt to make ThumbGate easy for ChatGPT, Claude, Perplexity, Gemini, Grok, and Google AI features to summarize.',
          'Use pre-action checks to govern MCP tool calls, browser automation, database writes, publish commands, and payment/customer-system actions.',
          'Use feedback capture so a thumbs-down on one bad agent pattern becomes a repeat-blocking rule across the next session and team workflow.',
        ],
      },
      {
        heading: 'High-ROI promotion moves',
        bullets: [
          'Publish this page as the canonical "agentic web governance" explainer and link it from the homepage, learn hub, llms.txt, and sitemap.',
          'Pitch the line: "Bots already outnumber humans on the web. ThumbGate keeps AI agents from acting like unmanaged bots in your codebase."',
          'Target buyer prompts such as "how do I govern AI agents before they call tools?", "AI crawler visibility for developer tools", and "pre-action checks for MCP tools."',
          'Measure success in Search Console AI reports, first-party landing events, and checkout/intake paths instead of raw traffic alone.',
        ],
      },
    ],
    faq: [
      {
        question: 'What is agentic web governance?',
        answer: 'Agentic web governance is the content, policy, approval, and runtime-control layer needed when AI agents browse, summarize, and act on behalf of users or teams. For ThumbGate, it means machine-readable public proof plus pre-action checks before internal agents touch real systems.',
      },
      {
        question: 'Does bot traffic mean ThumbGate should block AI crawlers?',
        answer: 'No. For promotion, ThumbGate should allow legitimate AI discovery while publishing clear llms.txt, schema, canonical pages, and proof links. The product should block risky internal agent actions, not useful AI-search discovery.',
      },
      {
        question: 'How does this create revenue?',
        answer: 'It gives ThumbGate a timely category narrative for buyers: as agent actions multiply, teams need pre-action controls before code, data, deploys, payments, or customers are touched. The page routes that demand into Pro checkout and the Team workflow hardening sprint.',
      },
    ],
    relatedPaths: ['/guides/ai-search-topical-presence', '/guides/mcp-tool-governance', '/guides/ai-agent-pre-action-approval-gates'],
  },
  guideBlueprint({
    query: 'autoresearch agent safety',
    path: '/guides/autoresearch-agent-safety',
    pillar: 'pre-action-checks',
    title: 'Autoresearch Agent Safety | Gates for Self-Improving Coding Agents',
    heroTitle: 'Autoresearch Agent Safety for Self-Improving Coding Agents',
    heroSummary: 'Autoresearch-style loops can search for better code, but they need gates for holdout tests, proof trails, reward hacking, and unsafe self-improvement.',
    takeaways: [
      'Self-improving coding loops need a control plane before they promote their own wins.',
      'ThumbGate turns failed experiment reviews into prevention rules and pre-action checks.',
      'The sales wedge is concrete: let the agent search, but gate the evidence before it accepts a variant.',
    ],
    sections: [
      paragraphs(
        'Why Autoresearch creates a new buying moment',
        [
          'Autoresearch-style systems run experiments, inspect results, and keep the variants that look better. That makes them powerful, but it also creates a trust gap for engineering teams.',
          'If the loop can edit the benchmark, skip a holdout, hide a failed run, or promote without proof, the buyer needs enforcement before autonomy expands.',
        ],
      ),
      bullets(
        'Where ThumbGate fits',
        [
          'Block promotion when required primary and holdout checks are missing.',
          'Require commands, changed files, logs, and verification evidence before a claimed improvement lands.',
          'Capture thumbs-down reviews when an experiment cheats the metric, then promote the pattern into a prevention rule.',
          'Use ContextFS packs and Thompson Sampling so recurring research failures get stricter over time.',
        ],
      ),
      paragraphs(
        'Starter harnesses that make the value visible',
        [
          'The first pack should wrap checks buyers already understand: npm test, lint, Playwright duration, bundle size, and CI status. Each one becomes a gate the buyer can see firing.',
        ],
      ),
    ],
    faq: [
      answer(
        'Why do Autoresearch-style agents need gates?',
        'A self-improving loop can optimize the wrong signal, skip holdout tests, or promote a cherry-picked run. ThumbGate blocks known-bad promotion patterns before the agent accepts the variant.',
      ),
      answer(
        'What does ThumbGate add to an Autoresearch loop?',
        'ThumbGate adds structured thumbs-up/down feedback, prevention rules, Thompson Sampling, ContextFS proof packs, and pre-action checks for risky experiment and promotion steps.',
      ),
    ],
    relatedPaths: ['/guides/pre-action-checks', '/guides/codex-cli-guardrails'],
  }),
  {
    query: 'claude desktop extension plugin thumbgate',
    path: '/guides/claude-desktop',
    pageType: 'integration',
    pillar: 'agent-workflows',
    title: 'ThumbGate for Claude Desktop | Install the Plugin in 60 Seconds',
    heroTitle: 'ThumbGate for Claude Desktop',
    heroSummary: 'Install ThumbGate as a Claude Desktop plugin and get pre-action checks running in under a minute. No build step, no cloud account, no config files.',
    takeaways: [
      'One command installs ThumbGate into Claude Desktop with zero config.',
      'The packaged .mcpb bundle is available on GitHub Releases for drag-and-drop install.',
      'All feedback, rules, and gates stay local on your machine.',
    ],
    sections: [
      {
        heading: 'Install with one command',
        paragraphs: [
          'Run this in your terminal and Claude Desktop picks up ThumbGate automatically:',
          'npx thumbgate init --claude-desktop',
          'Or add the MCP server directly:',
          'claude mcp add thumbgate -- npx -y thumbgate serve',
        ],
      },
      {
        heading: 'Or download the packaged bundle',
        paragraphs: [
          'Grab the .mcpb bundle from GitHub Releases — no build step required. Drop it into Claude Desktop and you are running.',
        ],
        bullets: [
          'Download from: github.com/IgorGanapolsky/ThumbGate/releases',
          'Works with Claude Desktop on macOS, Windows, and Linux.',
          'All data stays local. No cloud account needed.',
        ],
      },
      {
        heading: 'What you get',
        bullets: [
          'Thumbs-up/down feedback capture inside Claude Desktop.',
          'Prevention rules auto-generated from repeated failures.',
          'Pre-action checks that block known-bad patterns before execution.',
          'Full-text search across your lesson history.',
          'Health checks and system diagnostics.',
        ],
      },
      {
        heading: 'Verify it works',
        paragraphs: [
          'After install, run npx thumbgate doctor to confirm all subsystems are healthy. You should see 4/4 HEALTHY.',
        ],
      },
    ],
    faq: [
      {
        question: 'Do I need a cloud account?',
        answer: 'No. ThumbGate runs entirely locally. Your feedback, rules, and gates never leave your machine.',
      },
      {
        question: 'What is the .mcpb bundle?',
        answer: 'It is a packaged Claude Desktop extension that includes the ThumbGate MCP server, tool definitions, and manifest — ready to install without building from source.',
      },
      {
        question: 'Does this work with Claude Code too?',
        answer: 'Yes. The same npx thumbgate init command works for both Claude Desktop and Claude Code. Use --claude-desktop for the Desktop-specific setup.',
      },
    ],
    relatedPaths: ['/guides/claude-code-feedback', '/guides/pre-action-checks'],
  },
];

function normalizeText(value) {
  return String(value || '').replace(/\s+/g, ' ').trim();
}

function slugify(value) {
  return normalizeText(value)
    .toLowerCase()
    .split('')
    .map((char) => (/[a-z0-9]/.test(char) ? char : '-'))
    .join('')
    .split('-')
    .filter(Boolean)
    .join('-');
}

function toNumber(value) {
  if (value === undefined || value === null || value === '') return null;
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
}

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function parseCsvLine(line) {
  const cells = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    const next = line[i + 1];
    if (char === '"' && inQuotes && next === '"') {
      current += '"';
      i++;
      continue;
    }
    if (char === '"') {
      inQuotes = !inQuotes;
      continue;
    }
    if (char === ',' && !inQuotes) {
      cells.push(current);
      current = '';
      continue;
    }
    current += char;
  }
  cells.push(current);
  return cells.map((cell) => cell.trim());
}

function parseCsv(text) {
  const lines = String(text || '')
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
  if (lines.length === 0) return [];
  const headers = parseCsvLine(lines[0]).map((header) => slugify(header).replace(/-/g, '_'));
  return lines.slice(1).map((line) => {
    const values = parseCsvLine(line);
    return Object.fromEntries(headers.map((header, index) => [header, values[index] || '']));
  });
}

function loadKeywordRows(inputPath) {
  if (!inputPath) {
    return HIGH_ROI_QUERY_SEEDS.map((row) => ({ ...row }));
  }
  const resolved = path.resolve(inputPath);
  const raw = fs.readFileSync(resolved, 'utf8');
  if (resolved.endsWith('.json')) {
    const data = JSON.parse(raw);
    return Array.isArray(data) ? data : data.rows || [];
  }
  if (resolved.endsWith('.jsonl')) {
    return raw
      .split(/\r?\n/)
      .filter(Boolean)
      .map((line) => JSON.parse(line));
  }
  if (resolved.endsWith('.csv')) {
    return parseCsv(raw);
  }
  throw new Error(`Unsupported keyword input format for ${resolved}`);
}

function classifyIntent(query) {
  const normalized = normalizeText(query).toLowerCase();
  if (!normalized) return 'informational';
  if (/\b(vs|versus|alternative|compare|comparison|better than)\b/.test(normalized)) return 'comparison';
  if (/\b(price|pricing|buy|checkout|purchase|cost)\b/.test(normalized)) return 'transactional';
  if (/\b(autoresearch|self-improving|benchmark|reward hacking|agent safety|governance|deployment readiness|sprint)\b/.test(normalized)) return 'commercial';
  if (/\b(claude code|cursor|codex|gemini|amp|opencode|integration|plugin|setup|install)\b/.test(normalized)) {
    return 'commercial';
  }
  if (/\b(what is|how to|guide|best practices|why)\b/.test(normalized)) return 'informational';
  if (/\b(guardrails|pre-action checks|feedback|prevent repeated mistakes|repeating mistakes|memory|harness optimization)\b/.test(normalized)) {
    return 'commercial';
  }
  return 'informational';
}

function inferPillar(query) {
  const normalized = normalizeText(query).toLowerCase();
  if (/\b(speclock|mem0|alternative|vs|compare|comparison)\b/.test(normalized)) return 'comparison';
  if (/\b(thumbs up|thumbs down|feedback|reinforce|mistake)\b/.test(normalized)) return 'feedback-loop';
  if (/\b(programmatic seo|pseo|semantic seo|semantic programmatic|seo agent)\b/.test(normalized)) return 'seo-governance';
  if (/\b(rag|retrieval|proxy pointer|multimodal answer|document rag)\b/.test(normalized)) return 'document-rag-safety';
  if (/\b(topical presence|relational knowledge|recommend(?:ation|ed)? brands?|ai search visibility)\b/.test(normalized)) return 'ai-agent-reliability';
  if (/\b(browser automation|native messaging|browser bridge|prompt injection)\b/.test(normalized)) return 'pre-action-checks';
  if (/\b(autoresearch|self-improving|benchmark|reward hacking|harness optimization|long running agent|context management|reasoning compression|governance|sprint)\b/.test(normalized)) return 'pre-action-checks';
  if (/\b(pre-action checks|guardrails|block|prevent repeated mistakes|repeating mistakes)\b/.test(normalized)) return 'pre-action-checks';
  if (/\b(claude code|cursor|codex|gemini|amp|opencode|integration|plugin)\b/.test(normalized)) return 'agent-workflows';
  return 'ai-agent-reliability';
}

function inferPersona(query) {
  const normalized = normalizeText(query).toLowerCase();
  if (normalized.includes('claude code')) return 'claude-code-builder';
  if (normalized.includes('cursor')) return 'cursor-builder';
  if (normalized.includes('codex')) return 'codex-builder';
  if (normalized.includes('gemini')) return 'gemini-builder';
  if (normalized.includes('autoresearch') || normalized.includes('self-improving')) return 'ai-research-engineer';
  if (/\b(long running agent|context management|reasoning compression)\b/.test(normalized)) return 'platform-engineer';
  if (/\b(programmatic seo|pseo|semantic seo|ai search|topical presence|seo agent)\b/.test(normalized)) return 'growth-engineer';
  if (/\b(rag|retrieval|proxy pointer|multimodal answer|document rag)\b/.test(normalized)) return 'rag-engineer';
  if (/\b(vs|alternative|compare)\b/.test(normalized)) return 'tool-evaluator';
  if (/\b(guardrails|pre-action checks|governance|sprint)\b/.test(normalized)) return 'engineering-lead';
  return 'ai-engineer';
}

function inferPageType(intent, query) {
  const normalized = normalizeText(query).toLowerCase();
  if (intent === 'comparison') return 'comparison';
  if (/\b(claude code|cursor|codex|gemini|amp|opencode|integration|plugin)\b/.test(normalized)) return 'integration';
  if (/\b(guide|how to|what is|best practices)\b/.test(normalized)) return 'guide';
  return intent === 'transactional' ? 'money-page' : 'guide';
}

function scoreOpportunity(row) {
  const query = normalizeText(row.query);
  const intent = row.intent || classifyIntent(query);
  const pillar = row.pillar || inferPillar(query);
  const pageType = row.pageType || inferPageType(intent, query);
  let score = 0;

  const intentWeight = {
    comparison: 40,
    transactional: 38,
    commercial: 32,
    informational: 24,
  };
  const pageTypeWeight = {
    comparison: 20,
    integration: 16,
    'money-page': 18,
    guide: 14,
  };
  const pillarWeight = {
    comparison: 14,
    'pre-action-checks': 12,
    'feedback-loop': 12,
    'agent-workflows': 11,
    'seo-governance': 12,
    'document-rag-safety': 12,
    'ai-agent-reliability': 9,
  };

  score += intentWeight[intent] || 20;
  score += pageTypeWeight[pageType] || 12;
  score += pillarWeight[pillar] || 8;
  score += clamp(toNumber(row.businessValue) || 0, 0, 25);

  const impressions = toNumber(row.impressions);
  const clicks = toNumber(row.clicks);
  const ctr = toNumber(row.ctr);
  const position = toNumber(row.position);

  if (impressions !== null) score += clamp(impressions / 20, 0, 10);
  if (clicks !== null) score += clamp(clicks, 0, 10);
  if (ctr !== null) score += clamp(ctr * 100, 0, 6);
  if (position !== null) {
    if (position >= 4 && position <= 25) score += 6;
    else if (position > 25) score += 3;
  }

  if (/\bthumbgate\b/.test(query.toLowerCase())) score += 4;
  if (/\b(claude code|cursor|codex|gemini|amp|opencode)\b/.test(query.toLowerCase())) score += 4;

  return clamp(Number(score.toFixed(2)), 0, 100);
}

function normalizeKeywordRow(row, index = 0) {
  const query = normalizeText(row.query || row.keyword || row.term || row.topic);
  if (!query) {
    throw new Error(`Keyword row ${index + 1} is missing query/keyword/term/topic`);
  }

  const normalized = {
    id: row.id || `kw_${index + 1}_${slugify(query)}`,
    query,
    source: normalizeText(row.source) || 'input',
    notes: normalizeText(row.notes) || null,
    impressions: toNumber(row.impressions),
    clicks: toNumber(row.clicks),
    ctr: toNumber(row.ctr),
    position: toNumber(row.position),
    businessValue: toNumber(row.businessValue) || 0,
  };

  normalized.intent = classifyIntent(normalized.query);
  normalized.pillar = inferPillar(normalized.query);
  normalized.persona = inferPersona(normalized.query);
  normalized.pageType = inferPageType(normalized.intent, normalized.query);
  normalized.opportunityScore = scoreOpportunity(normalized);
  return normalized;
}

function clusterKeywordRows(rows) {
  const clusters = new Map();

  for (const row of rows) {
    const key = row.pillar;
    if (!clusters.has(key)) {
      clusters.set(key, {
        pillar: key,
        pageType: row.pageType,
        queries: [],
        totalOpportunityScore: 0,
        primaryQuery: null,
        personas: new Set(),
        intents: new Set(),
      });
    }
    const cluster = clusters.get(key);
    cluster.queries.push(row);
    cluster.totalOpportunityScore += row.opportunityScore;
    cluster.personas.add(row.persona);
    cluster.intents.add(row.intent);
    if (!cluster.primaryQuery || row.opportunityScore > cluster.primaryQuery.opportunityScore) {
      cluster.primaryQuery = row;
      cluster.pageType = row.pageType;
    }
  }

  return [...clusters.values()]
    .map((cluster) => ({
      ...cluster,
      personas: [...cluster.personas].sort((a, b) => a.localeCompare(b)),
      intents: [...cluster.intents].sort((a, b) => a.localeCompare(b)),
      totalOpportunityScore: Number(cluster.totalOpportunityScore.toFixed(2)),
      queries: [...cluster.queries].sort((a, b) => b.opportunityScore - a.opportunityScore),
    }))
    .sort((a, b) => b.totalOpportunityScore - a.totalOpportunityScore);
}

function buildAuthorityMap(rows, pages) {
  const pageProofByPillar = pages.reduce((acc, page) => {
    if (!acc[page.pillar]) acc[page.pillar] = [];
    acc[page.pillar].push(page.path);
    return acc;
  }, {});

  return clusterKeywordRows(rows).map((cluster) => {
    const proofPages = pageProofByPillar[cluster.pillar] || [];
    const authorityScore = clamp(
      Math.round((cluster.totalOpportunityScore / 2) + (proofPages.length * 32)),
      0,
      100
    );
    const rankPermission = authorityScore >= 70
      ? 'expand'
      : authorityScore >= 48
        ? 'defend-and-fill'
        : 'hold';

    return {
      pillar: cluster.pillar,
      primaryQuery: cluster.primaryQuery.query,
      authorityScore,
      rankPermission,
      proofPages: proofPages.slice(0, 5),
      nextAction: rankPermission === 'expand'
        ? 'Publish semantic variants with proof-backed internal links.'
        : rankPermission === 'defend-and-fill'
          ? 'Fill semantic gaps before scaling adjacent pages.'
          : 'Collect more proof or external demand before generating pages.',
    };
  });
}

function buildContextGovernance() {
  return {
    brandPersona: 'Technical, direct, proof-backed, and buyer-useful. ThumbGate is the enforcement layer, not generic AI content.',
    negativeConstraints: [
      'Do not claim partnerships, approval, revenue, or compliance unless the proof artifact exists.',
      'Do not publish stale pricing; use $19/mo Pro, $149/yr Pro, and $49/seat/mo Team only when the commercial truth source agrees.',
      'Do not create find-and-replace pages that only swap one keyword or platform name.',
    ],
    requiredContext: [
      'ThumbGate turns thumbs-up/down feedback into pre-action checks.',
      'Every buyer-facing page needs a concrete next step: Pro checkout, workflow sprint intake, or a proof-backed guide.',
      'Every generated page must include verification evidence, automation proof, llm-context, FAQPage, and TechArticle schema.',
    ],
  };
}

function buildSemanticMesh(pages) {
  return pages.map((page) => {
    const relatedPaths = page.relatedPages.map((related) => related.path);
    const hasConversionPath = Boolean(page.cta && page.cta.href);
    const hasPillarBridge = relatedPaths.some((relatedPath) => {
      const related = pages.find((candidate) => candidate.path === relatedPath);
      return related && related.pillar !== page.pillar;
    });

    return {
      path: page.path,
      pillar: page.pillar,
      relatedPaths,
      hasConversionPath,
      meshStatus: relatedPaths.length >= 2 && hasPillarBridge && hasConversionPath ? 'healthy' : 'needs-links',
      nextStep: relatedPaths.length >= 2 && hasPillarBridge && hasConversionPath
        ? 'Keep proof and adjacent links fresh.'
        : 'Add pillar, adjacent-guide, and conversion links before publish.',
    };
  });
}

function buildTechnicalGuardian(pages) {
  return {
    checks: [
      'canonical_url',
      'faq_json_ld',
      'tech_article_json_ld',
      'llm_context_link',
      'proof_links',
      'conversion_cta',
      'semantic_related_links',
    ],
    publishBlockers: pages
      .filter((page) => (
        !page.cta ||
        !page.cta.href ||
        !page.relatedPages ||
        page.relatedPages.length < 2 ||
        !page.proofLinks ||
        page.proofLinks.length < 2
      ))
      .map((page) => page.path),
  };
}

function trimMetaDescription(value, max = 160) {
  const text = normalizeText(value);
  if (text.length <= max) return text;
  return `${text.slice(0, max - 3).trim()}...`;
}

function createPageSpec(blueprint, row) {
  const keywordCluster = clusterKeywordRows(
    HIGH_ROI_QUERY_SEEDS.map((seed, index) => normalizeKeywordRow(seed, index))
  ).find((cluster) => cluster.pillar === blueprint.pillar);
  const description = trimMetaDescription(blueprint.heroSummary);
  const relatedPages = blueprint.relatedPaths.map((relatedPath) => {
    const related = PAGE_BLUEPRINTS.find((candidate) => candidate.path === relatedPath);
    return {
      path: relatedPath,
      title: related ? related.heroTitle : relatedPath,
    };
  });

  return {
    path: blueprint.path,
    slug: blueprint.path.split('/').filter(Boolean).join('-'),
    query: row.query,
    pillar: blueprint.pillar || row.pillar,
    intent: row.intent,
    pageType: blueprint.pageType,
    persona: row.persona,
    opportunityScore: row.opportunityScore,
    title: blueprint.title,
    description,
    heroTitle: blueprint.heroTitle,
    heroSummary: blueprint.heroSummary,
    takeaways: blueprint.takeaways,
    sections: blueprint.sections,
    faq: blueprint.faq,
    relatedPages,
    cta: blueprint.cta || {
      label: 'Go Pro — $19/mo',
      href: `/checkout/pro?utm_source=website&utm_medium=seo_page&utm_campaign=${blueprint.path.split('/').filter(Boolean).join('_')}&cta_placement=seo_brief&plan_id=pro`,
    },
    proofLinks: [
      { label: 'Verification evidence', href: PRODUCT.verificationUrl },
      { label: 'GitHub repository', href: PRODUCT.repoUrl },
    ],
    changefreq: blueprint.pageType === 'comparison' ? 'weekly' : 'monthly',
    priority: blueprint.pageType === 'comparison' ? '0.9' : '0.8',
    keywordCluster: keywordCluster ? keywordCluster.queries.slice(0, 4).map((item) => item.query) : [row.query],
    imageAlt: `${PRODUCT.name} guide for ${blueprint.heroTitle}`,
  };
}

function buildThumbGateSeoPlan(rawRows = HIGH_ROI_QUERY_SEEDS) {
  const capture = rawRows.map((row, index) => normalizeKeywordRow(row, index));
  const clusters = clusterKeywordRows(capture);
  const rowsByQuery = new Map(capture.map((row) => [row.query.toLowerCase(), row]));
  const pages = PAGE_BLUEPRINTS.map((blueprint) => {
    const row = rowsByQuery.get(blueprint.query.toLowerCase()) || normalizeKeywordRow({
      query: blueprint.query,
      businessValue: 90,
      source: 'blueprint',
    });
    return createPageSpec(blueprint, row);
  }).sort((a, b) => b.opportunityScore - a.opportunityScore);
  const semanticProgrammaticSeo = {
    authorityMap: buildAuthorityMap(capture, pages),
    contextGovernance: buildContextGovernance(),
    semanticMesh: buildSemanticMesh(pages),
    technicalGuardian: buildTechnicalGuardian(pages),
  };

  const briefs = pages.map((page, index) => ({
    priority: index + 1,
    path: page.path,
    title: page.title,
    primaryQuery: page.query,
    persona: page.persona,
    pageType: page.pageType,
    opportunityScore: page.opportunityScore,
    cta: page.cta,
    keywordCluster: page.keywordCluster,
    summary: page.heroSummary,
  }));

  return {
    framework: 'GSD',
    capture: {
      keywordRows: capture,
      totalKeywords: capture.length,
    },
    clarify: {
      intents: capture.reduce((acc, row) => {
        acc[row.intent] = (acc[row.intent] || 0) + 1;
        return acc;
      }, {}),
      personas: capture.reduce((acc, row) => {
        acc[row.persona] = (acc[row.persona] || 0) + 1;
        return acc;
      }, {}),
      pageTypes: capture.reduce((acc, row) => {
        acc[row.pageType] = (acc[row.pageType] || 0) + 1;
        return acc;
      }, {}),
      contextGovernance: semanticProgrammaticSeo.contextGovernance,
    },
    organize: {
      clusters,
      topClusters: clusters.slice(0, 4),
      authorityMap: semanticProgrammaticSeo.authorityMap,
      semanticMesh: semanticProgrammaticSeo.semanticMesh,
    },
    execute: {
      briefs,
      pages,
    },
    review: {
      topOpportunityQuery: capture.slice().sort((a, b) => b.opportunityScore - a.opportunityScore)[0],
      recommendedOrder: briefs.map((brief) => brief.path),
      proofAssets: PRODUCT.proofPoints,
      technicalGuardian: semanticProgrammaticSeo.technicalGuardian,
    },
    semanticProgrammaticSeo,
  };
}

function renderPlanMarkdown(plan) {
  const lines = [
    '# ThumbGate SEO/GEO GSD Plan',
    '',
    `Framework: ${plan.framework}`,
    '',
    '## Capture',
    '',
    `- Total keyword rows: ${plan.capture.totalKeywords}`,
    ...plan.capture.keywordRows.map((row) => `- ${row.query} | intent=${row.intent} | pillar=${row.pillar} | score=${row.opportunityScore}`),
    '',
    '## Clarify',
    '',
    `- Intents: ${Object.entries(plan.clarify.intents).map(([key, value]) => `${key}=${value}`).join(', ')}`,
    `- Personas: ${Object.entries(plan.clarify.personas).map(([key, value]) => `${key}=${value}`).join(', ')}`,
    `- Page types: ${Object.entries(plan.clarify.pageTypes).map(([key, value]) => `${key}=${value}`).join(', ')}`,
    `- Context governance: ${plan.clarify.contextGovernance.brandPersona}`,
    '',
    '## Organize',
    '',
    ...plan.organize.topClusters.map((cluster) => `- ${cluster.pillar}: ${cluster.primaryQuery.query} (${cluster.totalOpportunityScore})`),
    '',
    '### Authority Map',
    '',
    ...plan.organize.authorityMap.slice(0, 6).map((entry) => `- ${entry.pillar}: ${entry.rankPermission} | score=${entry.authorityScore} | ${entry.nextAction}`),
    '',
    '### Semantic Mesh',
    '',
    ...plan.organize.semanticMesh.slice(0, 8).map((entry) => `- ${entry.path}: ${entry.meshStatus} | links=${entry.relatedPaths.join(', ')}`),
    '',
    '## Execute',
    '',
    ...plan.execute.briefs.map((brief) => (
      `### ${brief.priority}. ${brief.title}\n\n- Path: ${brief.path}\n- Primary query: ${brief.primaryQuery}\n- Persona: ${brief.persona}\n- Page type: ${brief.pageType}\n- Opportunity score: ${brief.opportunityScore}\n- CTA: ${brief.cta.label}\n- Summary: ${brief.summary}`
    )),
    '',
    '## Review',
    '',
    `- Top opportunity query: ${plan.review.topOpportunityQuery.query}`,
    `- Recommended publish order: ${plan.review.recommendedOrder.join(', ')}`,
    `- Proof assets: ${plan.review.proofAssets.join(', ')}`,
    `- Technical guardian checks: ${plan.review.technicalGuardian.checks.join(', ')}`,
    `- Publish blockers: ${plan.review.technicalGuardian.publishBlockers.length ? plan.review.technicalGuardian.publishBlockers.join(', ') : 'none'}`,
    '',
  ];
  return lines.join('\n');
}

function writePlanOutputs(plan, outputDir = DEFAULT_OUTPUT_DIR) {
  fs.mkdirSync(outputDir, { recursive: true });
  const files = {
    capture: path.join(outputDir, '01-capture.json'),
    clarify: path.join(outputDir, '02-clarify.json'),
    organize: path.join(outputDir, '03-organize.json'),
    execute: path.join(outputDir, '04-execute-briefs.md'),
    review: path.join(outputDir, '05-review.json'),
    pages: path.join(outputDir, '06-page-specs.json'),
  };

  fs.writeFileSync(files.capture, `${JSON.stringify(plan.capture, null, 2)}\n`);
  fs.writeFileSync(files.clarify, `${JSON.stringify(plan.clarify, null, 2)}\n`);
  fs.writeFileSync(files.organize, `${JSON.stringify(plan.organize, null, 2)}\n`);
  fs.writeFileSync(files.execute, `${renderPlanMarkdown(plan)}\n`);
  fs.writeFileSync(files.review, `${JSON.stringify(plan.review, null, 2)}\n`);
  fs.writeFileSync(files.pages, `${JSON.stringify(plan.execute.pages, null, 2)}\n`);
  return files;
}

function renderFaqJsonLd(page) {
  if (!Array.isArray(page.faq) || page.faq.length === 0) return '';
  return JSON.stringify({
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: page.faq.map((item) => ({
      '@type': 'Question',
      name: item.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: item.answer,
      },
    })),
  }, null, 2);
}

function renderWebPageJsonLd(page, runtimeConfig) {
  return JSON.stringify({
    '@context': 'https://schema.org',
    '@type': 'TechArticle',
    headline: page.heroTitle,
    description: page.description,
    about: page.keywordCluster,
    url: `${runtimeConfig.appOrigin}${page.path}`,
    publisher: {
      '@type': 'Organization',
      name: PRODUCT.name,
      url: runtimeConfig.appOrigin,
    },
    mainEntityOfPage: `${runtimeConfig.appOrigin}${page.path}`,
  }, null, 2);
}

function renderPaidSprintCheckoutCard(page) {
  const paidSprintGuidePaths = new Set([
    '/guides/ai-agent-governance-sprint',
    '/guides/ai-deployment-readiness',
  ]);
  if (!paidSprintGuidePaths.has(page.path)) return '';

  return `<div class="sidebar-card paid-sprint-card">
          <h2>Ready to buy the sprint?</h2>
          <p>Skip the unpaid intake when budget is ready. Pick the smaller diagnostic to validate one repeated failure, or buy the 48-hour sprint for implementation and proof.</p>
          <div class="paid-offers">
            <a class="paid-offer diagnostic" href="${escapeHtml(PRODUCT.sprintDiagnosticPaymentUrl)}" target="_blank" rel="noopener">
              <span>Workflow Hardening Diagnostic</span>
              <strong>$499</strong>
            </a>
            <a class="paid-offer sprint" href="${escapeHtml(PRODUCT.workflowSprintPaymentUrl)}" target="_blank" rel="noopener">
              <span>AI Agent Governance Sprint</span>
              <strong>$1500</strong>
            </a>
          </div>
          <a class="secondary-cta" href="${escapeHtml(page.cta.href)}" target="_blank" rel="noopener">Use intake instead</a>
        </div>`;
}

function renderSeoPageHtml(page, runtimeConfig = {}) {
  const appOrigin = normalizeText(runtimeConfig.appOrigin) || PRODUCT.homepageUrl;
  const canonicalUrl = `${appOrigin}${page.path}`;
  const relatedCards = page.relatedPages.map((related) => `
        <a class="related-card" href="${escapeHtml(related.path)}">
          <span class="related-label">Related page</span>
          <strong>${escapeHtml(related.title)}</strong>
        </a>`).join('');
  const takeaways = page.takeaways.map((item) => `<li>${escapeHtml(item)}</li>`).join('');
  const sections = page.sections.map((section) => `
      <section class="detail-section">
        <h2>${escapeHtml(section.heading)}</h2>
        ${(section.paragraphs || []).map((paragraph) => `<p>${escapeHtml(paragraph)}</p>`).join('')}
        ${(section.bullets && section.bullets.length) ? `<ul>${section.bullets.map((bullet) => `<li>${escapeHtml(bullet)}</li>`).join('')}</ul>` : ''}
      </section>`).join('');
  const faq = page.faq.map((item) => `
      <details class="faq-item">
        <summary>${escapeHtml(item.question)}</summary>
        <p>${escapeHtml(item.answer)}</p>
      </details>`).join('');
  const proofLinks = page.proofLinks.map((link) => `<a href="${escapeHtml(link.href)}" target="_blank" rel="noopener">${escapeHtml(link.label)}</a>`).join('');
  const paidSprintCheckoutCard = renderPaidSprintCheckoutCard(page);
  const faqJsonLd = renderFaqJsonLd(page);
  const semanticPseoSidebar = page.path === '/guides/semantic-programmatic-seo-guardrails' ? `<div class="sidebar-card">
          <h2>pSEO governance gates</h2>
          <ul>
            <li>Authority map before page generation</li>
            <li>Brand context governance before drafting</li>
            <li>Semantic mesh links before publish</li>
            <li>Technical guardian checks before crawl</li>
          </ul>
        </div>` : '';
  const documentRagSidebar = page.pillar === 'document-rag-safety' ? `<div class="sidebar-card">
          <h2>Document RAG Safety gates</h2>
          <ul>
            <li>Retrieval baseline before tuning</li>
            <li>Two-stage verifier for structural near misses</li>
            <li>Section tree and image pointer grounding</li>
            <li>Latency budget before verifier rollout</li>
          </ul>
        </div>` : '';
  const codeGraphSidebar = page.path === '/guides/code-knowledge-graph-guardrails' ? `<div class="sidebar-card">
          <h2>Knowledge Graph Safety</h2>
          <ul>
            <li>Require diff impact before central edits</li>
            <li>Checkpoint cross-layer refactors</li>
            <li>Protect generated graph artifacts</li>
          </ul>
        </div>` : '';
  const workflowRuleSidebar = page.path === '/guides/prompt-tricks-to-workflow-rules' ? `<div class="sidebar-card">
          <h2>Workflow Rule Safety</h2>
          <ul>
            <li>Clear rule before risky execution</li>
            <li>Good and bad examples before reuse</li>
            <li>Verification evidence before done</li>
          </ul>
        </div>` : '';

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${escapeHtml(page.title)}</title>
  <meta name="description" content="${escapeHtml(page.description)}" />
  <meta property="og:title" content="${escapeHtml(page.title)}" />
  <meta property="og:description" content="${escapeHtml(page.description)}" />
  <meta property="og:type" content="article" />
  <meta property="og:url" content="${escapeHtml(canonicalUrl)}" />
  <link rel="canonical" href="${escapeHtml(canonicalUrl)}" />
  <link rel="llm-context" href="/llm-context.md" type="text/markdown" />
  <link rel="icon" type="image/svg+xml" href="/thumbgate-icon.png" />
  <link rel="apple-touch-icon" href="/assets/brand/thumbgate-mark.svg" />
  <meta property="og:image" content="/og.png" />
  <style>
    :root {
      --bg: #0a0a0b;
      --bg-raised: #111113;
      --bg-card: #161618;
      --line: #222225;
      --text: #e8e8ec;
      --muted: #8b8b96;
      --cyan: #22d3ee;
      --green: #4ade80;
      --red: #f87171;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      background: var(--bg);
      color: var(--text);
      line-height: 1.65;
    }
    a { color: var(--cyan); text-decoration: none; }
    a:hover { text-decoration: underline; }
    .container { max-width: 980px; margin: 0 auto; padding: 0 24px; }
    .topbar {
      position: sticky;
      top: 0;
      z-index: 20;
      backdrop-filter: blur(12px);
      background: rgba(10, 10, 11, 0.88);
      border-bottom: 1px solid var(--line);
    }
    .topbar .container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-top: 14px;
      padding-bottom: 14px;
    }
    .brand {
      font-weight: 700;
      color: var(--text);
      display: inline-flex;
      align-items: center;
      gap: 8px;
      text-decoration: none;
    }
    .brand .logo-mark { width: 28px; height: 28px; display: block; }
    .hero { padding: 72px 0 32px; }
    .eyebrow {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 6px 12px;
      border-radius: 999px;
      border: 1px solid rgba(34, 211, 238, 0.22);
      background: rgba(34, 211, 238, 0.1);
      color: var(--cyan);
      text-transform: uppercase;
      letter-spacing: 0.08em;
      font-size: 12px;
      font-weight: 700;
    }
    h1 {
      font-size: clamp(34px, 5vw, 56px);
      line-height: 1.06;
      letter-spacing: -0.04em;
      margin: 16px 0;
      max-width: 760px;
    }
    .hero p {
      max-width: 720px;
      color: var(--muted);
      font-size: 18px;
    }
    .signal-row {
      display: flex;
      flex-wrap: wrap;
      gap: 12px;
      margin: 28px 0 0;
    }
    .signal-pill {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 10px 14px;
      border-radius: 999px;
      border: 1px solid var(--line);
      background: var(--bg-raised);
      font-weight: 600;
      font-size: 14px;
    }
    .signal-pill.up {
      border-color: rgba(74, 222, 128, 0.28);
      color: #b8f7c8;
      background: rgba(74, 222, 128, 0.1);
    }
    .signal-pill.down {
      border-color: rgba(248, 113, 113, 0.28);
      color: #ffc0c0;
      background: rgba(248, 113, 113, 0.1);
    }
    .grid {
      display: grid;
      grid-template-columns: minmax(0, 2fr) minmax(280px, 1fr);
      gap: 24px;
      padding-bottom: 72px;
    }
    .card, .detail-section, .sidebar-card {
      background: var(--bg-card);
      border: 1px solid var(--line);
      border-radius: 16px;
    }
    .card { padding: 24px; }
    .detail-section { padding: 24px; margin-bottom: 18px; }
    .detail-section h2 { margin: 0 0 12px; font-size: 24px; letter-spacing: -0.03em; }
    .detail-section p { color: var(--muted); }
    .detail-section ul, .card ul { padding-left: 18px; color: var(--muted); }
    .card h2 { margin-top: 0; }
    .sidebar {
      display: flex;
      flex-direction: column;
      gap: 18px;
    }
    .sidebar-card {
      padding: 20px;
    }
    /* Only the first sidebar card sticks. Stacking multiple stickies at the
       same top offset makes them overlap each other on scroll. The related-
       pages card flows normally below. */
    .sidebar-card:first-child {
      position: sticky;
      top: 84px;
      max-height: calc(100vh - 104px);
      overflow-y: auto;
      -webkit-overflow-scrolling: touch;
    }
    .proof-links {
      display: flex;
      flex-wrap: wrap;
      gap: 12px;
      margin-top: 16px;
    }
    .cta-button {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      margin-top: 18px;
      padding: 12px 16px;
      border-radius: 10px;
      background: var(--cyan);
      color: #071116;
      font-weight: 700;
      text-decoration: none;
    }
    .paid-sprint-card {
      border-color: rgba(74, 222, 128, 0.32);
      background: linear-gradient(180deg, rgba(17, 17, 19, 0.98), rgba(10, 20, 14, 0.96));
    }
    .paid-sprint-card p {
      color: var(--muted);
      font-size: 14px;
      line-height: 1.55;
    }
    .paid-offers {
      display: grid;
      gap: 10px;
      margin-top: 16px;
    }
    .paid-offer {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      padding: 12px;
      border: 1px solid rgba(74, 222, 128, 0.28);
      border-radius: 10px;
      color: var(--fg);
      text-decoration: none;
      background: rgba(0, 0, 0, 0.22);
    }
    .paid-offer strong {
      color: #9af5b0;
      white-space: nowrap;
    }
    .paid-offer:hover, .paid-offer:focus-visible {
      border-color: rgba(74, 222, 128, 0.62);
      outline: none;
    }
    .secondary-cta {
      display: inline-flex;
      margin-top: 12px;
      color: var(--cyan);
      font-size: 14px;
      font-weight: 700;
      text-decoration: none;
    }
    .faq-item {
      border-top: 1px solid var(--line);
      padding: 14px 0;
    }
    .faq-item summary {
      cursor: pointer;
      font-weight: 600;
    }
    .faq-item p {
      color: var(--muted);
    }
    .related-card {
      display: block;
      padding: 14px;
      border-radius: 12px;
      border: 1px solid var(--line);
      background: var(--bg-raised);
      margin-top: 12px;
      color: var(--text);
    }
    .related-label {
      display: block;
      color: var(--muted);
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      margin-bottom: 4px;
    }
    @media (max-width: 860px) {
      .grid {
        grid-template-columns: 1fr;
      }
      .sidebar-card:first-child {
        position: static;
        max-height: none;
        overflow: visible;
      }
    }
  </style>
  <script type="application/ld+json">
${renderWebPageJsonLd(page, { appOrigin })}
  </script>
  ${faqJsonLd ? `<script type="application/ld+json">\n${faqJsonLd}\n  </script>` : ''}
</head>
<body>
  <div class="topbar">
    <div class="container">
      <a class="brand" href="/"><img src="/assets/brand/thumbgate-mark-inline-v3.svg" alt="ThumbGate" class="logo-mark" width="28" height="28"><span class="logo-text">ThumbGate</span></a>
      <a href="${escapeHtml(PRODUCT.verificationUrl)}" target="_blank" rel="noopener">Verification evidence</a>
    </div>
  </div>

  <main class="container">
    <section class="hero">
      <div class="eyebrow">${escapeHtml(page.pageType)} | ${escapeHtml(page.query)}</div>
      <h1>${escapeHtml(page.heroTitle)}</h1>
      <p>${escapeHtml(page.heroSummary)}</p>
      <div class="signal-row">
        <div class="signal-pill up">👍 Thumbs up reinforces good behavior</div>
        <div class="signal-pill down">👎 Thumbs down blocks repeated mistakes</div>
      </div>
    </section>

    <section class="grid">
      <div>
        <div class="card">
          <h2>Why this page exists</h2>
          <ul>${takeaways}</ul>
        </div>
        ${sections}
        <div class="detail-section">
          <h2>FAQ</h2>
          ${faq}
        </div>
      </div>

      <aside class="sidebar">
        ${semanticPseoSidebar}
        ${documentRagSidebar}
        ${codeGraphSidebar}
        ${workflowRuleSidebar}
        ${paidSprintCheckoutCard}
        <div class="sidebar-card">
          <h2>GSD execution brief</h2>
          <p>This page was prioritized because it captures high-intent demand around ${escapeHtml(page.query)} and feeds directly into ThumbGate's proof-led conversion path.</p>
          <p><strong>Opportunity score:</strong> ${page.opportunityScore}</p>
          <p><strong>Primary persona:</strong> ${escapeHtml(page.persona)}</p>
          <p><strong>Keyword cluster:</strong> ${escapeHtml(page.keywordCluster.join(', '))}</p>
          <p><strong>Pricing:</strong> Pro $19/mo or $149/yr. Team $49/seat/mo.</p>
          <div class="proof-links">${proofLinks}</div>
          <a class="cta-button" href="${escapeHtml(page.cta.href)}" target="_blank" rel="noopener">${escapeHtml(page.cta.label)}</a>
        </div>
        <div class="sidebar-card">
          <h2>Related pages</h2>
          ${relatedCards}
        </div>
      </aside>
    </section>
  </main>
</body>
</html>`;
  return html.split('\n').map((line) => line.trimEnd()).join('\n');
}

const THUMBGATE_SEO_PLAN = buildThumbGateSeoPlan(HIGH_ROI_QUERY_SEEDS);
const THUMBGATE_SEO_PAGE_SPECS = THUMBGATE_SEO_PLAN.execute.pages;
const THUMBGATE_SEO_SITEMAP_ENTRIES = THUMBGATE_SEO_PAGE_SPECS.map((page) => ({
  path: page.path,
  changefreq: page.changefreq,
  priority: page.priority,
}));

function findSeoPageByPath(pathname) {
  return THUMBGATE_SEO_PAGE_SPECS.find((page) => page.path === pathname) || null;
}

function parseArgs(argv) {
  const args = { command: 'full', write: false, input: null, outDir: DEFAULT_OUTPUT_DIR };
  const tokens = argv.slice(2);
  for (const token of tokens) {
    if (token === 'plan' || token === 'full') {
      args.command = token;
      continue;
    }
    if (token === '--write') {
      args.write = true;
      continue;
    }
    if (token.startsWith('--input=')) {
      args.input = token.slice('--input='.length);
      continue;
    }
    if (token.startsWith('--out-dir=')) {
      args.outDir = path.resolve(token.slice('--out-dir='.length));
      continue;
    }
  }
  return args;
}

async function main() {
  const args = parseArgs(process.argv);
  const rows = args.input ? loadKeywordRows(args.input) : HIGH_ROI_QUERY_SEEDS;
  const plan = buildThumbGateSeoPlan(rows);

  if (args.write) {
    const files = writePlanOutputs(plan, args.outDir);
    console.log(`Wrote SEO GSD outputs to ${args.outDir}`);
    for (const filePath of Object.values(files)) {
      console.log(`  - ${path.relative(ROOT, filePath)}`);
    }
  }

  if (args.command === 'plan' || args.command === 'full') {
    console.log(renderPlanMarkdown(plan));
  }
}

function isCliInvocation(argv = process.argv) {
  return Boolean(argv[1] && path.resolve(argv[1]) === __filename);
}

if (isCliInvocation()) {
  main().catch((error) => {
    console.error(error.message || String(error));
    process.exit(1);
  });
}

module.exports = {
  DEFAULT_OUTPUT_DIR,
  HIGH_ROI_QUERY_SEEDS,
  PAGE_BLUEPRINTS,
  PRODUCT,
  THUMBGATE_SEO_PLAN,
  THUMBGATE_SEO_PAGE_SPECS,
  THUMBGATE_SEO_SITEMAP_ENTRIES,
  buildThumbGateSeoPlan,
  buildAuthorityMap,
  buildContextGovernance,
  buildSemanticMesh,
  buildTechnicalGuardian,
  classifyIntent,
  clusterKeywordRows,
  createPageSpec,
  findSeoPageByPath,
  inferPageType,
  inferPersona,
  inferPillar,
  loadKeywordRows,
  normalizeKeywordRow,
  parseCsv,
  renderPlanMarkdown,
  renderSeoPageHtml,
  scoreOpportunity,
  writePlanOutputs,
};
